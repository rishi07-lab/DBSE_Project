import React, { useState, useEffect } from 'react';
import { API } from './services/api';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';

// Auth
import Login from './pages/Login';

// Doctor / Admin Pages
import Dashboard from './pages/Dashboard';
import Patients from './pages/Patients';
import Doctors from './pages/Doctors';
import Specializations from './pages/Specializations';
import MedicalRecords from './pages/MedicalRecords';
import Medicines from './pages/Medicines';
import Prescriptions from './pages/Prescriptions';
import LabTests from './pages/LabTests';
import LabReports from './pages/LabReports';
import Bills from './pages/Bills';
import Payments from './pages/Payments';
import Insurance from './pages/Insurance';

// Patient Portal Pages
import PatientDashboard from './pages/PatientDashboard';
import PatientViews from './pages/PatientViews';

// Laboratory Staff Portal Pages
import LabDashboard from './pages/LabDashboard';
import LabSampleCollection from './pages/LabSampleCollection';
import LabTestResults from './pages/LabTestResults';
import LabUploadReport from './pages/LabUploadReport';

// -----------------------------------------------------------------------
// Role-Based Route Access Control
// -----------------------------------------------------------------------
// Every valid "page" key in the app must be listed under exactly the
// role(s) permitted to view it. App.jsx uses this map as a frontend route
// guard: if a user's current page is not present in their role's list,
// they are redirected to their role's default landing page. This protects
// against a user manually forcing a page id they should not access
// (there are no browser URLs in this SPA, but this guard operates at the
// application state level so there is no way to bypass it from the UI).
const ROLE_HOME = {
  'Doctor / Admin': 'dashboard',
  'Patient': 'patient-dashboard',
  'Laboratory Staff': 'lab-dashboard',
};

const ROLE_ALLOWED_PAGES = {
  'Doctor / Admin': [
    'dashboard',
    'patients',
    'doctors',
    'specializations',
    'medical-records',
    'prescriptions',
    'medicines',
    'lab-tests',
    'lab-reports',
    'bills',
    'payments',
    'insurance',
  ],
  'Patient': [
    'patient-dashboard',
    'patient-profile',
    'patient-records',
    'patient-prescriptions',
    'patient-medicines',
    'patient-lab-reports',
    'patient-bills',
    'patient-hospital-info',
  ],
  'Laboratory Staff': [
    'lab-dashboard',
    'lab-tests',
    'lab-samples',
    'lab-results',
    'lab-upload',
    'lab-reports',
  ],
};

export default function App() {
  const [user, setUser] = useState(null);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    // Check if a demo session already exists in localStorage
    const existing = API.getCurrentUser();
    if (existing) {
      setUser(existing);
      setCurrentPage(ROLE_HOME[existing.role] || 'dashboard');
    }
    setAuthChecked(true);
  }, []);

  const handleLoginSuccess = (loggedInUser) => {
    setUser(loggedInUser);
    setCurrentPage(ROLE_HOME[loggedInUser.role] || 'dashboard');
  };

  const handleLogout = () => {
    API.logout();
    setUser(null);
    setCurrentPage('dashboard');
  };

  // -----------------------------------------------------------------------
  // FRONTEND ROUTE GUARD
  // -----------------------------------------------------------------------
  // Runs whenever the logged-in user or requested page changes. If the
  // requested page is not part of that role's allowed page list, the user
  // is force-redirected back to their own role's home/dashboard page. This
  // blocks a Patient or Lab Staff account from viewing Admin-only,
  // Medicine-management, or cross-role pages.
  useEffect(() => {
    if (!user) return;
    const allowed = ROLE_ALLOWED_PAGES[user.role] || [];
    if (!allowed.includes(currentPage)) {
      setCurrentPage(ROLE_HOME[user.role] || 'dashboard');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, currentPage]);

  if (!authChecked) {
    return null;
  }

  if (!user) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  const allowedPages = ROLE_ALLOWED_PAGES[user.role] || [];
  const safePage = allowedPages.includes(currentPage) ? currentPage : ROLE_HOME[user.role];

  const renderDoctorAdminPage = () => {
    switch (safePage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'patients':
        return <Patients />;
      case 'doctors':
        return <Doctors />;
      case 'specializations':
        return <Specializations />;
      case 'medicines':
        return <Medicines />;
      case 'prescriptions':
        return <Prescriptions />;
      case 'medical-records':
        return <MedicalRecords />;
      case 'lab-tests':
        return <LabTests />;
      case 'lab-reports':
        return <LabReports />;
      case 'bills':
        return <Bills />;
      case 'payments':
        return <Payments />;
      case 'insurance':
        return <Insurance />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  const renderPatientPage = () => {
    switch (safePage) {
      case 'patient-dashboard':
        return <PatientDashboard user={user} onNavigate={setCurrentPage} />;
      case 'patient-profile':
      case 'patient-records':
      case 'patient-prescriptions':
      case 'patient-medicines':
      case 'patient-lab-reports':
      case 'patient-bills':
      case 'patient-hospital-info':
        return <PatientViews viewType={safePage} user={user} />;
      default:
        return <PatientDashboard user={user} onNavigate={setCurrentPage} />;
    }
  };

  const renderLabStaffPage = () => {
    switch (safePage) {
      case 'lab-dashboard':
        return <LabDashboard onNavigate={setCurrentPage} />;
      case 'lab-tests':
        return <LabTests />;
      case 'lab-samples':
        return <LabSampleCollection />;
      case 'lab-results':
        return <LabTestResults />;
      case 'lab-upload':
        return <LabUploadReport />;
      case 'lab-reports':
        return <LabReports />;
      default:
        return <LabDashboard onNavigate={setCurrentPage} />;
    }
  };

  const renderPage = () => {
    if (user.role === 'Patient') return renderPatientPage();
    if (user.role === 'Laboratory Staff') return renderLabStaffPage();
    return renderDoctorAdminPage();
  };

  const handleQuickAction = () => {
    if (user.role === 'Patient') {
      setCurrentPage('patient-prescriptions');
    } else if (user.role === 'Laboratory Staff') {
      setCurrentPage('lab-samples');
    } else {
      setCurrentPage('patients');
    }
  };

  return (
    <div className="app-layout">
      <Sidebar
        currentPage={safePage}
        setCurrentPage={setCurrentPage}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        user={user}
        onLogout={handleLogout}
      />

      <div className="main-wrapper">
        <Navbar
          currentPage={safePage}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          user={user}
          onQuickAction={handleQuickAction}
        />

        <main>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
