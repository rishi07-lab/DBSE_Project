import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  LabTestIcon,
} from '../components/Icons';

export default function LabTests() {
  const [tests, setTests] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedTest, setSelectedTest] = useState(null);

  const initialFormData = {
    test_name: '',
    test_description: '',
    test_cost: '',
    sample_type: 'Whole Blood (EDTA)',
    test_status: 'Active',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchTests = async () => {
    setLoading(true);
    const data = await API.getLabTests();
    setTests(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchTests();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData(initialFormData);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (test) => {
    setIsEditMode(true);
    setSelectedTest(test);
    setFormData({
      test_name: test.test_name || '',
      test_description: test.test_description || '',
      test_cost: test.test_cost || '',
      sample_type: test.sample_type || 'Whole Blood (EDTA)',
      test_status: test.test_status || 'Active',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...formData,
      test_cost: parseFloat(formData.test_cost) || 0,
    };

    if (isEditMode && selectedTest) {
      await API.updateLabTest({
        ...selectedTest,
        ...payload,
      });
    } else {
      await API.addLabTest(payload);
    }

    setIsModalOpen(false);
    fetchTests();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to remove this lab test?')) {
      await API.deleteLabTest(id);
      fetchTests();
    }
  };

  const filteredTests = tests.filter((t) =>
    t.test_name?.toLowerCase().includes(search.toLowerCase()) ||
    t.test_description?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Laboratory Diagnostic Tests</h1>
          <p>Standard pathology, biochemistry, hematology, and radiological investigation pricing catalog.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Add New Lab Test</span>
        </button>
      </div>

      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '440px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search diagnostic investigations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredTests.length} diagnostic procedures listed
        </div>
      </div>

      <div className="cards-grid">
        {loading ? (
          <div style={{ padding: '30px', color: '#64748b' }}>Loading tests catalog...</div>
        ) : filteredTests.map((t) => (
          <div
            key={t.test_id}
            className="table-card"
            style={{
              padding: '20px',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
            }}
          >
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '10px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <div
                    style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '8px',
                      background: '#fee2e2',
                      color: '#dc2626',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <LabTestIcon size={20} />
                  </div>
                  <div>
                    <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: '#0f172a' }}>{t.test_name}</h3>
                    <div style={{ fontSize: '11px', color: '#64748b' }}>Test ID: #{t.test_id}</div>
                  </div>
                </div>
                <span className="badge badge-success" style={{ fontSize: '13px', padding: '4px 10px' }}>
                  ₹{Number(t.test_cost).toLocaleString('en-IN')}
                </span>
              </div>

              <p style={{ fontSize: '13px', color: '#475569', lineHeight: '1.45', margin: '12px 0 16px' }}>
                {t.test_description}
              </p>

              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                <span className="badge badge-primary">{t.sample_type || 'N/A'}</span>
                <span className={`badge ${t.test_status === 'Inactive' ? 'badge-gray' : 'badge-success'}`}>
                  {t.test_status === 'Inactive' ? '● Inactive' : '● Active'}
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '6px', borderTop: '1px solid #f1f5f9', paddingTop: '12px' }}>
              <button
                className="btn btn-sm btn-secondary"
                onClick={() => handleOpenEdit(t)}
              >
                <EditIcon size={14} />
                <span>Edit</span>
              </button>
              <button
                className="btn btn-sm btn-danger"
                onClick={() => handleDelete(t.test_id)}
              >
                <TrashIcon size={14} />
                <span>Remove</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Laboratory Test' : 'Add New Diagnostic Test'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Test' : 'Add Test'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Test Investigation Name *</label>
            <input
              type="text"
              className="form-input"
              value={formData.test_name}
              onChange={(e) => setFormData({ ...formData, test_name: e.target.value })}
              placeholder="e.g. Complete Blood Count (CBC) or Lipid Panel"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Investigation Description *</label>
            <textarea
              className="form-textarea"
              value={formData.test_description}
              onChange={(e) => setFormData({ ...formData, test_description: e.target.value })}
              placeholder="Clinical indications and parameters evaluated..."
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Standard Test Fee (₹) *</label>
            <input
              type="number"
              step="1"
              min="0"
              className="form-input"
              value={formData.test_cost}
              onChange={(e) => setFormData({ ...formData, test_cost: e.target.value })}
              placeholder="500"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Sample Type *</label>
            <select
              className="form-select"
              value={formData.sample_type}
              onChange={(e) => setFormData({ ...formData, sample_type: e.target.value })}
              required
            >
              <option value="Whole Blood (EDTA)">Whole Blood (EDTA)</option>
              <option value="Blood Serum">Blood Serum</option>
              <option value="Blood Serum (Fasting)">Blood Serum (Fasting)</option>
              <option value="Clean Catch Midstream Urine">Urine</option>
              <option value="Swab">Swab</option>
              <option value="Sputum">Sputum</option>
              <option value="Radiological Imaging">Radiological Imaging</option>
              <option value="Stool Sample">Stool Sample</option>
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Test Status</label>
            <select
              className="form-select"
              value={formData.test_status}
              onChange={(e) => setFormData({ ...formData, test_status: e.target.value })}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </form>
      </Modal>
    </div>
  );
}
