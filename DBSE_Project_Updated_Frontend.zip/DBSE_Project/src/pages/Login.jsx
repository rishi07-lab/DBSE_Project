import React, { useState } from 'react';
import { ActivityIcon, CheckCircleIcon } from '../components/Icons';
import { API } from '../services/api';

export default function Login({ onLoginSuccess }) {
  const [email, setEmail] = useState('admin@hospital.com');
  const [password, setPassword] = useState('Admin@123');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    const res = API.login(email, password);
    if (res.success) {
      onLoginSuccess(res.user);
    } else {
      setError(res.message || 'Invalid email or password.');
    }
  };

  const handleQuickDemo = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError('');
    const res = API.login(demoEmail, demoPassword);
    if (res.success) {
      onLoginSuccess(res.user);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #0369a1 50%, #0d9488 100%)',
      padding: '24px',
    }}>
      <div style={{
        background: '#ffffff',
        borderRadius: '18px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        width: '100%',
        maxWidth: '520px',
        overflow: 'hidden',
      }}>
        {/* Card Header */}
        <div style={{
          padding: '32px 32px 20px',
          textAlign: 'center',
          borderBottom: '1px solid #f1f5f9',
        }}>
          <div style={{
            width: '56px',
            height: '56px',
            background: 'linear-gradient(135deg, #0284c7, #0d9488)',
            borderRadius: '14px',
            margin: '0 auto 14px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#ffffff',
            boxShadow: '0 4px 12px rgba(2, 132, 199, 0.35)',
          }}>
            <ActivityIcon size={32} />
          </div>
          <h2 style={{ fontSize: '24px', fontWeight: '800', color: '#0f172a', letterSpacing: '-0.5px' }}>
            CarePulse Hospital System
          </h2>
          <p style={{ color: '#64748b', fontSize: '13.5px', marginTop: '4px' }}>
            Hospital Clinical & Administrative Management Portal
          </p>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '6px',
            background: '#e0f2fe',
            color: '#0284c7',
            padding: '3px 12px',
            borderRadius: '20px',
            fontSize: '11px',
            fontWeight: '600',
            marginTop: '8px',
          }}>
            <span>● Frontend Demo Mode</span>
          </div>
        </div>

        {/* Form Body */}
        <div style={{ padding: '24px 32px 28px' }}>
          {error && (
            <div style={{
              background: '#fee2e2',
              color: '#dc2626',
              padding: '10px 14px',
              borderRadius: '8px',
              fontSize: '13px',
              marginBottom: '16px',
              border: '1px solid #fecaca',
            }}>
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div className="form-group">
              <label className="form-label">Hospital Username / Email</label>
              <input
                type="email"
                className="form-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. admin@hospital.com"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ padding: '12px', marginTop: '4px' }}>
              Sign In to Hospital Portal
            </button>
          </form>

          {/* Demo Login Credentials Box */}
          <div style={{
            marginTop: '22px',
            paddingTop: '18px',
            borderTop: '1px solid #f1f5f9',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '10px',
            }}>
              <span style={{ fontSize: '12px', fontWeight: '700', color: '#475569', letterSpacing: '0.4px', textTransform: 'uppercase' }}>
                DEMO LOGIN CREDENTIALS
              </span>
              <span style={{ fontSize: '11px', color: '#0284c7', fontWeight: '600' }}>
                Click button to quick-fill & log in
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {/* Doctor / Admin */}
              <div style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-primary" style={{ fontSize: '11px', padding: '2px 8px' }}>Doctor / Admin</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>admin@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Admin@123</code> (Admin + Doctor features)
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={() => handleQuickDemo('admin@hospital.com', 'Admin@123')}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  Quick Login
                </button>
              </div>

              {/* Patient */}
              <div style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-success" style={{ fontSize: '11px', padding: '2px 8px' }}>Patient</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>patient@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Patient@123</code> (Patient #1: Ramesh Verma)
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-success"
                  onClick={() => handleQuickDemo('patient@hospital.com', 'Patient@123')}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  Quick Login
                </button>
              </div>

              {/* Laboratory Staff */}
              <div style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-purple" style={{ fontSize: '11px', padding: '2px 8px' }}>Lab Staff</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>lab@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Lab@123</code> (Diagnostic & lab tests)
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-secondary"
                  onClick={() => handleQuickDemo('lab@hospital.com', 'Lab@123')}
                  style={{ whiteSpace: 'nowrap', borderColor: '#8b5cf6', color: '#6d28d9' }}
                >
                  Quick Login
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
