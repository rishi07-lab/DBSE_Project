import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  EyeIcon,
  MedicalRecordIcon,
} from '../components/Icons';

export default function MedicalRecords() {
  const [records, setRecords] = useState([]);
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState(null);

  const initialFormData = {
    patient_id: '',
    diagnosis: '',
    symptoms: '',
    treatment: '',
    doctor_notes: '',
    record_date: new Date().toISOString().split('T')[0],
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [recList, patList] = await Promise.all([
      API.getMedicalRecords(),
      API.getPatients(),
    ]);
    setRecords(recList);
    setPatients(patList);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      ...initialFormData,
      patient_id: patients[0]?.patient_id || '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rec) => {
    setIsEditMode(true);
    setSelectedRecord(rec);
    setFormData({
      patient_id: rec.patient_id || '',
      diagnosis: rec.diagnosis || '',
      symptoms: rec.symptoms || '',
      treatment: rec.treatment || '',
      doctor_notes: rec.doctor_notes || '',
      record_date: rec.record_date || '',
    });
    setIsModalOpen(true);
  };

  const handleOpenView = (rec) => {
    setSelectedRecord(rec);
    setIsViewModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Unknown Patient',
    };

    if (isEditMode && selectedRecord) {
      await API.updateMedicalRecord({
        ...selectedRecord,
        ...payload,
      });
    } else {
      await API.addMedicalRecord(payload);
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this medical record?')) {
      await API.deleteMedicalRecord(id);
      fetchData();
    }
  };

  const filteredRecords = records.filter((r) => {
    return (
      r.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.diagnosis?.toLowerCase().includes(search.toLowerCase()) ||
      r.symptoms?.toLowerCase().includes(search.toLowerCase()) ||
      r.treatment?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Clinical Medical Records</h1>
          <p>Longitudinal patient history, clinical diagnoses, presenting symptoms, and therapy notes.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>New Medical Record</span>
        </button>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '460px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search records by diagnosis, symptoms, or patient..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredRecords.length} clinical records recorded
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Record ID</th>
                <th>Patient</th>
                <th>Diagnosis</th>
                <th>Presenting Symptoms</th>
                <th>Treatment Plan</th>
                <th>Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading clinical records...
                  </td>
                </tr>
              ) : filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No medical records found.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => (
                  <tr key={r.record_id}>
                    <td style={{ color: '#64748b', fontWeight: '600' }}>#{r.record_id}</td>
                    <td>
                      <div style={{ fontWeight: '700', color: '#0f172a' }}>{r.patient_name}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Patient ID: #{r.patient_id}</div>
                    </td>
                    <td>
                      <span className="badge badge-primary" style={{ fontWeight: '600' }}>
                        {r.diagnosis}
                      </span>
                    </td>
                    <td style={{ color: '#475569', maxWidth: '200px' }}>
                      <div style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                        {r.symptoms}
                      </div>
                    </td>
                    <td style={{ color: '#0f172a', maxWidth: '220px' }}>
                      <div style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                        {r.treatment}
                      </div>
                    </td>
                    <td style={{ color: '#64748b', fontSize: '12.5px' }}>{r.record_date}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon"
                          title="View Full Record"
                          onClick={() => handleOpenView(r)}
                        >
                          <EyeIcon size={16} />
                        </button>
                        <button
                          className="btn-icon edit"
                          title="Edit Record"
                          onClick={() => handleOpenEdit(r)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete Record"
                          onClick={() => handleDelete(r.record_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Medical Record' : 'Create Clinical Medical Record'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Record' : 'Save Record'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Select Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (#{p.patient_id}) - {p.gender}, {p.blood_group}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Clinical Diagnosis *</label>
            <input
              type="text"
              className="form-input"
              value={formData.diagnosis}
              onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
              placeholder="e.g. Type II Diabetes Mellitus with Peripheral Neuropathy"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Reported Symptoms *</label>
            <textarea
              className="form-textarea"
              value={formData.symptoms}
              onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
              placeholder="Describe primary complaints and symptoms..."
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Prescribed Treatment / Intervention *</label>
            <textarea
              className="form-textarea"
              value={formData.treatment}
              onChange={(e) => setFormData({ ...formData, treatment: e.target.value })}
              placeholder="Therapy regimen, prescribed drugs, dietary protocols..."
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Doctor's Clinical Notes</label>
            <textarea
              className="form-textarea"
              value={formData.doctor_notes}
              onChange={(e) => setFormData({ ...formData, doctor_notes: e.target.value })}
              placeholder="Doctor's confidential observations and follow-up directives..."
            />
          </div>

          <div className="form-group">
            <label className="form-label">Record Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.record_date}
              onChange={(e) => setFormData({ ...formData, record_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>

      {/* View Detail Modal */}
      {selectedRecord && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Clinical Case File: Record #${selectedRecord.record_id}`}
          footer={
            <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>
              Close
            </button>
          }
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '12px', color: '#64748b', fontWeight: '700' }}>PATIENT</div>
              <div style={{ fontSize: '18px', fontWeight: '800', color: '#0f172a' }}>
                {selectedRecord.patient_name}
              </div>
              <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {selectedRecord.record_date}</div>
            </div>

            <div>
              <div style={{ fontSize: '12px', fontWeight: '700', color: '#64748b' }}>DIAGNOSIS</div>
              <div style={{ fontSize: '15px', fontWeight: '700', color: '#0284c7', marginTop: '3px' }}>
                {selectedRecord.diagnosis}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '12px', fontWeight: '700', color: '#64748b' }}>SYMPTOMS REPORTED</div>
              <div style={{ fontSize: '14px', color: '#334155', marginTop: '3px', background: '#ffffff', padding: '10px', border: '1px solid #f1f5f9', borderRadius: '8px' }}>
                {selectedRecord.symptoms}
              </div>
            </div>

            <div>
              <div style={{ fontSize: '12px', fontWeight: '700', color: '#64748b' }}>TREATMENT PLAN</div>
              <div style={{ fontSize: '14px', color: '#059669', fontWeight: '500', marginTop: '3px', background: '#ecfdf5', padding: '10px', borderRadius: '8px', border: '1px solid #a7f3d0' }}>
                {selectedRecord.treatment}
              </div>
            </div>

            {selectedRecord.doctor_notes && (
              <div>
                <div style={{ fontSize: '12px', fontWeight: '700', color: '#64748b' }}>PHYSICIAN NOTES</div>
                <div style={{ fontSize: '13.5px', color: '#475569', fontStyle: 'italic', marginTop: '3px', background: '#f8fafc', padding: '10px', borderRadius: '8px' }}>
                  "{selectedRecord.doctor_notes}"
                </div>
              </div>
            )}
          </div>
        </Modal>
      )}
    </div>
  );
}
