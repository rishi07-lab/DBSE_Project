import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  ActivityIcon,
} from '../components/Icons';

export default function LabSampleCollection() {
  const [samples, setSamples] = useState([]);
  const [patients, setPatients] = useState([]);
  const [tests, setTests] = useState([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedSample, setSelectedSample] = useState(null);

  const initialFormData = {
    patient_id: '',
    test_id: '',
    sample_type: 'Whole Blood (EDTA)',
    collection_date: new Date().toISOString().split('T')[0],
    collection_time: '09:00 AM',
    collection_status: 'Collected',
    collected_by: 'Staff Phlebotomist Amit',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [sList, pList, tList] = await Promise.all([
      API.getLabSamples(),
      API.getPatients(),
      API.getLabTests(),
    ]);
    setSamples(sList);
    setPatients(pList);
    setTests(tList);

    if (pList.length && tList.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: pList[0].patient_id,
        test_id: tList[0].test_id,
        sample_type: tList[0].sample_type || 'Whole Blood (EDTA)',
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      patient_id: patients[0]?.patient_id || '',
      test_id: tests[0]?.test_id || '',
      sample_type: tests[0]?.sample_type || 'Whole Blood (EDTA)',
      collection_date: new Date().toISOString().split('T')[0],
      collection_time: '10:00 AM',
      collection_status: 'Collected',
      collected_by: 'Staff Phlebotomist Amit',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (sample) => {
    setIsEditMode(true);
    setSelectedSample(sample);
    setFormData({
      patient_id: sample.patient_id,
      test_id: sample.test_id,
      sample_type: sample.sample_type,
      collection_date: sample.collection_date,
      collection_time: sample.collection_time,
      collection_status: sample.collection_status,
      collected_by: sample.collected_by,
    });
    setIsModalOpen(true);
  };

  const handleTestChange = (testId) => {
    const selected = tests.find((t) => Number(t.test_id) === Number(testId));
    setFormData({
      ...formData,
      test_id: testId,
      sample_type: selected?.sample_type || formData.sample_type,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const testObj = tests.find((t) => Number(t.test_id) === Number(formData.test_id));

    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Patient',
      test_id: Number(formData.test_id),
      test_name: testObj ? testObj.test_name : 'Diagnostic Test',
    };

    if (isEditMode && selectedSample) {
      await API.updateLabSample({
        ...selectedSample,
        ...payload,
      });
    } else {
      const sample_id = `SMP-${Math.floor(1000 + Math.random() * 9000)}`;
      await API.addLabSample({
        sample_id,
        ...payload,
      });
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleStatusChange = async (sample, newStatus) => {
    await API.updateLabSample({
      ...sample,
      collection_status: newStatus,
    });
    fetchData();
  };

  const filteredSamples = samples.filter((s) => {
    const matchesSearch =
      s.sample_id?.toLowerCase().includes(search.toLowerCase()) ||
      s.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.test_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.sample_type?.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = filterStatus === 'All' || s.collection_status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Pending':
        return <span className="badge badge-warning">⏳ Pending</span>;
      case 'Collected':
        return <span className="badge badge-purple">🧪 Collected</span>;
      case 'Processing':
        return <span className="badge badge-primary">⚙️ Processing</span>;
      case 'Completed':
        return <span className="badge badge-success">✓ Completed</span>;
      default:
        return <span className="badge badge-gray">{status}</span>;
    }
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Laboratory Sample Collection</h1>
          <p>Phlebotomy logs, accession barcode IDs, specimen vial registration, and collection statuses.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Log Sample Collection</span>
        </button>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by sample ID, patient, test, or specimen..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="All">All Collection Statuses</option>
            <option value="Pending">Pending</option>
            <option value="Collected">Collected</option>
            <option value="Processing">Processing</option>
            <option value="Completed">Completed</option>
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredSamples.length} specimen records logged
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Sample ID</th>
                <th>Patient Name</th>
                <th>Patient ID</th>
                <th>Investigation Test</th>
                <th>Sample Specimen Type</th>
                <th>Collection Date & Time</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading laboratory specimen registry...
                  </td>
                </tr>
              ) : filteredSamples.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No sample collection records match your criteria.
                  </td>
                </tr>
              ) : (
                filteredSamples.map((s) => (
                  <tr key={s.sample_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>{s.sample_id}</td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>{s.patient_name}</td>
                    <td style={{ color: '#64748b' }}>#{s.patient_id}</td>
                    <td style={{ fontWeight: '600' }}>{s.test_name}</td>
                    <td>
                      <span className="badge badge-primary">{s.sample_type}</span>
                    </td>
                    <td style={{ color: '#475569', fontSize: '13px' }}>
                      {s.collection_date} <span style={{ color: '#64748b' }}>({s.collection_time})</span>
                    </td>
                    <td>{getStatusBadge(s.collection_status)}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '6px', alignItems: 'center' }}>
                        <select
                          className="filter-select"
                          style={{ padding: '4px 8px', fontSize: '12px' }}
                          value={s.collection_status}
                          onChange={(e) => handleStatusChange(s, e.target.value)}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Collected">Collected</option>
                          <option value="Processing">Processing</option>
                          <option value="Completed">Completed</option>
                        </select>
                        <button
                          className="btn-icon edit"
                          title="Edit Sample"
                          onClick={() => handleOpenEdit(s)}
                        >
                          <EditIcon size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Sample Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Specimen Log' : 'Register Specimen Collection'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Specimen' : 'Register Sample'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (Patient #{p.patient_id} - {p.gender}, {p.blood_group}, {p.city})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Investigation Test *</label>
            <select
              className="form-select"
              value={formData.test_id}
              onChange={(e) => handleTestChange(e.target.value)}
              required
            >
              {tests.map((t) => (
                <option key={t.test_id} value={t.test_id}>
                  {t.test_name} (₹{t.test_cost})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Specimen Sample Type *</label>
            <input
              type="text"
              className="form-input"
              value={formData.sample_type}
              onChange={(e) => setFormData({ ...formData, sample_type: e.target.value })}
              placeholder="e.g. Whole Blood, Serum, Urine, Swab"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Collection Status</label>
            <select
              className="form-select"
              value={formData.collection_status}
              onChange={(e) => setFormData({ ...formData, collection_status: e.target.value })}
            >
              <option value="Pending">Pending</option>
              <option value="Collected">Collected</option>
              <option value="Processing">Processing</option>
              <option value="Completed">Completed</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Collection Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.collection_date}
              onChange={(e) => setFormData({ ...formData, collection_date: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Collection Time *</label>
            <input
              type="text"
              className="form-input"
              value={formData.collection_time}
              onChange={(e) => setFormData({ ...formData, collection_time: e.target.value })}
              placeholder="e.g. 09:30 AM"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Collected By (Phlebotomist Name)</label>
            <input
              type="text"
              className="form-input"
              value={formData.collected_by}
              onChange={(e) => setFormData({ ...formData, collected_by: e.target.value })}
              placeholder="Staff Phlebotomist Amit"
            />
          </div>
        </form>
      </Modal>
    </div>
  );
}
