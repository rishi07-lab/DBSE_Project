import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  EyeIcon,
  PrinterIcon,
  BillIcon,
} from '../components/Icons';

export default function Bills() {
  const [bills, setBills] = useState([]);
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedBill, setSelectedBill] = useState(null);

  const initialFormData = {
    patient_id: '',
    bill_date: new Date().toISOString().split('T')[0],
    total_amount: '',
    payment_status: 'Unpaid',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [bList, patList] = await Promise.all([
      API.getBills(),
      API.getPatients(),
    ]);
    setBills(bList);
    setPatients(patList);

    if (patList.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: patList[0].patient_id,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      patient_id: patients[0]?.patient_id || '',
      bill_date: new Date().toISOString().split('T')[0],
      total_amount: '',
      payment_status: 'Unpaid',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (bill) => {
    setIsEditMode(true);
    setSelectedBill(bill);
    setFormData({
      patient_id: bill.patient_id || '',
      bill_date: bill.bill_date || '',
      total_amount: bill.total_amount || '',
      payment_status: bill.payment_status || 'Unpaid',
    });
    setIsModalOpen(true);
  };

  const handleOpenView = (bill) => {
    setSelectedBill(bill);
    setIsViewModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Patient',
      total_amount: parseFloat(formData.total_amount) || 0,
    };

    if (isEditMode && selectedBill) {
      await API.updateBill({
        ...selectedBill,
        ...payload,
      });
    } else {
      await API.addBill(payload);
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this invoice?')) {
      await API.deleteBill(id);
      fetchData();
    }
  };

  const filteredBills = bills.filter((b) => {
    const matchesSearch =
      b.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      String(b.bill_id).includes(search);
    const matchesStatus = filterStatus === 'All' || b.payment_status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const totalBilled = bills.reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);
  const totalPaid = bills
    .filter((b) => b.payment_status === 'Paid')
    .reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);
  const totalPending = totalBilled - totalPaid;

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Paid':
        return <span className="badge badge-success">✓ Paid</span>;
      case 'Unpaid':
        return <span className="badge badge-danger">● Unpaid</span>;
      case 'Pending':
        return <span className="badge badge-warning">⏳ Pending</span>;
      default:
        return <span className="badge badge-gray">{status}</span>;
    }
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Patient Invoices & Hospital Bills</h1>
          <p>Outpatient and inpatient billing, treatment fee receipts, and outstanding dues.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Generate New Bill</span>
        </button>
      </div>

      {/* Financial Overview Cards */}
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))' }}>
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#e0f2fe', color: '#0284c7' }}>
            <BillIcon size={24} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">₹{totalBilled.toLocaleString('en-IN')}</span>
            <span className="stat-card-label">Total Invoiced</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#d1fae5', color: '#059669' }}>
            <BillIcon size={24} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value" style={{ color: '#059669' }}>₹{totalPaid.toLocaleString('en-IN')}</span>
            <span className="stat-card-label">Settled / Collected</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#fee2e2', color: '#dc2626' }}>
            <BillIcon size={24} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value" style={{ color: '#dc2626' }}>₹{totalPending.toLocaleString('en-IN')}</span>
            <span className="stat-card-label">Outstanding Dues</span>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by invoice # or patient name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="All">All Statuses</option>
            <option value="Paid">Paid</option>
            <option value="Unpaid">Unpaid</option>
            <option value="Pending">Pending</option>
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredBills.length} invoices found
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Patient Name</th>
                <th>Invoice Date</th>
                <th>Total Amount</th>
                <th>Payment Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading invoices...
                  </td>
                </tr>
              ) : filteredBills.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No invoices match your search.
                  </td>
                </tr>
              ) : (
                filteredBills.map((b) => (
                  <tr key={b.bill_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{b.bill_id}</td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>
                      {b.patient_name}
                      <span style={{ display: 'block', fontSize: '11px', color: '#64748b' }}>
                        Patient ID: #{b.patient_id}
                      </span>
                    </td>
                    <td>{b.bill_date}</td>
                    <td style={{ fontWeight: '700', fontSize: '14.5px', color: '#0f172a' }}>
                      ₹{Number(b.total_amount).toLocaleString('en-IN')}
                    </td>
                    <td>{getStatusBadge(b.payment_status)}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon"
                          title="View Invoice"
                          onClick={() => handleOpenView(b)}
                        >
                          <EyeIcon size={16} />
                        </button>
                        <button
                          className="btn-icon edit"
                          title="Edit"
                          onClick={() => handleOpenEdit(b)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete"
                          onClick={() => handleDelete(b.bill_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Hospital Bill' : 'Generate New Hospital Bill'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Bill' : 'Generate Bill'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (#{p.patient_id}) - {p.gender}, {p.blood_group}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Total Amount Due (₹) *</label>
            <input
              type="number"
              step="0.01"
              min="0"
              className="form-input"
              value={formData.total_amount}
              onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })}
              placeholder="1500.00"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Payment Status *</label>
            <select
              className="form-select"
              value={formData.payment_status}
              onChange={(e) => setFormData({ ...formData, payment_status: e.target.value })}
            >
              <option value="Unpaid">Unpaid</option>
              <option value="Paid">Paid</option>
              <option value="Pending">Pending</option>
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Invoice Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.bill_date}
              onChange={(e) => setFormData({ ...formData, bill_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>

      {/* Invoice Slip View */}
      {selectedBill && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title="Hospital Official Invoice"
          maxWidth="680px"
          footer={
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>
                Close
              </button>
              <button className="btn btn-primary" onClick={() => window.print()}>
                <PrinterIcon size={16} />
                <span>Print Invoice</span>
              </button>
            </div>
          }
        >
          <div className="medical-slip">
            <div className="slip-header">
              <div>
                <div className="slip-title">CarePulse Hospital</div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  Billing & Accounts Department • Tax ID: #MED-992-120
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontWeight: '800', fontSize: '18px', color: '#0f172a' }}>
                  INVOICE #{selectedBill.bill_id}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {selectedBill.bill_date}</div>
              </div>
            </div>

            <div className="slip-info-grid">
              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>BILLED TO</span>
                <div style={{ fontSize: '16px', fontWeight: '700' }}>{selectedBill.patient_name}</div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedBill.patient_id}</div>
              </div>

              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PAYMENT STATUS</span>
                <div style={{ marginTop: '4px' }}>{getStatusBadge(selectedBill.payment_status)}</div>
              </div>
            </div>

            <div style={{ margin: '24px 0', borderTop: '1px solid #e2e8f0', borderBottom: '1px solid #e2e8f0', padding: '16px 0' }}>
              <table style={{ width: '100%', fontSize: '14px', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ color: '#64748b', textAlign: 'left', borderBottom: '1px solid #f1f5f9' }}>
                    <th style={{ paddingBottom: '8px' }}>Description</th>
                    <th style={{ paddingBottom: '8px', textAlign: 'right' }}>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: '500' }}>
                      Clinical Consultation, Diagnostics & Pharmacy Services
                    </td>
                    <td style={{ padding: '10px 0', textAlign: 'right', fontWeight: '700' }}>
                      ₹{Number(selectedBill.total_amount).toLocaleString('en-IN')}
                    </td>
                  </tr>
                </tbody>
                <tfoot>
                  <tr style={{ borderTop: '2px solid #0f172a', fontWeight: '800' }}>
                    <td style={{ paddingTop: '12px', fontSize: '16px' }}>TOTAL DUE:</td>
                    <td style={{ paddingTop: '12px', textAlign: 'right', fontSize: '18px', color: '#0284c7' }}>
                      ₹{Number(selectedBill.total_amount).toLocaleString('en-IN')}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>

            <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: '11.5px', marginTop: '20px' }}>
              Thank you for trusting CarePulse Hospital with your medical healthcare.
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
