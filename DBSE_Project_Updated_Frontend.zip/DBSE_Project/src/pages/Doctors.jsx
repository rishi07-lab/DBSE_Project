import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  DoctorIcon,
} from '../components/Icons';

export default function Doctors() {
  const [doctors, setDoctors] = useState([]);
  const [specializations, setSpecializations] = useState([]);
  const [search, setSearch] = useState('');
  const [filterAvailability, setFilterAvailability] = useState('All');
  const [filterSpec, setFilterSpec] = useState('All');
  const [viewMode, setViewMode] = useState('cards'); // 'cards' or 'table'
  const [loading, setLoading] = useState(true);

  // Modals state
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(null);

  // Form
  const initialFormData = {
    name: '',
    email: '',
    phone: '',
    specialization_id: 1,
    qualification: '',
    experience_years: 5,
    availability_status: 'Available',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [docs, specs] = await Promise.all([
      API.getDoctors(),
      API.getSpecializations(),
    ]);
    setDoctors(docs);
    setSpecializations(specs);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      ...initialFormData,
      specialization_id: specializations[0]?.specialization_id || 1,
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (doc) => {
    setIsEditMode(true);
    setSelectedDoctor(doc);
    setFormData({
      name: doc.name || '',
      email: doc.email || '',
      phone: doc.phone || '',
      specialization_id: doc.specialization_id || 1,
      qualification: doc.qualification || '',
      experience_years: doc.experience_years || 0,
      availability_status: doc.availability_status || 'Available',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const specObj = specializations.find(
      (s) => Number(s.specialization_id) === Number(formData.specialization_id)
    );
    const specName = specObj ? specObj.specialization_name : 'General Medicine';

    const doctorPayload = {
      ...formData,
      specialization_name: specName,
    };

    if (isEditMode && selectedDoctor) {
      await API.updateDoctor({
        ...selectedDoctor,
        ...doctorPayload,
      });
    } else {
      await API.addDoctor({
        ...doctorPayload,
        user_id: Math.floor(Math.random() * 1000) + 500,
      });
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to remove this doctor?')) {
      await API.deleteDoctor(id);
      fetchData();
    }
  };

  // Filtered doctors
  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name?.toLowerCase().includes(search.toLowerCase()) ||
      doc.specialization_name?.toLowerCase().includes(search.toLowerCase()) ||
      doc.qualification?.toLowerCase().includes(search.toLowerCase());

    const matchesAvailability =
      filterAvailability === 'All' || doc.availability_status === filterAvailability;

    const matchesSpec =
      filterSpec === 'All' || String(doc.specialization_id) === String(filterSpec);

    return matchesSearch && matchesAvailability && matchesSpec;
  });

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Available':
        return <span className="badge badge-success">● Available</span>;
      case 'In Surgery':
        return <span className="badge badge-danger">● In Surgery</span>;
      case 'On Leave':
        return <span className="badge badge-warning">● On Leave</span>;
      default:
        return <span className="badge badge-gray">{status}</span>;
    }
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Medical Doctors & Specialists</h1>
          <p>Consultant physicians, surgeons, specializations, and on-duty availability.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Add New Doctor</span>
        </button>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by doctor name, specialty, or qualification..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterAvailability}
            onChange={(e) => setFilterAvailability(e.target.value)}
          >
            <option value="All">All Availabilities</option>
            <option value="Available">Available</option>
            <option value="In Surgery">In Surgery</option>
            <option value="On Leave">On Leave</option>
          </select>

          <select
            className="filter-select"
            value={filterSpec}
            onChange={(e) => setFilterSpec(e.target.value)}
          >
            <option value="All">All Specializations</option>
            {specializations.map((s) => (
              <option key={s.specialization_id} value={s.specialization_id}>
                {s.specialization_name}
              </option>
            ))}
          </select>
        </div>

        {/* View mode toggle */}
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button
            className={`btn btn-sm ${viewMode === 'cards' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setViewMode('cards')}
          >
            Cards View
          </button>
          <button
            className={`btn btn-sm ${viewMode === 'table' ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setViewMode('table')}
          >
            Table View
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px', color: '#64748b' }}>
          Loading doctors roster...
        </div>
      ) : filteredDoctors.length === 0 ? (
        <div className="table-card" style={{ padding: '40px', textAlign: 'center', color: '#94a3b8' }}>
          No doctors found matching your criteria.
        </div>
      ) : viewMode === 'cards' ? (
        /* Cards View */
        <div className="cards-grid">
          {filteredDoctors.map((doc) => (
            <div key={doc.doctor_id} className="doctor-card">
              <div>
                <div className="doctor-header">
                  <div className="doctor-avatar">
                    {doc.name.replace('Dr. ', '').charAt(0)}
                  </div>
                  <div>
                    <div className="doctor-name">{doc.name}</div>
                    <div className="doctor-spec">{doc.specialization_name}</div>
                  </div>
                </div>

                <div style={{ margin: '8px 0' }}>
                  {getStatusBadge(doc.availability_status)}
                </div>

                <div className="doctor-meta-list">
                  <div className="doctor-meta-item">
                    <span>Doctor ID:</span>
                    <strong style={{ color: '#0f172a' }}>#{doc.doctor_id}</strong>
                  </div>
                  <div className="doctor-meta-item">
                    <span>Qualification:</span>
                    <strong style={{ color: '#0f172a' }}>{doc.qualification}</strong>
                  </div>
                  <div className="doctor-meta-item">
                    <span>Experience:</span>
                    <strong style={{ color: '#0f172a' }}>{doc.experience_years} Years</strong>
                  </div>
                  <div className="doctor-meta-item">
                    <span>Contact:</span>
                    <span>{doc.phone}</span>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '8px', borderTop: '1px solid #f1f5f9', paddingTop: '12px' }}>
                <button
                  className="btn btn-sm btn-secondary"
                  onClick={() => handleOpenEdit(doc)}
                >
                  <EditIcon size={14} />
                  <span>Edit</span>
                </button>
                <button
                  className="btn btn-sm btn-danger"
                  onClick={() => handleDelete(doc.doctor_id)}
                >
                  <TrashIcon size={14} />
                  <span>Remove</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Doctor Name</th>
                  <th>Specialization</th>
                  <th>Qualification</th>
                  <th>Experience</th>
                  <th>Status</th>
                  <th>Phone</th>
                  <th style={{ textAlign: 'right' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredDoctors.map((doc) => (
                  <tr key={doc.doctor_id}>
                    <td style={{ color: '#64748b', fontWeight: '600' }}>#{doc.doctor_id}</td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>{doc.name}</td>
                    <td>
                      <span className="badge badge-primary">{doc.specialization_name}</span>
                    </td>
                    <td>{doc.qualification}</td>
                    <td>{doc.experience_years} Years</td>
                    <td>{getStatusBadge(doc.availability_status)}</td>
                    <td style={{ color: '#475569' }}>{doc.phone}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon edit"
                          title="Edit"
                          onClick={() => handleOpenEdit(doc)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete"
                          onClick={() => handleDelete(doc.doctor_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Doctor Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Doctor Profile' : 'Add New Doctor'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Doctor' : 'Save Doctor'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group">
            <label className="form-label">Doctor Full Name *</label>
            <input
              type="text"
              className="form-input"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Dr. Ananya Krishnan"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Specialization (Department) *</label>
            <select
              className="form-select"
              value={formData.specialization_id}
              onChange={(e) => setFormData({ ...formData, specialization_id: Number(e.target.value) })}
            >
              {specializations.map((s) => (
                <option key={s.specialization_id} value={s.specialization_id}>
                  {s.specialization_name}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Qualification *</label>
            <input
              type="text"
              className="form-input"
              value={formData.qualification}
              onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
              placeholder="e.g. MBBS, MD, DM Cardiology"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Years of Experience</label>
            <input
              type="number"
              min="0"
              className="form-input"
              value={formData.experience_years}
              onChange={(e) => setFormData({ ...formData, experience_years: Number(e.target.value) })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Availability Status</label>
            <select
              className="form-select"
              value={formData.availability_status}
              onChange={(e) => setFormData({ ...formData, availability_status: e.target.value })}
            >
              <option value="Available">Available</option>
              <option value="In Surgery">In Surgery</option>
              <option value="On Leave">On Leave</option>
              <option value="Busy">Busy</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input
              type="text"
              className="form-input"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="+91 98765 43210"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Email Address</label>
            <input
              type="email"
              className="form-input"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="doctor.name@hospital.com"
              required
            />
          </div>
        </form>
      </Modal>
    </div>
  );
}
