import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  LabTestIcon,
  LabReportIcon,
  ActivityIcon,
  PlusIcon,
  CheckCircleIcon,
  EyeIcon,
} from '../components/Icons';

export default function LabDashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const data = await API.getLabDashboardStats();
      setStats(data);
      setLoading(false);
    }
    loadData();
  }, []);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading laboratory department overview...
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: 'Diagnostic Test Catalog',
      value: stats.totalTests,
      subtext: 'Active Test Profiles',
      color: '#0284c7',
      bg: '#e0f2fe',
      page: 'lab-tests',
      icon: LabTestIcon,
    },
    {
      label: 'Pending Sample Collections',
      value: stats.pendingSamples,
      subtext: 'Awaiting Phlebotomy',
      color: '#d97706',
      bg: '#fef3c7',
      page: 'lab-samples',
      icon: ActivityIcon,
    },
    {
      label: 'In-Processing Samples',
      value: stats.processingSamples,
      subtext: 'Under Biochemical Analysis',
      color: '#7c3aed',
      bg: '#ede9fe',
      page: 'lab-results',
      icon: ActivityIcon,
    },
    {
      label: 'Completed Pathology Reports',
      value: stats.completedReports,
      subtext: 'Verified & Dispatched',
      color: '#059669',
      bg: '#d1fae5',
      page: 'lab-reports',
      icon: LabReportIcon,
    },
  ];

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Laboratory Diagnostic Center Dashboard</h1>
          <p>Specimen collection workflows, pathology investigation queues, and clinical result verification.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('lab-samples')}>
            <PlusIcon size={16} />
            <span>Collect New Sample</span>
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('lab-upload')}>
            <PlusIcon size={16} />
            <span>Upload Patient Report</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="stats-grid">
        {statCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <div
              key={i}
              className="stat-card"
              style={{ cursor: 'pointer' }}
              onClick={() => onNavigate(card.page)}
            >
              <div className="stat-icon-wrapper" style={{ background: card.bg, color: card.color }}>
                <Icon size={26} />
              </div>
              <div className="stat-card-info">
                <span className="stat-card-value">{card.value}</span>
                <span className="stat-card-label">{card.label}</span>
                <span className="stat-card-trend" style={{ color: card.color }}>{card.subtext}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Grid: Recent Samples & Quick Operations */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
        
        {/* Recent Sample Queue */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: '#0f172a' }}>
              Specimen Collection Queue
            </h3>
            <button className="btn btn-sm btn-secondary" onClick={() => onNavigate('lab-samples')}>
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Sample ID</th>
                  <th>Patient</th>
                  <th>Investigation</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentSamples.map((s) => (
                  <tr key={s.sample_id}>
                    <td style={{ fontWeight: '700', color: '#0284c7' }}>{s.sample_id}</td>
                    <td style={{ fontWeight: '600' }}>{s.patient_name}</td>
                    <td>{s.test_name}</td>
                    <td>
                      <span className={`badge ${
                        s.collection_status === 'Completed'
                          ? 'badge-success'
                          : s.collection_status === 'Processing'
                          ? 'badge-primary'
                          : s.collection_status === 'Collected'
                          ? 'badge-purple'
                          : 'badge-warning'
                      }`}>
                        {s.collection_status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Launch Cards */}
        <div className="table-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '16px' }}>
            Laboratory Workstations
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {[
              {
                title: 'Laboratory Tests Catalog',
                desc: 'Manage test profiles, sample requirements & standard pricing in ₹.',
                page: 'lab-tests',
                btn: 'Manage Tests',
              },
              {
                title: 'Phlebotomy Sample Collection',
                desc: 'Record patient sample collections, vials, collection timestamps & types.',
                page: 'lab-samples',
                btn: 'Sample Log',
              },
              {
                title: 'Biochemical Test Results Entry',
                desc: 'Input quantitative findings, test values, and clinical impressions.',
                page: 'lab-results',
                btn: 'Enter Results',
              },
              {
                title: 'Upload Official Reports',
                desc: 'Attach and file diagnostic PDF reports for patient portal access.',
                page: 'lab-upload',
                btn: 'Upload Report',
              },
            ].map((ws, index) => (
              <div
                key={index}
                style={{
                  padding: '12px 16px',
                  background: '#f8fafc',
                  borderRadius: '10px',
                  border: '1px solid #e2e8f0',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '12px',
                }}
              >
                <div>
                  <div style={{ fontWeight: '700', fontSize: '14px', color: '#0f172a' }}>{ws.title}</div>
                  <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{ws.desc}</div>
                </div>
                <button
                  className="btn btn-sm btn-secondary"
                  onClick={() => onNavigate(ws.page)}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  {ws.btn}
                </button>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
