import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  EyeIcon,
} from '../components/Icons';

export default function Patients() {
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [filterGender, setFilterGender] = useState('All');
  const [filterBlood, setFilterBlood] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [isEditMode, setIsEditMode] = useState(false);

  // Form state
  const initialFormData = {
    name: '',
    email: '',
    phone: '',
    date_of_birth: '',
    gender: 'Male',
    blood_group: 'O+',
    address: '',
    emergency_contact: '',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchPatients = async () => {
    setLoading(true);
    const data = await API.getPatients();
    setPatients(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData(initialFormData);
    setIsAddModalOpen(true);
  };

  const handleOpenEdit = (patient) => {
    setIsEditMode(true);
    setSelectedPatient(patient);
    setFormData({
      name: patient.name || '',
      email: patient.email || '',
      phone: patient.phone || '',
      date_of_birth: patient.date_of_birth || '',
      gender: patient.gender || 'Male',
      blood_group: patient.blood_group || 'O+',
      address: patient.address || '',
      emergency_contact: patient.emergency_contact || '',
    });
    setIsAddModalOpen(true);
  };

  const handleOpenView = (patient) => {
    setSelectedPatient(patient);
    setIsViewModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEditMode && selectedPatient) {
      await API.updatePatient({
        ...selectedPatient,
        ...formData,
      });
    } else {
      await API.addPatient({
        ...formData,
        user_id: Math.floor(Math.random() * 1000) + 100,
      });
    }
    setIsAddModalOpen(false);
    fetchPatients();
  };

  const handleDelete = async (patientId) => {
    if (window.confirm('Are you sure you want to delete this patient record?')) {
      await API.deletePatient(patientId);
      fetchPatients();
    }
  };

  // Filtered patients
  const filteredPatients = patients.filter((p) => {
    const matchesSearch =
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.phone?.toLowerCase().includes(search.toLowerCase()) ||
      p.email?.toLowerCase().includes(search.toLowerCase()) ||
      p.address?.toLowerCase().includes(search.toLowerCase());

    const matchesGender = filterGender === 'All' || p.gender === filterGender;
    const matchesBlood = filterBlood === 'All' || p.blood_group === filterBlood;

    return matchesSearch && matchesGender && matchesBlood;
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Patients Directory</h1>
          <p>Manage patient records, emergency contacts, and clinical registrations.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Register New Patient</span>
        </button>
      </div>

      {/* Action Bar: Search & Filters */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by name, phone, email, or address..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterGender}
            onChange={(e) => setFilterGender(e.target.value)}
          >
            <option value="All">All Genders</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>

          <select
            className="filter-select"
            value={filterBlood}
            onChange={(e) => setFilterBlood(e.target.value)}
          >
            <option value="All">All Blood Groups</option>
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B-">B-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          Showing {filteredPatients.length} of {patients.length} patients
        </div>
      </div>

      {/* Patients Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Patient Name</th>
                <th>Contact Phone</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Blood Group</th>
                <th>Emergency Contact</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading patient database records...
                  </td>
                </tr>
              ) : filteredPatients.length === 0 ? (
                <tr>
                  <td colSpan="8" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No patients match your search criteria.
                  </td>
                </tr>
              ) : (
                filteredPatients.map((p) => (
                  <tr key={p.patient_id}>
                    <td style={{ color: '#64748b', fontWeight: '600' }}>#{p.patient_id}</td>
                    <td>
                      <div style={{ fontWeight: '700', color: '#0f172a' }}>{p.name}</div>
                      <div style={{ fontSize: '12px', color: '#64748b' }}>{p.email}</div>
                    </td>
                    <td>{p.phone}</td>
                    <td>{p.date_of_birth}</td>
                    <td>
                      <span className={`badge ${p.gender === 'Male' ? 'badge-primary' : 'badge-purple'}`}>
                        {p.gender}
                      </span>
                    </td>
                    <td>
                      <span className="badge badge-warning" style={{ fontWeight: '700' }}>
                        {p.blood_group}
                      </span>
                    </td>
                    <td style={{ fontSize: '12.5px', color: '#475569' }}>
                      {p.emergency_contact || 'None'}
                    </td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon"
                          title="View Details"
                          onClick={() => handleOpenView(p)}
                        >
                          <EyeIcon size={16} />
                        </button>
                        <button
                          className="btn-icon edit"
                          title="Edit Patient"
                          onClick={() => handleOpenEdit(p)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete Patient"
                          onClick={() => handleDelete(p.patient_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title={isEditMode ? 'Edit Patient Information' : 'Register New Patient'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Save Changes' : 'Register Patient'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group">
            <label className="form-label">Full Name *</label>
            <input
              type="text"
              className="form-input"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g. Rahul Sharma"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Email Address *</label>
            <input
              type="email"
              className="form-input"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="patient.name@gmail.com"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Phone Number *</label>
            <input
              type="text"
              className="form-input"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="+91 98765 43210"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Date of Birth *</label>
            <input
              type="date"
              className="form-input"
              value={formData.date_of_birth}
              onChange={(e) => setFormData({ ...formData, date_of_birth: e.target.value })}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Gender</label>
            <select
              className="form-select"
              value={formData.gender}
              onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Blood Group</label>
            <select
              className="form-select"
              value={formData.blood_group}
              onChange={(e) => setFormData({ ...formData, blood_group: e.target.value })}
            >
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Residential Address</label>
            <input
              type="text"
              className="form-input"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              placeholder="Full street address, city, state"
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Emergency Contact (Name & Relationship & Phone)</label>
            <input
              type="text"
              className="form-input"
              value={formData.emergency_contact}
              onChange={(e) => setFormData({ ...formData, emergency_contact: e.target.value })}
              placeholder="e.g. Sunita Sharma (Spouse) +91 98765 43211"
            />
          </div>
        </form>
      </Modal>

      {/* View Patient Details Modal */}
      {selectedPatient && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title={`Patient Record: ${selectedPatient.name}`}
          footer={
            <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>
              Close
            </button>
          }
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '16px',
              padding: '16px',
              background: '#f8fafc',
              borderRadius: '12px',
            }}>
              <div style={{
                width: '54px',
                height: '54px',
                borderRadius: '50%',
                background: 'linear-gradient(135deg, #0284c7, #0d9488)',
                color: 'white',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '20px',
                fontWeight: '700',
              }}>
                {selectedPatient.name.charAt(0)}
              </div>
              <div>
                <h3 style={{ fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>{selectedPatient.name}</h3>
                <div style={{ fontSize: '13px', color: '#64748b' }}>
                  Patient ID: #{selectedPatient.patient_id} • User ID: #{selectedPatient.user_id}
                </div>
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '14px', fontSize: '13.5px' }}>
              <div>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>EMAIL ADDRESS</span>
                <span style={{ fontWeight: '500' }}>{selectedPatient.email}</span>
              </div>
              <div>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>PHONE NUMBER</span>
                <span style={{ fontWeight: '500' }}>{selectedPatient.phone}</span>
              </div>
              <div>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>DATE OF BIRTH</span>
                <span style={{ fontWeight: '500' }}>{selectedPatient.date_of_birth}</span>
              </div>
              <div>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>GENDER & BLOOD</span>
                <span style={{ fontWeight: '500' }}>{selectedPatient.gender} ({selectedPatient.blood_group})</span>
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>RESIDENTIAL ADDRESS</span>
                <span style={{ fontWeight: '500' }}>{selectedPatient.address || 'N/A'}</span>
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <span style={{ color: '#64748b', display: 'block', fontSize: '12px', fontWeight: '600' }}>EMERGENCY CONTACT</span>
                <span style={{ fontWeight: '600', color: '#b45309' }}>{selectedPatient.emergency_contact || 'None specified'}</span>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
