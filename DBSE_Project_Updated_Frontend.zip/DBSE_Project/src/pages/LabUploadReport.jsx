import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  LabReportIcon,
  CheckCircleIcon,
  EyeIcon,
  ActivityIcon,
} from '../components/Icons';

export default function LabUploadReport() {
  const [patients, setPatients] = useState([]);
  const [tests, setTests] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [uploadedReports, setUploadedReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [successMsg, setSuccessMsg] = useState('');

  // Form State
  const initialFormData = {
    patient_id: '',
    test_id: '',
    doctor_id: '',
    result: '',
    remarks: '',
    file_name: '',
    file_size: '',
    report_date: new Date().toISOString().split('T')[0],
  };
  const [formData, setFormData] = useState(initialFormData);
  const [selectedFile, setSelectedFile] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    const [pList, tList, dList, rList] = await Promise.all([
      API.getPatients(),
      API.getLabTests(),
      API.getDoctors(),
      API.getLabReports(),
    ]);
    setPatients(pList);
    setTests(tList);
    setDoctors(dList);
    setUploadedReports(rList);

    if (pList.length && tList.length && dList.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: pList[0].patient_id,
        test_id: tList[0].test_id,
        doctor_id: dList[0].doctor_id,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setSelectedFile(file);
      setFormData({
        ...formData,
        file_name: file.name,
        file_size: `${(file.size / 1024).toFixed(1)} KB`,
      });
    }
  };

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const testObj = tests.find((t) => Number(t.test_id) === Number(formData.test_id));
    const docObj = doctors.find((d) => Number(d.doctor_id) === Number(formData.doctor_id));

    const payload = {
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Patient',
      test_id: Number(formData.test_id),
      test_name: testObj ? testObj.test_name : 'Diagnostic Test',
      doctor_id: Number(formData.doctor_id),
      doctor_name: docObj ? docObj.name : 'Dr. Rajesh Sharma',
      result: formData.result || 'Diagnostic report file uploaded and verified.',
      remarks: formData.remarks || 'Standard diagnostic investigation report document.',
      report_date: formData.report_date,
      file_attachment: formData.file_name || 'Diagnostic_Pathology_Report.pdf',
      file_size: formData.file_size || '120 KB',
      is_uploaded_document: true,
    };

    await API.addLabReport(payload);

    setSuccessMsg(`Successfully uploaded report for ${payload.patient_name} (${payload.test_name}). The patient can now view this in their Patient Portal.`);
    setSelectedFile(null);
    setFormData({
      ...formData,
      result: '',
      remarks: '',
      file_name: '',
      file_size: '',
    });
    fetchData();

    setTimeout(() => {
      setSuccessMsg('');
    }, 6000);
  };

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Upload Patient Laboratory Reports</h1>
          <p>Publish digital diagnostic sheets and laboratory documents for patient health portal access.</p>
        </div>
      </div>

      {/* Notice regarding frontend demo file storage */}
      <div style={{
        background: '#eff6ff',
        border: '1px solid #bfdbfe',
        borderRadius: '12px',
        padding: '14px 18px',
        marginBottom: '24px',
        fontSize: '13px',
        color: '#1e40af',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
      }}>
        <span style={{ fontSize: '20px' }}>ℹ️</span>
        <div>
          <strong>Frontend Demo Mode Notice:</strong> Files uploaded here are simulated and indexed into the local frontend session cache. When a backend/S3 object storage is connected later, this will securely store actual files on the cloud server.
        </div>
      </div>

      {successMsg && (
        <div style={{
          background: '#d1fae5',
          border: '1px solid #a7f3d0',
          color: '#065f46',
          padding: '14px 18px',
          borderRadius: '10px',
          marginBottom: '20px',
          fontWeight: '600',
          fontSize: '13.5px',
        }}>
          ✓ {successMsg}
        </div>
      )}

      {/* Grid: Upload Form + Recently Uploaded Reports */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
        
        {/* Upload Form Card */}
        <div className="table-card" style={{ padding: '24px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '18px' }}>
            Document Upload Form
          </h3>

          <form onSubmit={handleUploadSubmit} className="form-grid">
            <div className="form-group col-span-2">
              <label className="form-label">Select Patient *</label>
              <select
                className="form-select"
                value={formData.patient_id}
                onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
                required
              >
                {patients.map((p) => (
                  <option key={p.patient_id} value={p.patient_id}>
                    {p.name} (Patient #{p.patient_id} - {p.gender}, {p.city})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Investigation Test *</label>
              <select
                className="form-select"
                value={formData.test_id}
                onChange={(e) => setFormData({ ...formData, test_id: e.target.value })}
                required
              >
                {tests.map((t) => (
                  <option key={t.test_id} value={t.test_id}>
                    {t.test_name} (₹{t.test_cost})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Referring Consultant *</label>
              <select
                className="form-select"
                value={formData.doctor_id}
                onChange={(e) => setFormData({ ...formData, doctor_id: e.target.value })}
                required
              >
                {doctors.map((d) => (
                  <option key={d.doctor_id} value={d.doctor_id}>
                    {d.name} ({d.specialization_name})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Report Document File (PDF / Scanned Sheet) *</label>
              <input
                type="file"
                className="form-input"
                onChange={handleFileChange}
                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              />
              {formData.file_name && (
                <div style={{ fontSize: '12px', color: '#059669', marginTop: '4px', fontWeight: '600' }}>
                  Selected File: {formData.file_name} ({formData.file_size})
                </div>
              )}
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Summary Finding / Result Value *</label>
              <input
                type="text"
                className="form-input"
                value={formData.result}
                onChange={(e) => setFormData({ ...formData, result: e.target.value })}
                placeholder="e.g. Normal Study. Parameters well within biological intervals."
                required
              />
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Pathologist Remarks / Impression</label>
              <textarea
                className="form-textarea"
                rows="2"
                value={formData.remarks}
                onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                placeholder="Clinical correlation and advice..."
              />
            </div>

            <div className="form-group">
              <label className="form-label">Report Date *</label>
              <input
                type="date"
                className="form-input"
                value={formData.report_date}
                onChange={(e) => setFormData({ ...formData, report_date: e.target.value })}
                required
              />
            </div>

            <div className="form-group" style={{ display: 'flex', justifyContent: 'flex-end', alignItems: 'flex-end' }}>
              <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '11px' }}>
                Upload & Publish to Patient
              </button>
            </div>
          </form>
        </div>

        {/* Recently Published Reports */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
          }}>
            <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: '#0f172a' }}>
              Published Diagnostic Reports
            </h3>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Report #</th>
                  <th>Patient</th>
                  <th>Investigation</th>
                  <th>Attached File</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {uploadedReports.map((r) => (
                  <tr key={r.report_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{r.report_id}</td>
                    <td style={{ fontWeight: '700' }}>{r.patient_name}</td>
                    <td>{r.test_name}</td>
                    <td>
                      <span className="badge badge-purple" style={{ fontSize: '11px' }}>
                        📄 {r.file_attachment || 'Report.pdf'}
                      </span>
                    </td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{r.report_date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
