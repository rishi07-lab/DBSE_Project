import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  InsuranceIcon,
} from '../components/Icons';

export default function Insurance() {
  const [insuranceList, setInsuranceList] = useState([]);
  const [patients, setPatients] = useState([]);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedInsurance, setSelectedInsurance] = useState(null);

  const initialFormData = {
    patient_id: '',
    insurance_provider: 'Star Health & Allied Insurance',
    policy_number: '',
    coverage_amount: '',
    claim_status: 'Pending',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [ins, pats] = await Promise.all([
      API.getInsurance(),
      API.getPatients(),
    ]);
    setInsuranceList(ins);
    setPatients(pats);

    if (pats.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: pats[0].patient_id,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      patient_id: patients[0]?.patient_id || '',
      insurance_provider: 'Star Health & Allied Insurance',
      policy_number: '',
      coverage_amount: '',
      claim_status: 'Pending',
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (ins) => {
    setIsEditMode(true);
    setSelectedInsurance(ins);
    setFormData({
      patient_id: ins.patient_id || '',
      insurance_provider: ins.insurance_provider || '',
      policy_number: ins.policy_number || '',
      coverage_amount: ins.coverage_amount || '',
      claim_status: ins.claim_status || 'Pending',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Patient',
      coverage_amount: parseFloat(formData.coverage_amount) || 0,
    };

    if (isEditMode && selectedInsurance) {
      await API.updateInsurance({
        ...selectedInsurance,
        ...payload,
      });
    } else {
      await API.addInsurance(payload);
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this insurance claim policy record?')) {
      await API.deleteInsurance(id);
      fetchData();
    }
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Approved':
        return <span className="badge badge-success">✓ Approved</span>;
      case 'Processing':
        return <span className="badge badge-primary">⏳ Processing</span>;
      case 'Pending':
        return <span className="badge badge-warning">● Pending</span>;
      case 'Rejected':
        return <span className="badge badge-danger">✕ Rejected</span>;
      default:
        return <span className="badge badge-gray">{status}</span>;
    }
  };

  const totalCoverage = insuranceList.reduce(
    (acc, curr) => acc + (Number(curr.coverage_amount) || 0),
    0
  );
  const approvedClaims = insuranceList.filter((i) => i.claim_status === 'Approved').length;

  const filteredInsurance = insuranceList.filter((ins) => {
    const matchesSearch =
      ins.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      ins.insurance_provider?.toLowerCase().includes(search.toLowerCase()) ||
      ins.policy_number?.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = filterStatus === 'All' || ins.claim_status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Medical Insurance & Claims</h1>
          <p>TPA provider verification, insured policy authorizations, and claim adjudication statuses.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Add Insurance Claim</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#ede9fe', color: '#7c3aed' }}>
            <InsuranceIcon size={24} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">₹{totalCoverage.toLocaleString('en-IN')}</span>
            <span className="stat-card-label">Total Policy Coverage Active</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#d1fae5', color: '#059669' }}>
            <InsuranceIcon size={24} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value" style={{ color: '#059669' }}>{approvedClaims}</span>
            <span className="stat-card-label">Approved Pre-Authorizations</span>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by policy #, patient, or provider..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="All">All Statuses</option>
            <option value="Approved">Approved</option>
            <option value="Processing">Processing</option>
            <option value="Pending">Pending</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredInsurance.length} policies found
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Insurance ID</th>
                <th>Patient</th>
                <th>TPA / Insurance Provider</th>
                <th>Policy Number</th>
                <th>Coverage Limit (₹)</th>
                <th>Claim Adjudication</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading insurance records...
                  </td>
                </tr>
              ) : filteredInsurance.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No insurance records found.
                  </td>
                </tr>
              ) : (
                filteredInsurance.map((ins) => (
                  <tr key={ins.insurance_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{ins.insurance_id}</td>
                    <td>
                      <div style={{ fontWeight: '700', color: '#0f172a' }}>{ins.patient_name}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Patient ID: #{ins.patient_id}</div>
                    </td>
                    <td>
                      <span className="badge badge-purple">{ins.insurance_provider}</span>
                    </td>
                    <td style={{ fontWeight: '600', color: '#334155', letterSpacing: '0.3px' }}>
                      {ins.policy_number}
                    </td>
                    <td style={{ fontWeight: '700', color: '#059669', fontSize: '14px' }}>
                      ₹{Number(ins.coverage_amount).toLocaleString('en-IN')}
                    </td>
                    <td>{getStatusBadge(ins.claim_status)}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon edit"
                          title="Edit Claim"
                          onClick={() => handleOpenEdit(ins)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete Claim"
                          onClick={() => handleDelete(ins.insurance_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Insurance Record' : 'Register Patient Insurance Policy'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Policy' : 'Save Policy'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Insured Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (#{p.patient_id}) - {p.gender}, {p.blood_group}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Insurance Provider *</label>
            <input
              type="text"
              className="form-input"
              value={formData.insurance_provider}
              onChange={(e) => setFormData({ ...formData, insurance_provider: e.target.value })}
              placeholder="e.g. Star Health, HDFC ERGO, ICICI Lombard"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Policy / Certificate # *</label>
            <input
              type="text"
              className="form-input"
              value={formData.policy_number}
              onChange={(e) => setFormData({ ...formData, policy_number: e.target.value })}
              placeholder="e.g. POL-899120-X"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Total Coverage Amount (₹) *</label>
            <input
              type="number"
              step="1000"
              min="0"
              className="form-input"
              value={formData.coverage_amount}
              onChange={(e) => setFormData({ ...formData, coverage_amount: e.target.value })}
              placeholder="500000"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Claim Adjudication Status</label>
            <select
              className="form-select"
              value={formData.claim_status}
              onChange={(e) => setFormData({ ...formData, claim_status: e.target.value })}
            >
              <option value="Pending">Pending</option>
              <option value="Processing">Processing</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>
        </form>
      </Modal>
    </div>
  );
}
