import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  PatientsIcon,
  DoctorIcon,
  MedicineIcon,
  PrescriptionIcon,
  BillIcon,
  LabReportIcon,
  InsuranceIcon,
  AlertTriangleIcon,
  PlusIcon,
  EyeIcon,
} from '../components/Icons';

export default function Dashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      const data = await API.getDashboardStats();
      setStats(data);
      setLoading(false);
    }
    loadStats();
  }, []);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading hospital analytics...
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: 'Registered Patients',
      value: stats.totalPatients,
      icon: PatientsIcon,
      bgColor: '#e0f2fe',
      iconColor: '#0284c7',
      page: 'patients',
    },
    {
      label: 'Specialist Doctors',
      value: stats.totalDoctors,
      icon: DoctorIcon,
      bgColor: '#ccfbf1',
      iconColor: '#0d9488',
      page: 'doctors',
    },
    {
      label: 'Medicine Inventory',
      value: stats.totalMedicines,
      icon: MedicineIcon,
      bgColor: '#fef3c7',
      iconColor: '#d97706',
      page: 'medicines',
      subtext: `${stats.lowStockMedicines} Low Stock`,
    },
    {
      label: 'Prescriptions Issued',
      value: stats.totalPrescriptions,
      icon: PrescriptionIcon,
      bgColor: '#ede9fe',
      iconColor: '#7c3aed',
      page: 'prescriptions',
    },
    {
      label: 'Total Revenue',
      value: `₹${Number(stats.totalRevenue).toLocaleString('en-IN')}`,
      icon: BillIcon,
      bgColor: '#d1fae5',
      iconColor: '#059669',
      page: 'bills',
      subtext: `${stats.pendingBills} Pending Payment`,
    },
    {
      label: 'Laboratory Reports',
      value: stats.totalLabReports,
      icon: LabReportIcon,
      bgColor: '#fee2e2',
      iconColor: '#dc2626',
      page: 'lab-reports',
    },
    {
      label: 'Insurance Claims',
      value: stats.totalInsurance,
      icon: InsuranceIcon,
      bgColor: '#e0e7ff',
      iconColor: '#4f46e5',
      page: 'insurance',
    },
  ];

  return (
    <div className="page-container">
      {/* Page Heading */}
      <div className="page-header">
        <div>
          <h1>Hospital Clinical Overview</h1>
          <p>Real-time metrics, active clinical caseloads, and department summaries.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('patients')}>
            <PlusIcon size={16} />
            <span>Admit Patient</span>
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('prescriptions')}>
            <PlusIcon size={16} />
            <span>New Prescription</span>
          </button>
        </div>
      </div>

      {/* Low stock alert banner if any */}
      {stats.lowStockMedicines > 0 && (
        <div style={{
          background: '#fffbeb',
          border: '1px solid #fde68a',
          borderRadius: '12px',
          padding: '14px 20px',
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ color: '#d97706' }}><AlertTriangleIcon size={22} /></span>
            <div>
              <span style={{ fontWeight: '700', color: '#92400e', fontSize: '14px' }}>
                Pharmacy Stock Attention Required:
              </span>{' '}
              <span style={{ color: '#b45309', fontSize: '13.5px' }}>
                {stats.lowStockMedicines} medicine item(s) are running below safety threshold (under 20 units).
              </span>
            </div>
          </div>
          <button 
            className="btn btn-sm btn-secondary"
            onClick={() => onNavigate('medicines')}
            style={{ whiteSpace: 'nowrap' }}
          >
            Review Inventory
          </button>
        </div>
      )}

      {/* KPI Stats Grid */}
      <div className="stats-grid">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div 
              key={index} 
              className="stat-card"
              style={{ cursor: 'pointer' }}
              onClick={() => onNavigate(card.page)}
            >
              <div 
                className="stat-icon-wrapper" 
                style={{ backgroundColor: card.bgColor, color: card.iconColor }}
              >
                <Icon size={26} />
              </div>
              <div className="stat-card-info">
                <span className="stat-card-value">{card.value}</span>
                <span className="stat-card-label">{card.label}</span>
                {card.subtext && (
                  <span className="stat-card-trend" style={{ color: card.iconColor }}>
                    {card.subtext}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Lower Section: Quick Actions & Recent Prescriptions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>
        
        {/* Recent Prescriptions Table Card */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>
              Recent Prescriptions Issued
            </h3>
            <button 
              className="btn btn-sm btn-secondary"
              onClick={() => onNavigate('prescriptions')}
            >
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Doctor</th>
                  <th>Medicine</th>
                  <th>Dosage</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentPrescriptions?.length > 0 ? (
                  stats.recentPrescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td style={{ fontWeight: '600' }}>{p.patient_name}</td>
                      <td style={{ color: '#0284c7' }}>{p.doctor_name}</td>
                      <td>{p.medicine_name}</td>
                      <td><span className="badge badge-gray">{p.dosage}</span></td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>
                      No prescriptions recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Navigation / Department Access Card */}
        <div className="table-card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '16px' }}>
            Hospital Modules Quick Launch
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            {[
              { title: 'Specializations', desc: 'Departments directory', page: 'specializations' },
              { title: 'Medical Records', desc: 'Diagnoses & history', page: 'medical-records' },
              { title: 'Lab Tests', desc: 'Diagnostic catalog', page: 'lab-tests' },
              { title: 'Billing & Invoices', desc: 'Financial invoices', page: 'bills' },
              { title: 'Payment Receipts', desc: 'Payment logs', page: 'payments' },
              { title: 'Insurance Policies', desc: 'Provider claims', page: 'insurance' },
            ].map((m, i) => (
              <div
                key={i}
                onClick={() => onNavigate(m.page)}
                style={{
                  padding: '14px',
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  transition: 'all 0.18s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#e0f2fe';
                  e.currentTarget.style.borderColor = '#0284c7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#f8fafc';
                  e.currentTarget.style.borderColor = '#e2e8f0';
                }}
              >
                <div style={{ fontWeight: '700', fontSize: '13.5px', color: '#0f172a' }}>{m.title}</div>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
