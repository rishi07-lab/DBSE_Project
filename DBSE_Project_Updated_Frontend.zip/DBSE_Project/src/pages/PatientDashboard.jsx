import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  PrescriptionIcon,
  LabReportIcon,
  BillIcon,
  MedicalRecordIcon,
  ActivityIcon,
  EyeIcon,
  CheckCircleIcon,
} from '../components/Icons';

export default function PatientDashboard({ user, onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const patientId = user?.patient_id || 1;

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const data = await API.getPatientDashboardStats(patientId);
      setStats(data);
      setLoading(false);
    }
    loadData();
  }, [patientId]);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading your medical portal...
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      {/* Patient Welcome Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #0284c7 0%, #0d9488 100%)',
        color: '#ffffff',
        borderRadius: '16px',
        padding: '24px 28px',
        marginBottom: '28px',
        boxShadow: '0 10px 25px -5px rgba(2, 132, 199, 0.3)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '20px',
      }}>
        <div>
          <div style={{ fontSize: '12px', fontWeight: '600', textTransform: 'uppercase', letterSpacing: '0.8px', color: '#bae6fd' }}>
            CarePulse Patient Health Portal
          </div>
          <h1 style={{ fontSize: '24px', fontWeight: '800', marginTop: '4px', color: '#ffffff' }}>
            Welcome, {user?.name || 'Ramesh Kumar Verma'}
          </h1>
          <p style={{ fontSize: '13.5px', color: '#f0f9ff', marginTop: '4px', maxWidth: '560px' }}>
            Access your active prescriptions, verified pathology diagnostic sheets, personal clinical history, and billing records in one secure portal.
          </p>
          <div style={{ display: 'flex', gap: '16px', marginTop: '14px', flexWrap: 'wrap', fontSize: '12.5px' }}>
            <span style={{ background: 'rgba(255,255,255,0.2)', padding: '4px 12px', borderRadius: '20px' }}>
              Patient ID: <strong>#{patientId}</strong>
            </span>
            <span style={{ background: 'rgba(255,255,255,0.2)', padding: '4px 12px', borderRadius: '20px' }}>
              Blood Group: <strong>{user?.blood_group || 'B+'}</strong>
            </span>
            <span style={{ background: 'rgba(255,255,255,0.2)', padding: '4px 12px', borderRadius: '20px' }}>
              City: <strong>{user?.city || 'Mumbai'}</strong>
            </span>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button
            className="btn"
            style={{ background: '#ffffff', color: '#0369a1', fontWeight: '700' }}
            onClick={() => onNavigate('patient-prescriptions')}
          >
            <PrescriptionIcon size={16} />
            <span>My Prescriptions</span>
          </button>
          <button
            className="btn"
            style={{ background: 'rgba(255,255,255,0.15)', color: '#ffffff', border: '1px solid rgba(255,255,255,0.4)', fontWeight: '600' }}
            onClick={() => onNavigate('patient-lab-reports')}
          >
            <LabReportIcon size={16} />
            <span>My Lab Reports</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="stats-grid">
        <div
          className="stat-card"
          style={{ cursor: 'pointer' }}
          onClick={() => onNavigate('patient-prescriptions')}
        >
          <div className="stat-icon-wrapper" style={{ background: '#ede9fe', color: '#7c3aed' }}>
            <PrescriptionIcon size={26} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">{stats.totalPrescriptions}</span>
            <span className="stat-card-label">Active Prescriptions</span>
          </div>
        </div>

        <div
          className="stat-card"
          style={{ cursor: 'pointer' }}
          onClick={() => onNavigate('patient-lab-reports')}
        >
          <div className="stat-icon-wrapper" style={{ background: '#fee2e2', color: '#dc2626' }}>
            <LabReportIcon size={26} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">{stats.totalLabReports}</span>
            <span className="stat-card-label">Laboratory Reports</span>
          </div>
        </div>

        <div
          className="stat-card"
          style={{ cursor: 'pointer' }}
          onClick={() => onNavigate('patient-records')}
        >
          <div className="stat-icon-wrapper" style={{ background: '#e0f2fe', color: '#0284c7' }}>
            <MedicalRecordIcon size={26} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">{stats.totalMedicalRecords}</span>
            <span className="stat-card-label">Clinical Diagnoses</span>
          </div>
        </div>

        <div
          className="stat-card"
          style={{ cursor: 'pointer' }}
          onClick={() => onNavigate('patient-bills')}
        >
          <div className="stat-icon-wrapper" style={{ background: '#d1fae5', color: '#059669' }}>
            <BillIcon size={26} />
          </div>
          <div className="stat-card-info">
            <span className="stat-card-value">₹{Number(stats.totalBilled).toLocaleString('en-IN')}</span>
            <span className="stat-card-label">Total Invoiced (₹)</span>
            <span className="stat-card-trend" style={{ color: Number(stats.pendingDues) > 0 ? '#dc2626' : '#059669' }}>
              {Number(stats.pendingDues) > 0 ? `₹${Number(stats.pendingDues).toLocaleString('en-IN')} Due` : '✓ All Dues Settled'}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Prescriptions & Diagnostic Reports */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px', marginBottom: '24px' }}>
        
        {/* Prescriptions */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: '#0f172a' }}>
              My Active Prescriptions
            </h3>
            <button className="btn btn-sm btn-secondary" onClick={() => onNavigate('patient-prescriptions')}>
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Prescribed Drug</th>
                  <th>Doctor</th>
                  <th>Dosage Schedule</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.prescriptions.length === 0 ? (
                  <tr>
                    <td colSpan="4" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>
                      No active prescriptions on file.
                    </td>
                  </tr>
                ) : (
                  stats.prescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td style={{ fontWeight: '700', color: '#0f172a' }}>{p.medicine_name}</td>
                      <td style={{ color: '#0284c7', fontSize: '13px' }}>{p.doctor_name}</td>
                      <td><span className="badge badge-primary">{p.dosage}</span></td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Diagnostic Reports */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '15.5px', fontWeight: '700', color: '#0f172a' }}>
              Verified Pathology Reports
            </h3>
            <button className="btn btn-sm btn-secondary" onClick={() => onNavigate('patient-lab-reports')}>
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Investigation</th>
                  <th>Findings Summary</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.labReports.length === 0 ? (
                  <tr>
                    <td colSpan="3" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>
                      No diagnostic reports logged yet.
                    </td>
                  </tr>
                ) : (
                  stats.labReports.map((r) => (
                    <tr key={r.report_id}>
                      <td>
                        <div style={{ fontWeight: '700', color: '#0f172a' }}>{r.test_name}</div>
                        <div style={{ fontSize: '11px', color: '#64748b' }}>Report #{r.report_id}</div>
                      </td>
                      <td style={{ fontSize: '13px', color: '#334155', maxWidth: '240px' }}>
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {r.result}
                        </div>
                      </td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{r.report_date}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Hospital Help & Contacts Banner */}
      <div style={{
        background: '#f8fafc',
        border: '1px solid #e2e8f0',
        borderRadius: '12px',
        padding: '18px 22px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px',
      }}>
        <div>
          <h4 style={{ fontSize: '14.5px', fontWeight: '700', color: '#0f172a' }}>
            Need Medical Assistance or Have Inquiries?
          </h4>
          <p style={{ fontSize: '13px', color: '#64748b', marginTop: '2px' }}>
            Our 24x7 Emergency helpline is ready to assist you. Central Hotline: <strong>+91 98201 00100</strong>
          </p>
        </div>
        <button
          className="btn btn-secondary btn-sm"
          onClick={() => onNavigate('patient-hospital-info')}
        >
          View Hospital Information & Timings
        </button>
      </div>
    </div>
  );
}
