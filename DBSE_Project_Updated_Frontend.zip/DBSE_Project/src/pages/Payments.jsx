import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  TrashIcon,
  PaymentIcon,
} from '../components/Icons';

export default function Payments() {
  const [payments, setPayments] = useState([]);
  const [bills, setBills] = useState([]);
  const [search, setSearch] = useState('');
  const [filterMethod, setFilterMethod] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const initialFormData = {
    bill_id: '',
    amount_paid: '',
    payment_method: 'Credit Card',
    payment_date: new Date().toISOString().split('T')[0],
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [pList, bList] = await Promise.all([
      API.getPayments(),
      API.getBills(),
    ]);
    setPayments(pList);
    setBills(bList);

    if (bList.length) {
      setFormData((prev) => ({
        ...prev,
        bill_id: bList[0].bill_id,
        amount_paid: bList[0].total_amount,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setFormData({
      bill_id: bills[0]?.bill_id || '',
      amount_paid: bills[0]?.total_amount || '',
      payment_method: 'Credit Card',
      payment_date: new Date().toISOString().split('T')[0],
    });
    setIsModalOpen(true);
  };

  const handleBillSelect = (billId) => {
    const selected = bills.find((b) => Number(b.bill_id) === Number(billId));
    setFormData({
      ...formData,
      bill_id: billId,
      amount_paid: selected ? selected.total_amount : '',
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const billObj = bills.find((b) => Number(b.bill_id) === Number(formData.bill_id));
    const payload = {
      ...formData,
      bill_id: Number(formData.bill_id),
      patient_name: billObj ? billObj.patient_name : 'Patient',
      amount_paid: parseFloat(formData.amount_paid) || 0,
    };

    await API.addPayment(payload);

    // If bill amount paid matches or exceeds, optionally update bill status
    if (billObj) {
      await API.updateBill({
        ...billObj,
        payment_status: 'Paid',
      });
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this payment transaction entry?')) {
      await API.deletePayment(id);
      fetchData();
    }
  };

  const totalCollected = payments.reduce((acc, curr) => acc + (Number(curr.amount_paid) || 0), 0);

  const filteredPayments = payments.filter((p) => {
    const matchesSearch =
      p.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      String(p.bill_id).includes(search) ||
      String(p.payment_id).includes(search);

    const matchesMethod = filterMethod === 'All' || p.payment_method === filterMethod;
    return matchesSearch && matchesMethod;
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Payment Transactions History</h1>
          <p>Cashier transactions, digital settlements, card debits, and verified patient receipts.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Record Payment</span>
        </button>
      </div>

      {/* Summary Card */}
      <div className="stat-card" style={{ maxWidth: '320px', marginBottom: '24px' }}>
        <div className="stat-icon-wrapper" style={{ background: '#d1fae5', color: '#059669' }}>
          <PaymentIcon size={26} />
        </div>
        <div className="stat-card-info">
          <span className="stat-card-value" style={{ color: '#059669' }}>
            ₹{totalCollected.toLocaleString('en-IN')}
          </span>
          <span className="stat-card-label">Total Settled Collections</span>
        </div>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by payment ID, bill ID, or patient name..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterMethod}
            onChange={(e) => setFilterMethod(e.target.value)}
          >
            <option value="All">All Payment Methods</option>
            <option value="Credit Card">Credit Card</option>
            <option value="Cash">Cash</option>
            <option value="UPI / Online">UPI / Online</option>
            <option value="Insurance Claim">Insurance Claim</option>
            <option value="Net Banking">Net Banking</option>
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredPayments.length} transactions recorded
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Payment ID</th>
                <th>Bill Reference</th>
                <th>Patient Name</th>
                <th>Amount Paid</th>
                <th>Method</th>
                <th>Payment Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading payment records...
                  </td>
                </tr>
              ) : filteredPayments.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No payment transactions recorded.
                  </td>
                </tr>
              ) : (
                filteredPayments.map((p) => (
                  <tr key={p.payment_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{p.payment_id}</td>
                    <td>
                      <span className="badge badge-gray">Invoice #{p.bill_id}</span>
                    </td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>{p.patient_name}</td>
                    <td style={{ fontWeight: '700', color: '#059669', fontSize: '14px' }}>
                      +₹{Number(p.amount_paid).toLocaleString('en-IN')}
                    </td>
                    <td>
                      <span className="badge badge-primary">{p.payment_method}</span>
                    </td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{p.payment_date}</td>
                    <td style={{ textAlign: 'right' }}>
                      <button
                        className="btn-icon delete"
                        title="Delete record"
                        onClick={() => handleDelete(p.payment_id)}
                      >
                        <TrashIcon size={16} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Record Cash / Electronic Payment"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              Record Transaction
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Hospital Invoice Bill Reference *</label>
            <select
              className="form-select"
              value={formData.bill_id}
              onChange={(e) => handleBillSelect(e.target.value)}
              required
            >
              {bills.map((b) => (
                <option key={b.bill_id} value={b.bill_id}>
                  Invoice #{b.bill_id} - {b.patient_name} (₹{Number(b.total_amount).toLocaleString('en-IN')} - Status: {b.payment_status})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Amount Paid (₹) *</label>
            <input
              type="number"
              step="0.01"
              min="0"
              className="form-input"
              value={formData.amount_paid}
              onChange={(e) => setFormData({ ...formData, amount_paid: e.target.value })}
              placeholder="0.00"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Payment Method *</label>
            <select
              className="form-select"
              value={formData.payment_method}
              onChange={(e) => setFormData({ ...formData, payment_method: e.target.value })}
            >
              <option value="Credit Card">Credit Card</option>
              <option value="Cash">Cash</option>
              <option value="UPI / Online">UPI / Online</option>
              <option value="Insurance Claim">Insurance Claim</option>
              <option value="Net Banking">Net Banking</option>
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Payment Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.payment_date}
              onChange={(e) => setFormData({ ...formData, payment_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>
    </div>
  );
}
