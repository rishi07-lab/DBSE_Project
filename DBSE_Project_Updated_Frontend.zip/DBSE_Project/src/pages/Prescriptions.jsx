import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  TrashIcon,
  EyeIcon,
  PrinterIcon,
  ActivityIcon,
} from '../components/Icons';

export default function Prescriptions() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [medicines, setMedicines] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState(null);

  // Form State
  const initialFormData = {
    patient_id: '',
    doctor_id: '',
    medicine_id: '',
    dosage: '1 tablet daily after meals',
    duration: '14 Days',
    prescription_date: new Date().toISOString().split('T')[0],
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [pList, patList, docList, medList] = await Promise.all([
      API.getPrescriptions(),
      API.getPatients(),
      API.getDoctors(),
      API.getMedicines(),
    ]);
    setPrescriptions(pList);
    setPatients(patList);
    setDoctors(docList);
    setMedicines(medList);

    if (patList.length && docList.length && medList.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: patList[0].patient_id,
        doctor_id: docList[0].doctor_id,
        medicine_id: medList[0].medicine_id,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setFormData({
      patient_id: patients[0]?.patient_id || '',
      doctor_id: doctors[0]?.doctor_id || '',
      medicine_id: medicines[0]?.medicine_id || '',
      dosage: '1 tablet twice daily after meals',
      duration: '7 Days',
      prescription_date: new Date().toISOString().split('T')[0],
    });
    setIsAddModalOpen(true);
  };

  const handleOpenView = (p) => {
    setSelectedPrescription(p);
    setIsViewModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const docObj = doctors.find((d) => Number(d.doctor_id) === Number(formData.doctor_id));
    const medObj = medicines.find((m) => Number(m.medicine_id) === Number(formData.medicine_id));

    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Unknown Patient',
      doctor_id: Number(formData.doctor_id),
      doctor_name: docObj ? docObj.name : 'Attending Physician',
      medicine_id: Number(formData.medicine_id),
      // Demonstrates the SQL JOIN effect requirement: obtaining medicine_name and expiry_date from medicines table
      medicine_name: medObj ? medObj.medicine_name : 'Prescribed Formulation',
      expiry_date: medObj ? medObj.expiry_date : 'N/A',
    };

    await API.addPrescription(payload);
    setIsAddModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this prescription record?')) {
      await API.deletePrescription(id);
      fetchData();
    }
  };

  // Medicine details when selected in modal
  const selectedMedObj = medicines.find(
    (m) => Number(m.medicine_id) === Number(formData.medicine_id)
  );

  const filteredPrescriptions = prescriptions.filter((p) => {
    return (
      p.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      p.doctor_name?.toLowerCase().includes(search.toLowerCase()) ||
      p.medicine_name?.toLowerCase().includes(search.toLowerCase()) ||
      p.dosage?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Prescriptions Management</h1>
          <p>Electronic medical prescriptions, dosage schedules, and drug dispensing verification.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Issue New Prescription</span>
        </button>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '440px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search by patient, doctor, medicine, or dosage..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          Showing {filteredPrescriptions.length} of {prescriptions.length} prescriptions
        </div>
      </div>

      {/* Table */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Rx ID</th>
                <th>Patient</th>
                <th>Prescribing Doctor</th>
                <th>Medicine Formulation (JOIN)</th>
                <th>Batch Expiry (JOIN)</th>
                <th>Dosage Instructions</th>
                <th>Duration</th>
                <th>Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading prescriptions...
                  </td>
                </tr>
              ) : filteredPrescriptions.length === 0 ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No prescriptions found.
                  </td>
                </tr>
              ) : (
                filteredPrescriptions.map((p) => (
                  <tr key={p.prescription_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{p.prescription_id}</td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>{p.patient_name}</td>
                    <td style={{ color: '#475569' }}>{p.doctor_name}</td>
                    <td>
                      <div style={{ fontWeight: '600' }}>{p.medicine_name}</div>
                      <div style={{ fontSize: '11px', color: '#64748b' }}>Med ID: #{p.medicine_id}</div>
                    </td>
                    <td>
                      <span className="badge badge-gray">{p.expiry_date || 'N/A'}</span>
                    </td>
                    <td>
                      <span className="badge badge-primary">{p.dosage}</span>
                    </td>
                    <td style={{ fontWeight: '600', color: '#334155' }}>{p.duration}</td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon"
                          title="Print / View Slip"
                          onClick={() => handleOpenView(p)}
                        >
                          <EyeIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete"
                          onClick={() => handleDelete(p.prescription_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Prescription Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Issue New Medical Prescription"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsAddModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              Issue Prescription
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (#{p.patient_id}) - {p.gender}, {p.blood_group}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Consultant Doctor *</label>
            <select
              className="form-select"
              value={formData.doctor_id}
              onChange={(e) => setFormData({ ...formData, doctor_id: e.target.value })}
              required
            >
              {doctors.map((d) => (
                <option key={d.doctor_id} value={d.doctor_id}>
                  {d.name} ({d.specialization_name})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Medicine Formulation (from Inventory) *</label>
            <select
              className="form-select"
              value={formData.medicine_id}
              onChange={(e) => setFormData({ ...formData, medicine_id: e.target.value })}
              required
            >
              {medicines.map((m) => (
                <option key={m.medicine_id} value={m.medicine_id}>
                  {m.medicine_name} - In Stock: {m.quantity} | Expiry: {m.expiry_date}
                </option>
              ))}
            </select>
            {selectedMedObj && (
              <div style={{ fontSize: '12px', color: '#0284c7', marginTop: '4px' }}>
                Selected: <strong>{selectedMedObj.medicine_name}</strong> | Batch Expiry:{' '}
                <strong>{selectedMedObj.expiry_date}</strong> | Stock Available:{' '}
                <strong>{selectedMedObj.quantity} units</strong>
              </div>
            )}
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Dosage Instructions *</label>
            <input
              type="text"
              className="form-input"
              value={formData.dosage}
              onChange={(e) => setFormData({ ...formData, dosage: e.target.value })}
              placeholder="e.g. 1 tablet twice daily after meals"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Course Duration *</label>
            <input
              type="text"
              className="form-input"
              value={formData.duration}
              onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
              placeholder="e.g. 7 Days, 30 Days"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Prescription Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.prescription_date}
              onChange={(e) => setFormData({ ...formData, prescription_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>

      {/* Printable Prescription Slip Modal */}
      {selectedPrescription && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title="Hospital Prescription Slip"
          maxWidth="680px"
          footer={
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>
                Close
              </button>
              <button 
                className="btn btn-primary"
                onClick={() => window.print()}
              >
                <PrinterIcon size={16} />
                <span>Print Prescription</span>
              </button>
            </div>
          }
        >
          <div className="medical-slip">
            <div className="slip-header">
              <div>
                <div className="slip-title">CarePulse Memorial Hospital</div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  Central Outpatient Clinical Department • Phone: +91 98201 00100
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontWeight: '700', color: '#0f172a' }}>
                  Rx #{selectedPrescription.prescription_id}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  Date: {selectedPrescription.prescription_date}
                </div>
              </div>
            </div>

            <div className="slip-info-grid">
              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PATIENT NAME</span>
                <div style={{ fontSize: '15px', fontWeight: '700', color: '#0f172a' }}>
                  {selectedPrescription.patient_name}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedPrescription.patient_id}</div>
              </div>

              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PRESCRIBING DOCTOR</span>
                <div style={{ fontSize: '15px', fontWeight: '700', color: '#0284c7' }}>
                  {selectedPrescription.doctor_name}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>Doctor ID: #{selectedPrescription.doctor_id}</div>
              </div>
            </div>

            <div className="rx-symbol">℞</div>

            <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0', marginBottom: '24px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <h4 style={{ fontSize: '16px', fontWeight: '800', color: '#0f172a' }}>
                    {selectedPrescription.medicine_name}
                  </h4>
                  <div style={{ fontSize: '12.5px', color: '#475569', marginTop: '4px' }}>
                    Batch Expiry: <strong>{selectedPrescription.expiry_date}</strong> • Medicine ID: #{selectedPrescription.medicine_id}
                  </div>
                </div>
                <span className="badge badge-success" style={{ fontSize: '13px', padding: '6px 14px' }}>
                  Course: {selectedPrescription.duration}
                </span>
              </div>

              <div style={{ marginTop: '14px', paddingTop: '12px', borderTop: '1px dashed #cbd5e1' }}>
                <span style={{ fontSize: '12px', fontWeight: '700', color: '#64748b' }}>DIRECTIONS FOR USE:</span>
                <p style={{ fontSize: '14px', fontWeight: '600', color: '#0284c7', marginTop: '2px' }}>
                  {selectedPrescription.dosage}
                </p>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '40px' }}>
              <div style={{ textAlign: 'center', minWidth: '180px' }}>
                <div style={{ borderBottom: '1px solid #94a3b8', height: '30px', marginBottom: '6px' }} />
                <div style={{ fontSize: '12px', fontWeight: '600', color: '#475569' }}>
                  {selectedPrescription.doctor_name}
                </div>
                <div style={{ fontSize: '11px', color: '#94a3b8' }}>Authorized Medical Signature</div>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
