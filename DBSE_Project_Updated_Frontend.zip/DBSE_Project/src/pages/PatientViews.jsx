import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PrescriptionIcon,
  MedicalRecordIcon,
  LabReportIcon,
  BillIcon,
  MedicineIcon,
  EyeIcon,
  PrinterIcon,
  ActivityIcon,
} from '../components/Icons';

export default function PatientViews({ viewType, user }) {
  const patientId = user?.patient_id || 1;

  const [patient, setPatient] = useState(null);
  const [prescriptions, setPrescriptions] = useState([]);
  const [medicalRecords, setMedicalRecords] = useState([]);
  const [labReports, setLabReports] = useState([]);
  const [bills, setBills] = useState([]);
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);

  // Modal states for printing/viewing
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [selectedReport, setSelectedReport] = useState(null);
  const [selectedBill, setSelectedBill] = useState(null);

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      const [allPatients, allPresc, allRecords, allReports, allBills, allPayments] = await Promise.all([
        API.getPatients(),
        API.getPrescriptions(),
        API.getMedicalRecords(),
        API.getLabReports(),
        API.getBills(),
        API.getPayments(),
      ]);

      const currentPatient = allPatients.find((p) => Number(p.patient_id) === Number(patientId)) || {
        patient_id: 1,
        name: 'Ramesh Kumar Verma',
        email: 'patient@hospital.com',
        phone: '+91 98201 11223',
        date_of_birth: '1978-05-14',
        age: 48,
        gender: 'Male',
        blood_group: 'B+',
        city: 'Mumbai',
        address: 'Flat 402, Shanti Niketan, Andheri West, Mumbai, Maharashtra 400058',
        emergency_contact: 'Sunita Verma (Spouse) +91 98201 11224',
        medical_history: 'Primary Hypertension, Type 2 Diabetes (5 years)',
      };

      setPatient(currentPatient);
      setPrescriptions(allPresc.filter((p) => Number(p.patient_id) === Number(patientId)));
      setMedicalRecords(allRecords.filter((m) => Number(m.patient_id) === Number(patientId)));
      setLabReports(allReports.filter((r) => Number(r.patient_id) === Number(patientId)));
      setBills(allBills.filter((b) => Number(b.patient_id) === Number(patientId)));
      setPayments(allPayments.filter((p) => p.patient_name?.toLowerCase().includes(currentPatient.name?.toLowerCase())));
      setLoading(false);
    }
    loadData();
  }, [patientId]);

  if (loading) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading your medical records...
        </div>
      </div>
    );
  }

  // 1. My Profile View
  if (viewType === 'patient-profile') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Patient Profile</h1>
            <p>Personal registration details, demographic dossier, and emergency contact record.</p>
          </div>
        </div>

        <div className="table-card" style={{ maxWidth: '780px', padding: '28px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px', borderBottom: '1px solid #e2e8f0', paddingBottom: '24px', marginBottom: '24px' }}>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: 'linear-gradient(135deg, #0284c7, #0d9488)',
              color: 'white',
              fontSize: '26px',
              fontWeight: '800',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              {patient.name.charAt(0)}
            </div>
            <div>
              <h2 style={{ fontSize: '20px', fontWeight: '800', color: '#0f172a' }}>{patient.name}</h2>
              <div style={{ fontSize: '13px', color: '#64748b', marginTop: '2px' }}>
                Patient ID: <strong>#{patient.patient_id}</strong> • Blood Group: <strong style={{ color: '#0284c7' }}>{patient.blood_group}</strong> • Age: <strong>{patient.age || '48'} Yrs</strong>
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '18px', fontSize: '14px' }}>
            <div>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Email Address</span>
              <div style={{ fontWeight: '600', marginTop: '3px' }}>{patient.email}</div>
            </div>
            <div>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Phone Number</span>
              <div style={{ fontWeight: '600', marginTop: '3px' }}>{patient.phone}</div>
            </div>
            <div>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Date of Birth</span>
              <div style={{ fontWeight: '600', marginTop: '3px' }}>{patient.date_of_birth}</div>
            </div>
            <div>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Gender & Blood Group</span>
              <div style={{ fontWeight: '600', marginTop: '3px' }}>{patient.gender} ({patient.blood_group})</div>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Residential Address</span>
              <div style={{ fontWeight: '600', marginTop: '3px' }}>{patient.address}</div>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Emergency Contact</span>
              <div style={{ fontWeight: '700', color: '#b45309', marginTop: '3px' }}>{patient.emergency_contact}</div>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <span style={{ color: '#64748b', fontSize: '12px', fontWeight: '700', textTransform: 'uppercase' }}>Known Medical Conditions / History</span>
              <div style={{ marginTop: '3px', background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                {patient.medical_history || 'None recorded'}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // 2. My Medical Records View
  if (viewType === 'patient-records') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Clinical Medical Records</h1>
            <p>Diagnoses, reported symptoms, and treatment plans documented by attending consultants.</p>
          </div>
        </div>

        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Record Date</th>
                  <th>Clinical Diagnosis</th>
                  <th>Reported Symptoms</th>
                  <th>Prescribed Therapy</th>
                  <th>Physician Advice</th>
                </tr>
              </thead>
              <tbody>
                {medicalRecords.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                      No clinical records found.
                    </td>
                  </tr>
                ) : (
                  medicalRecords.map((r) => (
                    <tr key={r.record_id}>
                      <td style={{ color: '#64748b', fontSize: '12.5px', whiteSpace: 'nowrap' }}>{r.record_date}</td>
                      <td>
                        <span className="badge badge-primary" style={{ fontWeight: '700' }}>
                          {r.diagnosis}
                        </span>
                      </td>
                      <td style={{ color: '#475569', fontSize: '13px' }}>{r.symptoms}</td>
                      <td style={{ color: '#059669', fontWeight: '500', fontSize: '13px' }}>{r.treatment}</td>
                      <td style={{ color: '#475569', fontSize: '13px', fontStyle: 'italic' }}>"{r.doctor_notes}"</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // 3. My Prescriptions View
  if (viewType === 'patient-prescriptions') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Prescriptions</h1>
            <p>Active pharmaceutical prescriptions issued by hospital specialist doctors.</p>
          </div>
        </div>

        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Rx ID</th>
                  <th>Prescribed Medicine</th>
                  <th>Prescribing Doctor</th>
                  <th>Dosage Schedule</th>
                  <th>Duration</th>
                  <th>Prescribed Date</th>
                  <th style={{ textAlign: 'right' }}>Prescription Slip</th>
                </tr>
              </thead>
              <tbody>
                {prescriptions.length === 0 ? (
                  <tr>
                    <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                      No active prescriptions on file.
                    </td>
                  </tr>
                ) : (
                  prescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td style={{ color: '#0284c7', fontWeight: '700' }}>#{p.prescription_id}</td>
                      <td>
                        <div style={{ fontWeight: '700', color: '#0f172a' }}>{p.medicine_name}</div>
                      </td>
                      <td style={{ color: '#475569' }}>{p.doctor_name}</td>
                      <td><span className="badge badge-primary">{p.dosage}</span></td>
                      <td style={{ fontWeight: '600', color: '#334155' }}>{p.duration}</td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className="btn btn-sm btn-secondary"
                          onClick={() => setSelectedPrescription(p)}
                        >
                          <PrinterIcon size={14} />
                          <span>View & Print Slip</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Prescription Slip Modal */}
        {selectedPrescription && (
          <Modal
            isOpen={!!selectedPrescription}
            onClose={() => setSelectedPrescription(null)}
            title="Hospital Prescription Slip"
            maxWidth="660px"
            footer={
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <button className="btn btn-secondary" onClick={() => setSelectedPrescription(null)}>
                  Close
                </button>
                <button className="btn btn-primary" onClick={() => window.print()}>
                  <PrinterIcon size={16} />
                  <span>Print Prescription</span>
                </button>
              </div>
            }
          >
            <div className="medical-slip">
              <div className="slip-header">
                <div>
                  <div className="slip-title">CarePulse Multi-Speciality Hospital</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>
                    Central Medical Outpatient Clinic • Helpline: +91 98201 00100
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: '800', color: '#0f172a' }}>Rx #{selectedPrescription.prescription_id}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {selectedPrescription.prescription_date}</div>
                </div>
              </div>

              <div className="slip-info-grid">
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PATIENT</span>
                  <div style={{ fontSize: '15px', fontWeight: '700' }}>{selectedPrescription.patient_name}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedPrescription.patient_id}</div>
                </div>
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>CONSULTANT DOCTOR</span>
                  <div style={{ fontSize: '15px', fontWeight: '700', color: '#0284c7' }}>{selectedPrescription.doctor_name}</div>
                </div>
              </div>

              <div className="rx-symbol">℞</div>

              <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0', marginBottom: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <h4 style={{ fontSize: '16px', fontWeight: '800', color: '#0f172a' }}>
                      {selectedPrescription.medicine_name}
                    </h4>
                  </div>
                  <span className="badge badge-success" style={{ fontSize: '13px', padding: '4px 12px' }}>
                    Duration: {selectedPrescription.duration}
                  </span>
                </div>
                <div style={{ marginTop: '12px', paddingTop: '10px', borderTop: '1px dashed #cbd5e1' }}>
                  <span style={{ fontSize: '11px', fontWeight: '700', color: '#64748b' }}>DOSAGE INSTRUCTIONS:</span>
                  <p style={{ fontSize: '14px', fontWeight: '600', color: '#0284c7', marginTop: '2px' }}>
                    {selectedPrescription.dosage}
                  </p>
                </div>
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '30px' }}>
                <div style={{ textAlign: 'center', minWidth: '180px' }}>
                  <div style={{ borderBottom: '1px solid #94a3b8', height: '26px', marginBottom: '4px' }} />
                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#334155' }}>{selectedPrescription.doctor_name}</div>
                  <div style={{ fontSize: '10px', color: '#94a3b8' }}>Authorized Medical Practitioner</div>
                </div>
              </div>
            </div>
          </Modal>
        )}
      </div>
    );
  }

  // 4. My Prescribed Medicines View (STRICTLY NO INVENTORY OR STOCK NUMBERS)
  if (viewType === 'patient-medicines') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Prescribed Medicines</h1>
            <p>Pharmaceutical medications prescribed for your ongoing treatment plan. (Inventory stock controls restricted).</p>
          </div>
        </div>

        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Medicine Name</th>
                  <th>Prescribing Doctor</th>
                  <th>Dosage Instructions</th>
                  <th>Course Duration</th>
                  <th>Prescribed Date</th>
                </tr>
              </thead>
              <tbody>
                {prescriptions.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                      No prescribed medications found.
                    </td>
                  </tr>
                ) : (
                  prescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td>
                        <div style={{ fontWeight: '700', color: '#0f172a', fontSize: '14px' }}>
                          {p.medicine_name}
                        </div>
                      </td>
                      <td style={{ color: '#0284c7', fontWeight: '500' }}>{p.doctor_name}</td>
                      <td>
                        <span className="badge badge-primary">{p.dosage}</span>
                      </td>
                      <td style={{ fontWeight: '600', color: '#334155' }}>{p.duration}</td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  // 5. My Laboratory Reports View
  if (viewType === 'patient-lab-reports') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Pathology & Laboratory Reports</h1>
            <p>Official diagnostic test findings, clinical impressions, and authorized pathologist reports.</p>
          </div>
        </div>

        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Report #</th>
                  <th>Investigation Name</th>
                  <th>Referring Doctor</th>
                  <th>Clinical Result Summary</th>
                  <th>Report Date</th>
                  <th style={{ textAlign: 'right' }}>Diagnostic Report</th>
                </tr>
              </thead>
              <tbody>
                {labReports.length === 0 ? (
                  <tr>
                    <td colSpan="6" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                      No diagnostic laboratory reports on file.
                    </td>
                  </tr>
                ) : (
                  labReports.map((r) => (
                    <tr key={r.report_id}>
                      <td style={{ color: '#0284c7', fontWeight: '700' }}>#{r.report_id}</td>
                      <td style={{ fontWeight: '700', color: '#0f172a' }}>{r.test_name}</td>
                      <td style={{ color: '#475569' }}>{r.doctor_name}</td>
                      <td style={{ color: '#0369a1', fontWeight: '500', maxWidth: '260px' }}>
                        <div style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {r.result}
                        </div>
                      </td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{r.report_date}</td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className="btn btn-sm btn-secondary"
                          onClick={() => setSelectedReport(r)}
                        >
                          <EyeIcon size={14} />
                          <span>View Official Sheet</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Diagnostic Report Sheet Modal */}
        {selectedReport && (
          <Modal
            isOpen={!!selectedReport}
            onClose={() => setSelectedReport(null)}
            title="CarePulse Pathology Diagnostic Sheet"
            maxWidth="680px"
            footer={
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <button className="btn btn-secondary" onClick={() => setSelectedReport(null)}>
                  Close
                </button>
                <button className="btn btn-primary" onClick={() => window.print()}>
                  <PrinterIcon size={16} />
                  <span>Print Diagnostic Sheet</span>
                </button>
              </div>
            }
          >
            <div className="medical-slip">
              <div className="slip-header">
                <div>
                  <div className="slip-title">CarePulse Pathology Laboratory</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>
                    NABL Accredited Diagnostic Center • License #LAB-IND-88192
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: '700', color: '#0f172a' }}>Report #{selectedReport.report_id}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {selectedReport.report_date}</div>
                </div>
              </div>

              <div className="slip-info-grid">
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PATIENT</span>
                  <div style={{ fontSize: '15px', fontWeight: '700' }}>{selectedReport.patient_name}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedReport.patient_id}</div>
                </div>
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>REFERRING CONSULTANT</span>
                  <div style={{ fontSize: '15px', fontWeight: '700', color: '#0284c7' }}>{selectedReport.doctor_name}</div>
                </div>
              </div>

              <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0', margin: '18px 0' }}>
                <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
                  INVESTIGATION
                </div>
                <div style={{ fontSize: '16px', fontWeight: '800', color: '#0f172a', marginTop: '2px' }}>
                  {selectedReport.test_name}
                </div>

                <div style={{ marginTop: '14px', padding: '14px', background: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                  <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b' }}>OBSERVED FINDINGS / RESULTS</div>
                  <div style={{ fontSize: '14.5px', fontWeight: '700', color: '#0369a1', marginTop: '4px' }}>
                    {selectedReport.result}
                  </div>
                </div>

                {selectedReport.remarks && (
                  <div style={{ marginTop: '12px' }}>
                    <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b' }}>PATHOLOGIST IMPRESSION</div>
                    <div style={{ fontSize: '13px', color: '#334155', marginTop: '3px' }}>
                      {selectedReport.remarks}
                    </div>
                  </div>
                )}
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '24px' }}>
                <div style={{ textAlign: 'center', minWidth: '180px' }}>
                  <div style={{ borderBottom: '1px solid #94a3b8', height: '24px', marginBottom: '4px' }} />
                  <div style={{ fontSize: '12px', fontWeight: '700', color: '#334155' }}>Dr. Kavita Reddy (MD Pathology)</div>
                  <div style={{ fontSize: '10px', color: '#94a3b8' }}>Chief Consultant Pathologist</div>
                </div>
              </div>
            </div>
          </Modal>
        )}
      </div>
    );
  }

  // 6. My Bills & Payments View (INR ₹)
  if (viewType === 'patient-bills') {
    return (
      <div className="page-container">
        <div className="page-header">
          <div>
            <h1>My Invoices & Billing Receipts</h1>
            <p>Itemized hospital bills, consultation fees, diagnostic payments, and payment history in ₹.</p>
          </div>
        </div>

        <div className="table-card">
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Date</th>
                  <th>Total Amount (₹)</th>
                  <th>Payment Status</th>
                  <th style={{ textAlign: 'right' }}>Invoice Receipt</th>
                </tr>
              </thead>
              <tbody>
                {bills.length === 0 ? (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', padding: '30px', color: '#94a3b8' }}>
                      No billing invoices on record.
                    </td>
                  </tr>
                ) : (
                  bills.map((b) => (
                    <tr key={b.bill_id}>
                      <td style={{ color: '#0284c7', fontWeight: '700' }}>#{b.bill_id}</td>
                      <td>{b.bill_date}</td>
                      <td style={{ fontWeight: '700', fontSize: '14.5px', color: '#0f172a' }}>
                        ₹{Number(b.total_amount).toLocaleString('en-IN')}
                      </td>
                      <td>
                        <span className={`badge ${b.payment_status === 'Paid' ? 'badge-success' : 'badge-danger'}`}>
                          {b.payment_status === 'Paid' ? '✓ Paid' : '● Unpaid'}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className="btn btn-sm btn-secondary"
                          onClick={() => setSelectedBill(b)}
                        >
                          <PrinterIcon size={14} />
                          <span>View Receipt</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Invoice Modal */}
        {selectedBill && (
          <Modal
            isOpen={!!selectedBill}
            onClose={() => setSelectedBill(null)}
            title="Hospital Official Invoice Receipt"
            maxWidth="650px"
            footer={
              <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                <button className="btn btn-secondary" onClick={() => setSelectedBill(null)}>
                  Close
                </button>
                <button className="btn btn-primary" onClick={() => window.print()}>
                  <PrinterIcon size={16} />
                  <span>Print Receipt</span>
                </button>
              </div>
            }
          >
            <div className="medical-slip">
              <div className="slip-header">
                <div>
                  <div className="slip-title">CarePulse Hospital</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>
                    Billing & Accounts Division • GSTIN: #27AAAAA0000A1Z5
                  </div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontWeight: '800', fontSize: '17px' }}>INVOICE #{selectedBill.bill_id}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Date: {selectedBill.bill_date}</div>
                </div>
              </div>

              <div className="slip-info-grid">
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>BILLED TO</span>
                  <div style={{ fontSize: '15px', fontWeight: '700' }}>{selectedBill.patient_name}</div>
                  <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedBill.patient_id}</div>
                </div>
                <div>
                  <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PAYMENT STATUS</span>
                  <div style={{ marginTop: '4px' }}>
                    <span className={`badge ${selectedBill.payment_status === 'Paid' ? 'badge-success' : 'badge-danger'}`}>
                      {selectedBill.payment_status === 'Paid' ? '✓ Settled / Paid' : '● Due / Unpaid'}
                    </span>
                  </div>
                </div>
              </div>

              <div style={{ margin: '20px 0', borderTop: '1px solid #e2e8f0', borderBottom: '1px solid #e2e8f0', padding: '14px 0' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', padding: '6px 0' }}>
                  <span>Clinical Diagnostics & Inpatient / Outpatient Services:</span>
                  <span style={{ fontWeight: '700' }}>₹{Number(selectedBill.total_amount).toLocaleString('en-IN')}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '16px', fontWeight: '800', borderTop: '2px solid #0f172a', paddingTop: '10px', marginTop: '10px' }}>
                  <span>TOTAL AMOUNT:</span>
                  <span style={{ color: '#0284c7' }}>₹{Number(selectedBill.total_amount).toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div style={{ textAlign: 'center', color: '#94a3b8', fontSize: '11px' }}>
                Thank you for choosing CarePulse Hospital for your healthcare needs.
              </div>
            </div>
          </Modal>
        )}
      </div>
    );
  }

  // 7. Hospital Information View
  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>CarePulse Hospital Information & Services</h1>
          <p>Key emergency lines, hospital OPD hours, clinical facilities, and patient care contacts.</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '20px' }}>
        <div className="table-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '12px' }}>
            🚨 24x7 Emergency Helplines
          </h3>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '13.5px' }}>
            <li>Emergency Trauma Room: <strong style={{ color: '#dc2626' }}>+91 98201 00100</strong></li>
            <li>Cardiac Ambulance Hotline: <strong style={{ color: '#dc2626' }}>108 / +91 98201 00108</strong></li>
            <li>Blood Bank Assistance: <strong>+91 98201 00115</strong></li>
            <li>24x7 Pharmacy Desk: <strong>+91 98201 00120</strong></li>
          </ul>
        </div>

        <div className="table-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '12px' }}>
            ⏰ OPD & Visiting Hours
          </h3>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '10px', fontSize: '13.5px' }}>
            <li>Morning OPD: <strong>08:30 AM - 01:30 PM</strong></li>
            <li>Evening OPD: <strong>04:30 PM - 08:30 PM</strong></li>
            <li>Inpatient Visiting: <strong>05:00 PM - 07:00 PM</strong></li>
            <li>Emergency & Casualty: <strong>24 Hours Open (All 7 Days)</strong></li>
          </ul>
        </div>

        <div className="table-card" style={{ padding: '22px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '12px' }}>
            📍 Location & Campus
          </h3>
          <p style={{ fontSize: '13.5px', color: '#475569', lineHeight: '1.6' }}>
            CarePulse Multi-Speciality Medical Center<br />
            Opposite Link Road Metro Station, Andheri West,<br />
            Mumbai, Maharashtra 400053.<br />
            Email: <strong>helpdesk@hospital.com</strong>
          </p>
        </div>
      </div>
    </div>
  );
}
