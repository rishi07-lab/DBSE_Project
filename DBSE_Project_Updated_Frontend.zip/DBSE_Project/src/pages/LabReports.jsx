import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  EyeIcon,
  PrinterIcon,
} from '../components/Icons';

export default function LabReports() {
  const [reports, setReports] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [tests, setTests] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modals
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedReport, setSelectedReport] = useState(null);

  const initialFormData = {
    patient_id: '',
    test_id: '',
    doctor_id: '',
    result: '',
    remarks: '',
    report_date: new Date().toISOString().split('T')[0],
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [repList, patList, docList, testList] = await Promise.all([
      API.getLabReports(),
      API.getPatients(),
      API.getDoctors(),
      API.getLabTests(),
    ]);
    setReports(repList);
    setPatients(patList);
    setDoctors(docList);
    setTests(testList);

    if (patList.length && docList.length && testList.length) {
      setFormData((prev) => ({
        ...prev,
        patient_id: patList[0].patient_id,
        doctor_id: docList[0].doctor_id,
        test_id: testList[0].test_id,
      }));
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData({
      patient_id: patients[0]?.patient_id || '',
      test_id: tests[0]?.test_id || '',
      doctor_id: doctors[0]?.doctor_id || '',
      result: '',
      remarks: '',
      report_date: new Date().toISOString().split('T')[0],
    });
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rep) => {
    setIsEditMode(true);
    setSelectedReport(rep);
    setFormData({
      patient_id: rep.patient_id || '',
      test_id: rep.test_id || '',
      doctor_id: rep.doctor_id || '',
      result: rep.result || '',
      remarks: rep.remarks || '',
      report_date: rep.report_date || '',
    });
    setIsModalOpen(true);
  };

  const handleOpenView = (rep) => {
    setSelectedReport(rep);
    setIsViewModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const patObj = patients.find((p) => Number(p.patient_id) === Number(formData.patient_id));
    const docObj = doctors.find((d) => Number(d.doctor_id) === Number(formData.doctor_id));
    const testObj = tests.find((t) => Number(t.test_id) === Number(formData.test_id));

    const payload = {
      ...formData,
      patient_id: Number(formData.patient_id),
      patient_name: patObj ? patObj.name : 'Patient',
      doctor_id: Number(formData.doctor_id),
      doctor_name: docObj ? docObj.name : 'Physician',
      test_id: Number(formData.test_id),
      test_name: testObj ? testObj.test_name : 'Diagnostic Test',
    };

    if (isEditMode && selectedReport) {
      await API.updateLabReport({
        ...selectedReport,
        ...payload,
      });
    } else {
      await API.addLabReport(payload);
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this pathology report?')) {
      await API.deleteLabReport(id);
      fetchData();
    }
  };

  const filteredReports = reports.filter((r) => {
    return (
      r.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.test_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.doctor_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.result?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Patient Pathology & Lab Reports</h1>
          <p>Clinical investigation findings, biochemical parameters, and consultant pathologist remarks.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Upload New Lab Report</span>
        </button>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '440px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search by patient, test name, doctor, or result..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredReports.length} reports logged
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Report ID</th>
                <th>Patient</th>
                <th>Diagnostic Investigation</th>
                <th>Referring Physician</th>
                <th>Clinical Finding / Result</th>
                <th>Date</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading laboratory reports...
                  </td>
                </tr>
              ) : filteredReports.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No lab reports found.
                  </td>
                </tr>
              ) : (
                filteredReports.map((r) => (
                  <tr key={r.report_id}>
                    <td style={{ color: '#0284c7', fontWeight: '700' }}>#{r.report_id}</td>
                    <td style={{ fontWeight: '700', color: '#0f172a' }}>{r.patient_name}</td>
                    <td>
                      <span className="badge badge-purple">{r.test_name}</span>
                    </td>
                    <td style={{ color: '#475569' }}>{r.doctor_name}</td>
                    <td style={{ maxWidth: '240px' }}>
                      <div style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap', fontWeight: '500' }}>
                        {r.result}
                      </div>
                    </td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{r.report_date}</td>
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '4px' }}>
                        <button
                          className="btn-icon"
                          title="View Official Report"
                          onClick={() => handleOpenView(r)}
                        >
                          <EyeIcon size={16} />
                        </button>
                        <button
                          className="btn-icon edit"
                          title="Edit Report"
                          onClick={() => handleOpenEdit(r)}
                        >
                          <EditIcon size={16} />
                        </button>
                        <button
                          className="btn-icon delete"
                          title="Delete Report"
                          onClick={() => handleDelete(r.report_id)}
                        >
                          <TrashIcon size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Laboratory Report' : 'File New Laboratory Test Report'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update Report' : 'Publish Report'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Patient *</label>
            <select
              className="form-select"
              value={formData.patient_id}
              onChange={(e) => setFormData({ ...formData, patient_id: e.target.value })}
              required
            >
              {patients.map((p) => (
                <option key={p.patient_id} value={p.patient_id}>
                  {p.name} (#{p.patient_id}) - {p.gender}, {p.blood_group}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Test Investigation *</label>
            <select
              className="form-select"
              value={formData.test_id}
              onChange={(e) => setFormData({ ...formData, test_id: e.target.value })}
              required
            >
              {tests.map((t) => (
                <option key={t.test_id} value={t.test_id}>
                  {t.test_name} (₹{Number(t.test_cost).toLocaleString('en-IN')})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Referring Doctor *</label>
            <select
              className="form-select"
              value={formData.doctor_id}
              onChange={(e) => setFormData({ ...formData, doctor_id: e.target.value })}
              required
            >
              {doctors.map((d) => (
                <option key={d.doctor_id} value={d.doctor_id}>
                  {d.name} ({d.specialization_name})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Quantitative Finding / Result Value *</label>
            <textarea
              className="form-textarea"
              value={formData.result}
              onChange={(e) => setFormData({ ...formData, result: e.target.value })}
              placeholder="e.g. Total Cholesterol: 235 mg/dL (Elevated), LDL: 155 mg/dL"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Pathologist Remarks / Impression</label>
            <textarea
              className="form-textarea"
              value={formData.remarks}
              onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
              placeholder="Clinical correlation and recommendations..."
            />
          </div>

          <div className="form-group">
            <label className="form-label">Report Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.report_date}
              onChange={(e) => setFormData({ ...formData, report_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>

      {/* Official Diagnostic Report Modal */}
      {selectedReport && (
        <Modal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          title="Official Pathology Report"
          maxWidth="680px"
          footer={
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <button className="btn btn-secondary" onClick={() => setIsViewModalOpen(false)}>
                Close
              </button>
              <button className="btn btn-primary" onClick={() => window.print()}>
                <PrinterIcon size={16} />
                <span>Print Diagnostic Sheet</span>
              </button>
            </div>
          }
        >
          <div className="medical-slip">
            <div className="slip-header">
              <div>
                <div className="slip-title">CarePulse Pathology Laboratory</div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  NABL Accredited Diagnostic Center • License #LAB-88192
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontWeight: '700', color: '#0f172a' }}>
                  Report #{selectedReport.report_id}
                </div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>
                  Date: {selectedReport.report_date}
                </div>
              </div>
            </div>

            <div className="slip-info-grid">
              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>PATIENT</span>
                <div style={{ fontSize: '15px', fontWeight: '700' }}>{selectedReport.patient_name}</div>
                <div style={{ fontSize: '12px', color: '#64748b' }}>Patient ID: #{selectedReport.patient_id}</div>
              </div>

              <div>
                <span style={{ color: '#64748b', fontSize: '11px', fontWeight: '700' }}>REFERRING DOCTOR</span>
                <div style={{ fontSize: '15px', fontWeight: '700', color: '#0284c7' }}>
                  {selectedReport.doctor_name}
                </div>
              </div>
            </div>

            <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '10px', border: '1px solid #e2e8f0', margin: '20px 0' }}>
              <div style={{ fontSize: '12px', fontWeight: '700', color: '#64748b', textTransform: 'uppercase' }}>
                INVESTIGATION PERFORMED
              </div>
              <div style={{ fontSize: '17px', fontWeight: '800', color: '#0f172a', marginTop: '2px' }}>
                {selectedReport.test_name}
              </div>

              <div style={{ marginTop: '16px', padding: '14px', background: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b' }}>OBSERVED FINDINGS / RESULTS</div>
                <div style={{ fontSize: '15px', fontWeight: '700', color: '#0369a1', marginTop: '4px' }}>
                  {selectedReport.result}
                </div>
              </div>

              {selectedReport.remarks && (
                <div style={{ marginTop: '14px' }}>
                  <div style={{ fontSize: '11px', fontWeight: '700', color: '#64748b' }}>PATHOLOGIST IMPRESSION & REMARKS</div>
                  <div style={{ fontSize: '13.5px', color: '#334155', marginTop: '3px' }}>
                    {selectedReport.remarks}
                  </div>
                </div>
              )}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '30px' }}>
              <div style={{ textAlign: 'center', minWidth: '180px' }}>
                <div style={{ borderBottom: '1px solid #94a3b8', height: '24px', marginBottom: '4px' }} />
                <div style={{ fontSize: '12px', fontWeight: '700', color: '#334155' }}>Chief Consultant Pathologist</div>
                <div style={{ fontSize: '10px', color: '#94a3b8' }}>CarePulse Diagnostic Labs</div>
              </div>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
