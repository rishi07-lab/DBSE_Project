import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  SpecializationIcon,
} from '../components/Icons';

export default function Specializations() {
  const [specializations, setSpecializations] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedSpec, setSelectedSpec] = useState(null);
  const [specName, setSpecName] = useState('');

  const fetchData = async () => {
    setLoading(true);
    const [specs, docs] = await Promise.all([
      API.getSpecializations(),
      API.getDoctors(),
    ]);
    setSpecializations(specs);
    setDoctors(docs);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setSpecName('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (spec) => {
    setIsEditMode(true);
    setSelectedSpec(spec);
    setSpecName(spec.specialization_name);
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!specName.trim()) return;

    if (isEditMode && selectedSpec) {
      await API.updateSpecialization({
        ...selectedSpec,
        specialization_name: specName.trim(),
      });
    } else {
      await API.addSpecialization({
        specialization_name: specName.trim(),
      });
    }

    setIsModalOpen(false);
    fetchData();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to remove this medical specialization?')) {
      await API.deleteSpecialization(id);
      fetchData();
    }
  };

  const filteredSpecs = specializations.filter((s) =>
    s.specialization_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Medical Specializations & Departments</h1>
          <p>Clinical disciplines, specialized medical departments, and consultant staff counts.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Add Specialization</span>
        </button>
      </div>

      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '400px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search specializations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredSpecs.length} departments registered
        </div>
      </div>

      <div className="cards-grid">
        {loading ? (
          <div style={{ padding: '30px', color: '#64748b' }}>Loading specializations...</div>
        ) : filteredSpecs.map((spec) => {
          const docCount = doctors.filter(
            (d) => Number(d.specialization_id) === Number(spec.specialization_id)
          ).length;

          return (
            <div
              key={spec.specialization_id}
              className="table-card"
              style={{
                padding: '20px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
                <div
                  style={{
                    width: '46px',
                    height: '46px',
                    borderRadius: '10px',
                    background: '#e0f2fe',
                    color: '#0284c7',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <SpecializationIcon size={22} />
                </div>
                <div>
                  <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>
                    {spec.specialization_name}
                  </h3>
                  <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>
                    Dept ID: #{spec.specialization_id} •{' '}
                    <span style={{ color: '#0284c7', fontWeight: '600' }}>
                      {docCount} Specialist{docCount !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', gap: '6px' }}>
                <button
                  className="btn-icon edit"
                  title="Edit"
                  onClick={() => handleOpenEdit(spec)}
                >
                  <EditIcon size={16} />
                </button>
                <button
                  className="btn-icon delete"
                  title="Delete"
                  onClick={() => handleDelete(spec.specialization_id)}
                >
                  <TrashIcon size={16} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Department Specialization' : 'Add New Specialization'}
        maxWidth="480px"
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Update' : 'Add Specialization'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Specialization Department Name *</label>
            <input
              type="text"
              className="form-input"
              value={specName}
              onChange={(e) => setSpecName(e.target.value)}
              placeholder="e.g. Cardiology, Neurology, Pediatrics"
              required
              autoFocus
            />
          </div>
        </form>
      </Modal>
    </div>
  );
}
