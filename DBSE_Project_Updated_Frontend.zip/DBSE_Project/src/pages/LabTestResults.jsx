import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  CheckCircleIcon,
  ActivityIcon,
} from '../components/Icons';

export default function LabTestResults() {
  const [samples, setSamples] = useState([]);
  const [reports, setReports] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  // Modal for entering / updating results
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedSample, setSelectedSample] = useState(null);

  const initialFormData = {
    result_findings: '',
    reference_range: '',
    remarks: '',
    status: 'Completed',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    setLoading(true);
    const [sList, rList] = await Promise.all([
      API.getLabSamples(),
      API.getLabReports(),
    ]);
    setSamples(sList);
    setReports(rList);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleOpenEnterResult = (sample) => {
    setSelectedSample(sample);
    // Find if an existing report corresponds to this sample
    const existingRep = reports.find(
      (r) => Number(r.patient_id) === Number(sample.patient_id) && Number(r.test_id) === Number(sample.test_id)
    );

    setFormData({
      result_findings: existingRep ? existingRep.result : '',
      reference_range: 'Standard Pathology Reference Interval',
      remarks: existingRep ? existingRep.remarks : 'Specimen processed on automated clinical analyzer.',
      status: 'Completed',
    });
    setIsModalOpen(true);
  };

  const handleSubmitResult = async (e) => {
    e.preventDefault();
    if (!selectedSample) return;

    // 1. Update the sample collection status
    await API.updateLabSample({
      ...selectedSample,
      collection_status: formData.status,
    });

    // 2. Add or update official lab report so both Lab Reports and Patient portal reflect it
    const existingRep = reports.find(
      (r) => Number(r.patient_id) === Number(selectedSample.patient_id) && Number(r.test_id) === Number(selectedSample.test_id)
    );

    const reportPayload = {
      patient_id: selectedSample.patient_id,
      patient_name: selectedSample.patient_name,
      test_id: selectedSample.test_id,
      test_name: selectedSample.test_name,
      doctor_id: 1,
      doctor_name: 'Dr. Rajesh Sharma',
      result: formData.result_findings,
      remarks: formData.remarks,
      report_date: new Date().toISOString().split('T')[0],
      file_attachment: `${selectedSample.test_name.replace(/\s+/g, '_')}_Result.pdf (Verified Electronic Report)`,
    };

    if (existingRep) {
      await API.updateLabReport({
        ...existingRep,
        ...reportPayload,
      });
    } else {
      await API.addLabReport(reportPayload);
    }

    setIsModalOpen(false);
    fetchData();
  };

  const filteredSamples = samples.filter((s) => {
    return (
      s.sample_id?.toLowerCase().includes(search.toLowerCase()) ||
      s.patient_name?.toLowerCase().includes(search.toLowerCase()) ||
      s.test_name?.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Laboratory Test Results Entry</h1>
          <p>Input quantitative biochemical findings, reference range intervals, clinical pathologist observations, and sign-offs.</p>
        </div>
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-input-wrapper" style={{ maxWidth: '440px' }}>
          <span className="search-icon"><SearchIcon size={16} /></span>
          <input
            type="text"
            className="search-input"
            placeholder="Search pending specimen results by patient or test..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          {filteredSamples.length} investigations in workstation
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Sample ID</th>
                <th>Patient Name</th>
                <th>Investigation Test</th>
                <th>Sample Specimen</th>
                <th>Collection Timestamp</th>
                <th>Current Status</th>
                <th style={{ textAlign: 'right' }}>Result Entry</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading laboratory test results bench...
                  </td>
                </tr>
              ) : filteredSamples.length === 0 ? (
                <tr>
                  <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No laboratory samples found.
                  </td>
                </tr>
              ) : (
                filteredSamples.map((s) => {
                  const hasReport = reports.some(
                    (r) => Number(r.patient_id) === Number(s.patient_id) && Number(r.test_id) === Number(s.test_id)
                  );

                  return (
                    <tr key={s.sample_id}>
                      <td style={{ color: '#0284c7', fontWeight: '700' }}>{s.sample_id}</td>
                      <td style={{ fontWeight: '700', color: '#0f172a' }}>{s.patient_name}</td>
                      <td style={{ fontWeight: '600' }}>{s.test_name}</td>
                      <td>
                        <span className="badge badge-primary">{s.sample_type}</span>
                      </td>
                      <td style={{ color: '#475569', fontSize: '13px' }}>
                        {s.collection_date} {s.collection_time}
                      </td>
                      <td>
                        <span className={`badge ${
                          s.collection_status === 'Completed'
                            ? 'badge-success'
                            : s.collection_status === 'Processing'
                            ? 'badge-primary'
                            : 'badge-warning'
                        }`}>
                          {s.collection_status}
                        </span>
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <button
                          className={`btn btn-sm ${hasReport ? 'btn-secondary' : 'btn-primary'}`}
                          onClick={() => handleOpenEnterResult(s)}
                        >
                          <EditIcon size={14} />
                          <span>{hasReport ? 'Update Result' : 'Enter Result'}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Enter / Update Result Modal */}
      {selectedSample && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={`Biochemical Result Entry: ${selectedSample.sample_id}`}
          maxWidth="640px"
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={handleSubmitResult}>
                Commit & Sign-Off Result
              </button>
            </>
          }
        >
          <div style={{
            background: '#f8fafc',
            padding: '14px 18px',
            borderRadius: '10px',
            border: '1px solid #e2e8f0',
            marginBottom: '18px',
            fontSize: '13px',
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
              <div>Patient: <strong style={{ color: '#0f172a' }}>{selectedSample.patient_name}</strong> (#{selectedSample.patient_id})</div>
              <div>Specimen: <strong>{selectedSample.sample_type}</strong></div>
              <div style={{ gridColumn: '1 / -1' }}>
                Test: <strong style={{ color: '#0284c7' }}>{selectedSample.test_name}</strong>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmitResult} className="form-grid">
            <div className="form-group col-span-2">
              <label className="form-label">Quantitative / Qualitative Findings *</label>
              <textarea
                className="form-textarea"
                rows="3"
                value={formData.result_findings}
                onChange={(e) => setFormData({ ...formData, result_findings: e.target.value })}
                placeholder="e.g. Total Cholesterol: 228 mg/dL (Borderline High), LDL: 146 mg/dL, HDL: 44 mg/dL"
                required
              />
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Biological Reference Interval (Normal Ranges)</label>
              <input
                type="text"
                className="form-input"
                value={formData.reference_range}
                onChange={(e) => setFormData({ ...formData, reference_range: e.target.value })}
                placeholder="e.g. Desirable: <200 mg/dL, Borderline: 200-239 mg/dL"
              />
            </div>

            <div className="form-group col-span-2">
              <label className="form-label">Pathologist Clinical Observations & Remarks</label>
              <textarea
                className="form-textarea"
                rows="2"
                value={formData.remarks}
                onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                placeholder="Clinical correlation and dietary/medication comments..."
              />
            </div>

            <div className="form-group">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
              >
                <option value="Completed">Completed & Dispatched</option>
                <option value="Processing">In-Process / Re-testing</option>
                <option value="Collected">Awaiting Analysis</option>
              </select>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
