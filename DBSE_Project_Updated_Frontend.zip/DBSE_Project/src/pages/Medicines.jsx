import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import {
  PlusIcon,
  SearchIcon,
  EditIcon,
  TrashIcon,
  AlertTriangleIcon,
} from '../components/Icons';

export default function Medicines() {
  const [medicines, setMedicines] = useState([]);
  const [search, setSearch] = useState('');
  const [filterTab, setFilterTab] = useState('All'); // 'All', 'LowStock', 'Expired', 'InStock'
  const [filterCategory, setFilterCategory] = useState('All');
  const [loading, setLoading] = useState(true);

  // Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selectedMed, setSelectedMed] = useState(null);

  const initialFormData = {
    medicine_name: '',
    category: 'Antibiotics',
    manufacturer: '',
    price: '',
    quantity: '',
    expiry_date: '',
  };
  const [formData, setFormData] = useState(initialFormData);

  const fetchMedicines = async () => {
    setLoading(true);
    const data = await API.getMedicines();
    setMedicines(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchMedicines();
  }, []);

  const todayStr = new Date().toISOString().split('T')[0];

  const isExpired = (expiryDate) => {
    if (!expiryDate) return false;
    return expiryDate < todayStr;
  };

  const isLowStock = (qty) => {
    return Number(qty) < 20;
  };

  const handleOpenAdd = () => {
    setIsEditMode(false);
    setFormData(initialFormData);
    setIsModalOpen(true);
  };

  const handleOpenEdit = (med) => {
    setIsEditMode(true);
    setSelectedMed(med);
    setFormData({
      medicine_name: med.medicine_name || '',
      category: med.category || 'General',
      manufacturer: med.manufacturer || '',
      price: med.price || '',
      quantity: med.quantity || '',
      expiry_date: med.expiry_date || '',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      ...formData,
      price: parseFloat(formData.price) || 0,
      quantity: parseInt(formData.quantity, 10) || 0,
    };

    if (isEditMode && selectedMed) {
      await API.updateMedicine({
        ...selectedMed,
        ...payload,
      });
    } else {
      await API.addMedicine(payload);
    }

    setIsModalOpen(false);
    fetchMedicines();
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this medicine?')) {
      await API.deleteMedicine(id);
      fetchMedicines();
    }
  };

  // Categories list
  const categories = ['All', ...new Set(medicines.map((m) => m.category).filter(Boolean))];

  // Filtering
  const filteredMedicines = medicines.filter((m) => {
    const matchesSearch =
      m.medicine_name?.toLowerCase().includes(search.toLowerCase()) ||
      m.manufacturer?.toLowerCase().includes(search.toLowerCase()) ||
      m.category?.toLowerCase().includes(search.toLowerCase());

    const matchesCategory = filterCategory === 'All' || m.category === filterCategory;

    let matchesTab = true;
    if (filterTab === 'LowStock') matchesTab = isLowStock(m.quantity);
    else if (filterTab === 'Expired') matchesTab = isExpired(m.expiry_date);
    else if (filterTab === 'InStock') matchesTab = !isLowStock(m.quantity) && !isExpired(m.expiry_date);

    return matchesSearch && matchesCategory && matchesTab;
  });

  const lowStockCount = medicines.filter((m) => isLowStock(m.quantity)).length;
  const expiredCount = medicines.filter((m) => isExpired(m.expiry_date)).length;

  return (
    <div className="page-container">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1>Medicines & Pharmacy Inventory</h1>
          <p>Drug formulations, batch expiry tracking, and stock replenishment monitoring.</p>
        </div>
        <button className="btn btn-primary" onClick={handleOpenAdd}>
          <PlusIcon size={16} />
          <span>Add New Medicine</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '18px', flexWrap: 'wrap' }}>
        {[
          { id: 'All', label: `All Medicines (${medicines.length})` },
          { id: 'LowStock', label: `⚠️ Low Stock (<20) (${lowStockCount})`, alert: lowStockCount > 0 },
          { id: 'Expired', label: `⛔ Expired (${expiredCount})`, alert: expiredCount > 0 },
          { id: 'InStock', label: 'In Good Stock' },
        ].map((tab) => (
          <button
            key={tab.id}
            className={`btn btn-sm ${filterTab === tab.id ? 'btn-primary' : 'btn-secondary'}`}
            onClick={() => setFilterTab(tab.id)}
            style={{
              borderColor: tab.alert ? '#f59e0b' : undefined,
              fontWeight: tab.alert ? '700' : '500',
            }}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Action Bar */}
      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input
              type="text"
              className="search-input"
              placeholder="Search by medicine name, manufacturer, or category..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>

          <select
            className="filter-select"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === 'All' ? 'All Categories' : c}
              </option>
            ))}
          </select>
        </div>

        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: '500' }}>
          Showing {filteredMedicines.length} of {medicines.length} items
        </div>
      </div>

      {/* Table Card */}
      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Medicine Name</th>
                <th>Category</th>
                <th>Manufacturer</th>
                <th>Unit Price</th>
                <th>Stock Quantity</th>
                <th>Expiry Date</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>
                    Loading medicine inventory...
                  </td>
                </tr>
              ) : filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan="9" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>
                    No medicines match your filter criteria.
                  </td>
                </tr>
              ) : (
                filteredMedicines.map((m) => {
                  const expired = isExpired(m.expiry_date);
                  const lowStock = isLowStock(m.quantity);

                  return (
                    <tr key={m.medicine_id} style={{ backgroundColor: expired ? '#fff1f2' : undefined }}>
                      <td style={{ color: '#64748b', fontWeight: '600' }}>#{m.medicine_id}</td>
                      <td>
                        <div style={{ fontWeight: '700', color: '#0f172a' }}>{m.medicine_name}</div>
                      </td>
                      <td>
                        <span className="badge badge-primary">{m.category}</span>
                      </td>
                      <td style={{ color: '#475569' }}>{m.manufacturer}</td>
                      <td style={{ fontWeight: '600', color: '#059669' }}>₹{Number(m.price).toLocaleString('en-IN')}</td>
                      <td>
                        <span
                          style={{
                            fontWeight: '700',
                            color: m.quantity === 0 ? '#dc2626' : (lowStock ? '#d97706' : '#0f172a'),
                          }}
                        >
                          {m.quantity} units
                        </span>
                      </td>
                      <td style={{ color: expired ? '#dc2626' : '#475569', fontWeight: expired ? '700' : '400' }}>
                        {m.expiry_date}
                      </td>
                      <td>
                        {expired ? (
                          <span className="badge badge-danger">⛔ EXPIRED</span>
                        ) : m.quantity === 0 ? (
                          <span className="badge badge-danger">Out of Stock</span>
                        ) : lowStock ? (
                          <span className="badge badge-warning">⚠️ Low Stock</span>
                        ) : (
                          <span className="badge badge-success">✓ In Stock</span>
                        )}
                      </td>
                      <td style={{ textAlign: 'right' }}>
                        <div style={{ display: 'inline-flex', gap: '4px' }}>
                          <button
                            className="btn-icon edit"
                            title="Edit"
                            onClick={() => handleOpenEdit(m)}
                          >
                            <EditIcon size={16} />
                          </button>
                          <button
                            className="btn-icon delete"
                            title="Delete"
                            onClick={() => handleDelete(m.medicine_id)}
                          >
                            <TrashIcon size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditMode ? 'Edit Medicine Details' : 'Add New Medicine Formulation'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={handleSubmit}>
              {isEditMode ? 'Save Changes' : 'Add to Inventory'}
            </button>
          </>
        }
      >
        <form onSubmit={handleSubmit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Medicine Name & Strength *</label>
            <input
              type="text"
              className="form-input"
              value={formData.medicine_name}
              onChange={(e) => setFormData({ ...formData, medicine_name: e.target.value })}
              placeholder="e.g. Amoxicillin 500mg"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Category</label>
            <input
              type="text"
              className="form-input"
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              placeholder="e.g. Antibiotics, Analgesics"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Manufacturer Company</label>
            <input
              type="text"
              className="form-input"
              value={formData.manufacturer}
              onChange={(e) => setFormData({ ...formData, manufacturer: e.target.value })}
              placeholder="e.g. Cipla, Sun Pharma, Dr. Reddy's"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Unit Price (₹) *</label>
            <input
              type="number"
              step="0.01"
              min="0"
              className="form-input"
              value={formData.price}
              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
              placeholder="0.00"
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Stock Quantity *</label>
            <input
              type="number"
              min="0"
              className="form-input"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              placeholder="100"
              required
            />
          </div>

          <div className="form-group col-span-2">
            <label className="form-label">Expiry Date *</label>
            <input
              type="date"
              className="form-input"
              value={formData.expiry_date}
              onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>
    </div>
  );
}
