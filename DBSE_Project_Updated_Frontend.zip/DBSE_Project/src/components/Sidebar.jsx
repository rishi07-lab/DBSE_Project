import React from 'react';
import {
  DashboardIcon,
  PatientsIcon,
  DoctorIcon,
  SpecializationIcon,
  MedicalRecordIcon,
  MedicineIcon,
  PrescriptionIcon,
  LabTestIcon,
  LabReportIcon,
  BillIcon,
  PaymentIcon,
  InsuranceIcon,
  LogOutIcon,
  CloseIcon,
  ActivityIcon,
} from './Icons';

// Navigation menus are defined per role. Only items relevant to the
// logged-in role's permitted pages are rendered here; App.jsx's route
// guard is the actual enforcement layer, this is simply what's shown.
const NAV_ITEMS_BY_ROLE = {
  'Doctor / Admin': [
    { section: 'Overview' },
    { id: 'dashboard', label: 'Dashboard', icon: DashboardIcon },

    { section: 'Clinical Management' },
    { id: 'patients', label: 'Patients', icon: PatientsIcon },
    { id: 'doctors', label: 'Doctors', icon: DoctorIcon },
    { id: 'specializations', label: 'Specializations', icon: SpecializationIcon },
    { id: 'medical-records', label: 'Medical Records', icon: MedicalRecordIcon },
    { id: 'prescriptions', label: 'Prescriptions', icon: PrescriptionIcon },

    { section: 'Pharmacy & Laboratory' },
    { id: 'medicines', label: 'Medicines & Stock', icon: MedicineIcon },
    { id: 'lab-tests', label: 'Lab Tests Catalog', icon: LabTestIcon },
    { id: 'lab-reports', label: 'Lab Reports', icon: LabReportIcon },

    { section: 'Finance & Accounts' },
    { id: 'bills', label: 'Patient Bills', icon: BillIcon },
    { id: 'payments', label: 'Payments History', icon: PaymentIcon },
    { id: 'insurance', label: 'Insurance Claims', icon: InsuranceIcon },
  ],

  'Patient': [
    { section: 'My Health Portal' },
    { id: 'patient-dashboard', label: 'My Dashboard', icon: DashboardIcon },
    { id: 'patient-profile', label: 'My Profile', icon: PatientsIcon },

    { section: 'Clinical History' },
    { id: 'patient-records', label: 'My Medical Records', icon: MedicalRecordIcon },
    { id: 'patient-prescriptions', label: 'My Prescriptions', icon: PrescriptionIcon },
    { id: 'patient-medicines', label: 'My Prescribed Medicines', icon: MedicineIcon },
    { id: 'patient-lab-reports', label: 'My Lab Reports', icon: LabReportIcon },

    { section: 'Billing & Support' },
    { id: 'patient-bills', label: 'My Bills & Payments', icon: BillIcon },
    { id: 'patient-hospital-info', label: 'Hospital Information', icon: ActivityIcon },
  ],

  'Laboratory Staff': [
    { section: 'Laboratory Overview' },
    { id: 'lab-dashboard', label: 'Lab Dashboard', icon: DashboardIcon },

    { section: 'Diagnostic Workflow' },
    { id: 'lab-tests', label: 'Laboratory Tests', icon: LabTestIcon },
    { id: 'lab-samples', label: 'Sample Collection', icon: ActivityIcon },
    { id: 'lab-results', label: 'Test Results', icon: MedicalRecordIcon },
    { id: 'lab-upload', label: 'Upload Reports', icon: PrescriptionIcon },
    { id: 'lab-reports', label: 'Lab Reports', icon: LabReportIcon },
  ],
};

const ROLE_BADGE_LABEL = {
  'Doctor / Admin': 'Doctor / Admin',
  'Patient': 'Patient',
  'Laboratory Staff': 'Lab Staff',
};

export default function Sidebar({ currentPage, setCurrentPage, isOpen, setIsOpen, user, onLogout }) {
  const role = user?.role || 'Doctor / Admin';
  const navItems = NAV_ITEMS_BY_ROLE[role] || NAV_ITEMS_BY_ROLE['Doctor / Admin'];

  const handleSelect = (id) => {
    setCurrentPage(id);
    if (window.innerWidth < 900) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          className="modal-overlay"
          style={{ zIndex: 39, background: 'rgba(0,0,0,0.4)' }}
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        {/* Brand */}
        <div className="sidebar-brand">
          <div className="sidebar-logo-icon">
            <ActivityIcon size={24} />
          </div>
          <div>
            <div className="sidebar-brand-title">CarePulse HMS</div>
            <div className="sidebar-brand-subtitle">Hospital Management</div>
          </div>
          <button
            className="btn-icon menu-toggle-btn"
            style={{ marginLeft: 'auto', color: '#94a3b8' }}
            onClick={() => setIsOpen(false)}
          >
            <CloseIcon size={20} />
          </button>
        </div>

        {/* Navigation list */}
        <nav className="sidebar-menu">
          {navItems.map((item, index) => {
            if (item.section) {
              return (
                <div className="sidebar-section-title" key={`section-${index}`}>
                  {item.section}
                </div>
              );
            }
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                className={`sidebar-item ${isActive ? 'active' : ''}`}
                onClick={() => handleSelect(item.id)}
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer with logged in user & logout */}
        <div className="sidebar-footer">
          <div className="user-snippet">
            <div className="user-avatar">
              {user?.name ? user.name.charAt(0).toUpperCase() : 'A'}
            </div>
            <div style={{ overflow: 'hidden', flex: 1 }}>
              <div style={{ fontSize: '13px', fontWeight: '600', color: '#f8fafc', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden' }}>
                {user?.name || 'Administrator'}
              </div>
              <div style={{ fontSize: '11px', color: '#0ea5e9' }}>
                {ROLE_BADGE_LABEL[role] || role}
              </div>
            </div>
            <button
              onClick={onLogout}
              className="btn-icon"
              title="Logout"
              style={{ color: '#ef4444' }}
            >
              <LogOutIcon size={18} />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
