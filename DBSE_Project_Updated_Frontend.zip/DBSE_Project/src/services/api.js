// Hospital Management System (CarePulse HMS) Data Service
// Frontend-Only Demo Architecture with localStorage caching.
// Designed for seamless integration with a Node.js + Express backend in future.

const STORAGE_KEYS = {
  USERS: 'hms_users',
  SPECIALIZATIONS: 'hms_specializations',
  DOCTORS: 'hms_doctors',
  PATIENTS: 'hms_patients',
  MEDICINES: 'hms_medicines',
  PRESCRIPTIONS: 'hms_prescriptions',
  LAB_TESTS: 'hms_lab_tests',
  LAB_REPORTS: 'hms_lab_reports',
  LAB_SAMPLES: 'hms_lab_samples',
  BILLS: 'hms_bills',
  PAYMENTS: 'hms_payments',
  INSURANCE: 'hms_insurance',
  MEDICAL_RECORDS: 'hms_medical_records',
  CURRENT_USER: 'hms_current_user',
};

// -----------------------------------------------------------------------
// Demo Data Version
// -----------------------------------------------------------------------
// Because every demo data collection above is cached into the browser's
// localStorage the first time it's read (see getLocalData below), simply
// editing the seed data in this file does NOT automatically update a
// browser that already has an older cached copy saved from a previous
// version of the app. To force every browser to pick up fresh seed data
// whenever the demo dataset changes, bump this version string. On load,
// if the stored version doesn't match, all cached demo data (and the
// current session) is wiped so it reseeds cleanly from the arrays below.
const DEMO_DATA_VERSION = '2026-09-21-indian-data-v3';
const DATA_VERSION_KEY = 'hms_demo_data_version';

(function ensureFreshDemoData() {
  try {
    const storedVersion = localStorage.getItem(DATA_VERSION_KEY);
    if (storedVersion !== DEMO_DATA_VERSION) {
      Object.values(STORAGE_KEYS).forEach((key) => localStorage.removeItem(key));
      localStorage.setItem(DATA_VERSION_KEY, DEMO_DATA_VERSION);
    }
  } catch (err) {
    console.warn('Could not verify/reset demo data version:', err);
  }
})();

// 1. Initial Specializations (Medical Departments)
const initialSpecializations = [
  { specialization_id: 1, specialization_name: 'Cardiology' },
  { specialization_id: 2, specialization_name: 'Neurology' },
  { specialization_id: 3, specialization_name: 'Orthopedics' },
  { specialization_id: 4, specialization_name: 'Pediatrics' },
  { specialization_id: 5, specialization_name: 'Dermatology' },
  { specialization_id: 6, specialization_name: 'General Medicine' },
  { specialization_id: 7, specialization_name: 'Gynecology & Obstetrics' },
  { specialization_id: 8, specialization_name: 'ENT (Otorhinolaryngology)' },
  { specialization_id: 9, specialization_name: 'Ophthalmology' },
  { specialization_id: 10, specialization_name: 'General Surgery' },
  { specialization_id: 11, specialization_name: 'Oncology' },
  { specialization_id: 12, specialization_name: 'Pathology & Lab Medicine' },
];

// 2. Realistic Indian Doctors
const initialDoctors = [
  {
    doctor_id: 1,
    user_id: 101,
    name: 'Dr. Rajesh Sharma',
    email: 'r.sharma@hospital.com',
    phone: '+91 98201 44521',
    specialization_id: 1,
    specialization_name: 'Cardiology',
    qualification: 'MBBS, MD, DM Cardiology (AIIMS New Delhi)',
    experience_years: 18,
    availability_status: 'Available',
  },
  {
    doctor_id: 2,
    user_id: 102,
    name: 'Dr. Anita Deshmukh',
    email: 'a.deshmukh@hospital.com',
    phone: '+91 98220 55612',
    specialization_id: 2,
    specialization_name: 'Neurology',
    qualification: 'MBBS, MD, DM Neurology (KEM Hospital Mumbai)',
    experience_years: 15,
    availability_status: 'In Surgery',
  },
  {
    doctor_id: 3,
    user_id: 103,
    name: 'Dr. Suresh Kulkarni',
    email: 's.kulkarni@hospital.com',
    phone: '+91 98450 12890',
    specialization_id: 3,
    specialization_name: 'Orthopedics',
    qualification: 'MS Orthopedics, DNB, MCh (Grant Medical College)',
    experience_years: 20,
    availability_status: 'Available',
  },
  {
    doctor_id: 4,
    user_id: 104,
    name: 'Dr. Priya Nair',
    email: 'p.nair@hospital.com',
    phone: '+91 94470 33419',
    specialization_id: 4,
    specialization_name: 'Pediatrics',
    qualification: 'MBBS, MD Pediatrics (CMC Vellore)',
    experience_years: 11,
    availability_status: 'Available',
  },
  {
    doctor_id: 5,
    user_id: 105,
    name: 'Dr. Vikramaditya Rao',
    email: 'v.rao@hospital.com',
    phone: '+91 98490 66723',
    specialization_id: 10,
    specialization_name: 'General Surgery',
    qualification: 'MBBS, MS General Surgery, FIAGES (PGIMER Chandigarh)',
    experience_years: 16,
    availability_status: 'In Surgery',
  },
  {
    doctor_id: 6,
    user_id: 106,
    name: 'Dr. Sunita Patel',
    email: 's.patel@hospital.com',
    phone: '+91 98250 88914',
    specialization_id: 7,
    specialization_name: 'Gynecology & Obstetrics',
    qualification: 'MBBS, MD, DGO (BJMC Ahmedabad)',
    experience_years: 14,
    availability_status: 'Available',
  },
  {
    doctor_id: 7,
    user_id: 107,
    name: 'Dr. Arvind Menon',
    email: 'a.menon@hospital.com',
    phone: '+91 94440 22187',
    specialization_id: 6,
    specialization_name: 'General Medicine',
    qualification: 'MBBS, MD Internal Medicine (Madras Medical College)',
    experience_years: 22,
    availability_status: 'Available',
  },
  {
    doctor_id: 8,
    user_id: 108,
    name: 'Dr. Meera Nambiar',
    email: 'm.nambiar@hospital.com',
    phone: '+91 98480 77123',
    specialization_id: 5,
    specialization_name: 'Dermatology',
    qualification: 'MBBS, MD Dermatology, DVD (KMC Manipal)',
    experience_years: 9,
    availability_status: 'On Leave',
  },
  {
    doctor_id: 9,
    user_id: 109,
    name: 'Dr. Rohan Mukherjee',
    email: 'r.mukherjee@hospital.com',
    phone: '+91 98300 44198',
    specialization_id: 8,
    specialization_name: 'ENT (Otorhinolaryngology)',
    qualification: 'MBBS, MS ENT (IPGMER Kolkata)',
    experience_years: 12,
    availability_status: 'Available',
  },
  {
    doctor_id: 10,
    user_id: 110,
    name: 'Dr. Deepa Iyer',
    email: 'd.iyer@hospital.com',
    phone: '+91 98401 55678',
    specialization_id: 9,
    specialization_name: 'Ophthalmology',
    qualification: 'MBBS, MS Ophthalmology, DO (Sankara Nethralaya)',
    experience_years: 13,
    availability_status: 'Available',
  },
  {
    doctor_id: 11,
    user_id: 111,
    name: 'Dr. Amit Joshi',
    email: 'a.joshi@hospital.com',
    phone: '+91 98110 33245',
    specialization_id: 11,
    specialization_name: 'Oncology',
    qualification: 'MBBS, MD, DM Medical Oncology (Tata Memorial Hospital)',
    experience_years: 17,
    availability_status: 'Available',
  },
  {
    doctor_id: 12,
    user_id: 112,
    name: 'Dr. Kavita Reddy',
    email: 'k.reddy@hospital.com',
    phone: '+91 98499 11024',
    specialization_id: 12,
    specialization_name: 'Pathology & Lab Medicine',
    qualification: 'MBBS, MD Pathology (Osmania Medical College)',
    experience_years: 14,
    availability_status: 'Available',
  },
];

// 3. Realistic Indian Patients (Patient ID 1 bound to patient@hospital.com)
const initialPatients = [
  {
    patient_id: 1,
    user_id: 201,
    name: 'Ramesh Kumar Verma',
    email: 'patient@hospital.com',
    phone: '+91 98201 11223',
    date_of_birth: '1978-05-14',
    age: 48,
    gender: 'Male',
    blood_group: 'B+',
    city: 'Mumbai',
    address: 'Flat 402, Shanti Niketan, Andheri West, Mumbai, Maharashtra 400058',
    emergency_contact: 'Sunita Verma (Spouse) +91 98201 11224',
    medical_history: 'Primary Hypertension, Type 2 Diabetes (5 years)',
  },
  {
    patient_id: 2,
    user_id: 202,
    name: 'Ananya Sundaram',
    email: 'ananya.s@outlook.com',
    phone: '+91 94440 33211',
    date_of_birth: '1997-09-21',
    age: 29,
    gender: 'Female',
    blood_group: 'A+',
    city: 'Chennai',
    address: '14/2 Gandhi Mandapam Road, Kotturpuram, Chennai, Tamil Nadu 600085',
    emergency_contact: 'S. Sundaram (Father) +91 94440 33212',
    medical_history: 'Allergic Rhinitis, Occasional Migraines',
  },
  {
    patient_id: 3,
    user_id: 203,
    name: 'Harpreet Singh Gill',
    email: 'h.gill@yahoo.com',
    phone: '+91 98140 77654',
    date_of_birth: '1970-02-18',
    age: 56,
    gender: 'Male',
    blood_group: 'O+',
    city: 'Chandigarh',
    address: 'House 214, Sector 18-B, Chandigarh 160018',
    emergency_contact: 'Jaswinder Kaur (Spouse) +91 98140 77655',
    medical_history: 'Bilateral Knee Osteoarthritis, Mild Hyperlipidemia',
  },
  {
    patient_id: 4,
    user_id: 204,
    name: 'Priyanka Banerjee',
    email: 'priyanka.b@techcorp.in',
    phone: '+91 98300 44556',
    date_of_birth: '1992-11-04',
    age: 34,
    gender: 'Female',
    blood_group: 'AB+',
    city: 'Kolkata',
    address: '78 Lake Gardens, Prince Anwar Shah Road, Kolkata, West Bengal 700045',
    emergency_contact: 'Debashis Banerjee (Brother) +91 98300 44557',
    medical_history: 'Hypothyroidism (Eltroxin 50mcg)',
  },
  {
    patient_id: 5,
    user_id: 205,
    name: 'Mohammed Farooq',
    email: 'm.farooq@gmail.com',
    phone: '+91 98490 88990',
    date_of_birth: '1964-08-12',
    age: 62,
    gender: 'Male',
    blood_group: 'O-',
    city: 'Hyderabad',
    address: '12-2-417, Mehdipatnam, Hyderabad, Telangana 500028',
    emergency_contact: 'Sameer Farooq (Son) +91 98490 88991',
    medical_history: 'Coronary Artery Disease (Post PTCA Stent 2021)',
  },
  {
    patient_id: 6,
    user_id: 206,
    name: 'Lakshmi Narayanan',
    email: 'lakshmi.n@gmail.com',
    phone: '+91 98801 66778',
    date_of_birth: '1984-03-30',
    age: 42,
    gender: 'Female',
    blood_group: 'B+',
    city: 'Bengaluru',
    address: '304, 7th Cross, Malleshwaram, Bengaluru, Karnataka 560003',
    emergency_contact: 'R. Narayanan (Husband) +91 98801 66779',
    medical_history: 'Iron Deficiency Anemia, Cervical Spondylosis',
  },
  {
    patient_id: 7,
    user_id: 207,
    name: 'Amitav Sen',
    email: 'amitav.sen@tcs.com',
    phone: '+91 98311 22334',
    date_of_birth: '1988-07-15',
    age: 38,
    gender: 'Male',
    blood_group: 'A-',
    city: 'Kolkata',
    address: 'Flat 5B, Salt Lake Sector 2, Kolkata 700091',
    emergency_contact: 'Ruma Sen (Wife) +91 98311 22335',
    medical_history: 'Gastroesophageal Reflux Disease (GERD)',
  },
  {
    patient_id: 8,
    user_id: 208,
    name: 'Pooja Agrawal',
    email: 'pooja.agrawal@gmail.com',
    phone: '+91 94250 55667',
    date_of_birth: '1999-12-10',
    age: 27,
    gender: 'Female',
    blood_group: 'O+',
    city: 'Indore',
    address: '45 Palasia, AB Road, Indore, Madhya Pradesh 452001',
    emergency_contact: 'Mahesh Agrawal (Father) +91 94250 55668',
    medical_history: 'Mild Bronchial Asthma',
  },
  {
    patient_id: 9,
    user_id: 209,
    name: 'Vijay Chauhan',
    email: 'v.chauhan@punecorp.in',
    phone: '+91 98220 99887',
    date_of_birth: '1975-01-25',
    age: 51,
    gender: 'Male',
    blood_group: 'AB-',
    city: 'Pune',
    address: 'Bungalow 12, Senapati Bapat Road, Pune, Maharashtra 411016',
    emergency_contact: 'Rekha Chauhan (Wife) +91 98220 99888',
    medical_history: 'Hyperuricemia (Gout)',
  },
  {
    patient_id: 10,
    user_id: 210,
    name: 'Sneha Kulkarni',
    email: 'sneha.k@gmail.com',
    phone: '+91 98230 11445',
    date_of_birth: '1995-04-18',
    age: 31,
    gender: 'Female',
    blood_group: 'B-',
    city: 'Nagpur',
    address: '18 Ramdaspeth, Nagpur, Maharashtra 440010',
    emergency_contact: 'Sachin Kulkarni (Husband) +91 98230 11446',
    medical_history: 'Post-partum care, Vitamin D deficiency',
  },
];

// 4. Realistic Indian Medicines (26 Formulations with INR Pricing)
const initialMedicines = [
  {
    medicine_id: 1,
    medicine_name: 'Dolo 650 (Paracetamol 650mg)',
    category: 'Analgesics / Antipyretic',
    manufacturer: 'Micro Labs Ltd',
    price: 35.00,
    quantity: 450,
    expiry_date: '2028-06-30',
  },
  {
    medicine_id: 2,
    medicine_name: 'Augmentin 625 Duo (Amoxicillin + Clavulanate)',
    category: 'Antibiotics',
    manufacturer: 'Mankind Pharma',
    price: 210.00,
    quantity: 180,
    expiry_date: '2027-11-15',
  },
  {
    medicine_id: 3,
    medicine_name: 'Azee 500 (Azithromycin 500mg)',
    category: 'Antibiotics',
    manufacturer: 'Cipla Ltd',
    price: 125.00,
    quantity: 140,
    expiry_date: '2027-09-20',
  },
  {
    medicine_id: 4,
    medicine_name: 'Pan 40 (Pantoprazole 40mg)',
    category: 'Gastrointestinal / Antacid',
    manufacturer: 'Alkem Laboratories',
    price: 95.00,
    quantity: 320,
    expiry_date: '2028-01-31',
  },
  {
    medicine_id: 5,
    medicine_name: 'Glycomet 500 (Metformin 500mg)',
    category: 'Antidiabetic',
    manufacturer: 'USV Ltd',
    price: 45.00,
    quantity: 12, // Low stock indicator
    expiry_date: '2027-08-15',
  },
  {
    medicine_id: 6,
    medicine_name: 'Atorva 20 (Atorvastatin 20mg)',
    category: 'Cardiovascular / Statin',
    manufacturer: 'Zydus Cadila',
    price: 180.00,
    quantity: 95,
    expiry_date: '2027-05-10',
  },
  {
    medicine_id: 7,
    medicine_name: 'Telma 40 (Telmisartan 40mg)',
    category: 'Antihypertensive',
    manufacturer: 'Glenmark Pharmaceuticals',
    price: 140.00,
    quantity: 16, // Low stock indicator
    expiry_date: '2027-10-31',
  },
  {
    medicine_id: 8,
    medicine_name: 'Cetcip 10 (Cetirizine 10mg)',
    category: 'Antihistamine / Allergy',
    manufacturer: 'Cipla Ltd',
    price: 38.00,
    quantity: 210,
    expiry_date: '2026-07-31', // Expired indicator
  },
  {
    medicine_id: 9,
    medicine_name: 'Montair LC (Montelukast + Levocetirizine)',
    category: 'Respiratory / Antiallergic',
    manufacturer: 'Cipla Ltd',
    price: 190.00,
    quantity: 120,
    expiry_date: '2027-12-31',
  },
  {
    medicine_id: 10,
    medicine_name: 'Ciplox 500 (Ciprofloxacin 500mg)',
    category: 'Antibiotics',
    manufacturer: 'Cipla Ltd',
    price: 85.00,
    quantity: 160,
    expiry_date: '2027-04-15',
  },
  {
    medicine_id: 11,
    medicine_name: 'Amlong 5 (Amlodipine 5mg)',
    category: 'Antihypertensive',
    manufacturer: 'Micro Labs Ltd',
    price: 52.00,
    quantity: 240,
    expiry_date: '2028-03-20',
  },
  {
    medicine_id: 12,
    medicine_name: 'Combiflam (Ibuprofen 400mg + Paracetamol 325mg)',
    category: 'Analgesics / NSAID',
    manufacturer: 'Ipca Laboratories',
    price: 48.00,
    quantity: 380,
    expiry_date: '2027-11-30',
  },
  {
    medicine_id: 13,
    medicine_name: 'Omez 20 (Omeprazole 20mg)',
    category: 'Gastrointestinal',
    manufacturer: "Dr. Reddy's Laboratories",
    price: 65.00,
    quantity: 175,
    expiry_date: '2027-09-30',
  },
  {
    medicine_id: 14,
    medicine_name: 'Amaryl 2 (Glimepiride 2mg)',
    category: 'Antidiabetic',
    manufacturer: 'Wockhardt Ltd',
    price: 115.00,
    quantity: 8, // Low stock indicator
    expiry_date: '2027-06-15',
  },
  {
    medicine_id: 15,
    medicine_name: 'Rosuvas 10 (Rosuvastatin 10mg)',
    category: 'Cardiovascular',
    manufacturer: 'Sun Pharmaceutical',
    price: 195.00,
    quantity: 85,
    expiry_date: '2028-02-28',
  },
  {
    medicine_id: 16,
    medicine_name: 'Monocef 1g (Ceftriaxone Injection)',
    category: 'Injectable Antibiotic',
    manufacturer: 'Aristo Pharmaceuticals',
    price: 68.00,
    quantity: 90,
    expiry_date: '2027-08-31',
  },
  {
    medicine_id: 17,
    medicine_name: 'Emeset 4 (Ondansetron 4mg)',
    category: 'Antiemetic',
    manufacturer: 'Cipla Ltd',
    price: 55.00,
    quantity: 140,
    expiry_date: '2027-10-15',
  },
  {
    medicine_id: 18,
    medicine_name: 'Razo 20 (Rabeprazole Sodium 20mg)',
    category: 'Gastrointestinal',
    manufacturer: "Dr. Reddy's Laboratories",
    price: 130.00,
    quantity: 110,
    expiry_date: '2028-01-15',
  },
  {
    medicine_id: 19,
    medicine_name: 'Voveran 50 (Diclofenac Sodium 50mg)',
    category: 'Anti-inflammatory',
    manufacturer: 'Ajanta Pharma',
    price: 75.00,
    quantity: 200,
    expiry_date: '2027-07-20',
  },
  {
    medicine_id: 20,
    medicine_name: 'Ascoril D Plus Cough Syrup',
    category: 'Respiratory / Antitussive',
    manufacturer: 'Glenmark Pharmaceuticals',
    price: 110.00,
    quantity: 60,
    expiry_date: '2027-05-31',
  },
  {
    medicine_id: 21,
    medicine_name: 'Becozym C Forte Multivitamin',
    category: 'Vitamins & Supplements',
    manufacturer: 'Macleods Pharmaceuticals',
    price: 50.00,
    quantity: 300,
    expiry_date: '2028-05-15',
  },
  {
    medicine_id: 22,
    medicine_name: 'Shelcal 500 (Calcium + Vitamin D3)',
    category: 'Mineral Supplements',
    manufacturer: 'Torrent Pharmaceuticals',
    price: 135.00,
    quantity: 250,
    expiry_date: '2028-04-30',
  },
  {
    medicine_id: 23,
    medicine_name: 'Electral ORS Powder (WHO Formula)',
    category: 'Electrolytes / Rehydration',
    manufacturer: 'FDC Ltd',
    price: 22.00,
    quantity: 500,
    expiry_date: '2028-08-31',
  },
  {
    medicine_id: 24,
    medicine_name: 'Flagyl 400 (Metronidazole 400mg)',
    category: 'Antiprotozoal / Antibacterial',
    manufacturer: 'Emcure Pharmaceuticals',
    price: 32.00,
    quantity: 180,
    expiry_date: '2027-03-31',
  },
  {
    medicine_id: 25,
    medicine_name: 'Thyronorm 50mcg (Levothyroxine)',
    category: 'Endocrine / Thyroid',
    manufacturer: 'Lupin Ltd',
    price: 165.00,
    quantity: 150,
    expiry_date: '2028-02-15',
  },
  {
    medicine_id: 26,
    medicine_name: 'Zifi 200 (Cefixime 200mg)',
    category: 'Cephalosporin Antibiotic',
    manufacturer: 'FDC Ltd',
    price: 175.00,
    quantity: 130,
    expiry_date: '2027-12-15',
  },
];

// 5. Prescriptions (Linked to Indian Patients & Doctors)
const initialPrescriptions = [
  {
    prescription_id: 1,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    doctor_id: 1,
    doctor_name: 'Dr. Rajesh Sharma',
    medicine_id: 6,
    medicine_name: 'Atorva 20 (Atorvastatin 20mg)',
    expiry_date: '2027-05-10',
    dosage: '1 tablet once daily after dinner',
    duration: '30 Days',
    prescription_date: '2026-09-05',
  },
  {
    prescription_id: 2,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    doctor_id: 7,
    doctor_name: 'Dr. Arvind Menon',
    medicine_id: 5,
    medicine_name: 'Glycomet 500 (Metformin 500mg)',
    expiry_date: '2027-08-15',
    dosage: '1 tablet twice daily after meals (morning & evening)',
    duration: '60 Days',
    prescription_date: '2026-09-08',
  },
  {
    prescription_id: 3,
    patient_id: 2, // Ananya Sundaram
    patient_name: 'Ananya Sundaram',
    doctor_id: 4,
    doctor_name: 'Dr. Priya Nair',
    medicine_id: 9,
    medicine_name: 'Montair LC (Montelukast + Levocetirizine)',
    expiry_date: '2027-12-31',
    dosage: '1 tablet at bedtime for allergic rhinitis',
    duration: '14 Days',
    prescription_date: '2026-09-12',
  },
  {
    prescription_id: 4,
    patient_id: 3, // Harpreet Singh Gill
    patient_name: 'Harpreet Singh Gill',
    doctor_id: 3,
    doctor_name: 'Dr. Suresh Kulkarni',
    medicine_id: 19,
    medicine_name: 'Voveran 50 (Diclofenac Sodium 50mg)',
    expiry_date: '2027-07-20',
    dosage: '1 tablet after food as needed for severe joint stiffness',
    duration: '10 Days',
    prescription_date: '2026-09-14',
  },
  {
    prescription_id: 5,
    patient_id: 4, // Priyanka Banerjee
    patient_name: 'Priyanka Banerjee',
    doctor_id: 7,
    doctor_name: 'Dr. Arvind Menon',
    medicine_id: 25,
    medicine_name: 'Thyronorm 50mcg (Levothyroxine)',
    expiry_date: '2028-02-15',
    dosage: '1 tablet empty stomach in the morning with plain water',
    duration: '90 Days',
    prescription_date: '2026-09-16',
  },
];

// 6. Laboratory Diagnostic Tests Catalog (with Sample Type, Price in ₹, Status)
const initialLabTests = [
  {
    test_id: 1,
    test_name: 'Complete Blood Count (CBC) with ESR',
    test_description: 'Evaluates hemoglobin, RBC count, total WBC, differential count, and platelet count for infections and anemia.',
    test_cost: 380.00,
    sample_type: 'Whole Blood (EDTA)',
    test_status: 'Active',
  },
  {
    test_id: 2,
    test_name: 'Comprehensive Lipid Profile',
    test_description: 'Measures total serum cholesterol, HDL, LDL, VLDL, and triglycerides for cardiovascular risk assessment.',
    test_cost: 750.00,
    sample_type: 'Blood Serum (Fasting)',
    test_status: 'Active',
  },
  {
    test_id: 3,
    test_name: 'HbA1c (Glycated Hemoglobin)',
    test_description: 'Assesses 3-month average plasma glucose concentration for glycemic diabetic monitoring.',
    test_cost: 550.00,
    sample_type: 'Whole Blood (EDTA)',
    test_status: 'Active',
  },
  {
    test_id: 4,
    test_name: 'Liver Function Test (LFT Profile)',
    test_description: 'Measures SGOT, SGPT, Bilirubin total/direct, Alkaline Phosphatase, and Serum Proteins.',
    test_cost: 850.00,
    sample_type: 'Blood Serum',
    test_status: 'Active',
  },
  {
    test_id: 5,
    test_name: 'Kidney Function Test (KFT / RFT)',
    test_description: 'Evaluates serum creatinine, blood urea nitrogen (BUN), uric acid, and electrolytes.',
    test_cost: 700.00,
    sample_type: 'Blood Serum',
    test_status: 'Active',
  },
  {
    test_id: 6,
    test_name: 'Thyroid Profile Total (T3, T4, TSH)',
    test_description: 'Evaluates thyroid hormone production to screen for hyperthyroidism and hypothyroidism.',
    test_cost: 650.00,
    sample_type: 'Blood Serum',
    test_status: 'Active',
  },
  {
    test_id: 7,
    test_name: 'Digital Chest X-Ray (PA View)',
    test_description: 'High-resolution thoracic radiography for lungs, heart silhouette, and mediastinum.',
    test_cost: 600.00,
    sample_type: 'Radiological Imaging',
    test_status: 'Active',
  },
  {
    test_id: 8,
    test_name: 'Urine Routine & Microscopic Examination',
    test_description: 'Physical, chemical, and microscopic analysis for UTI, proteinuria, and renal casts.',
    test_cost: 250.00,
    sample_type: 'Clean Catch Midstream Urine',
    test_status: 'Active',
  },
];

// 7. Laboratory Sample Collection Logs (Dedicated Workflow)
const initialLabSamples = [
  {
    sample_id: 'SMP-1001',
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    test_id: 2,
    test_name: 'Comprehensive Lipid Profile',
    sample_type: 'Blood Serum (Fasting)',
    collection_date: '2026-09-17',
    collection_time: '08:30 AM',
    collection_status: 'Completed',
    collected_by: 'Staff Phlebotomist Amit',
  },
  {
    sample_id: 'SMP-1002',
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    test_id: 3,
    test_name: 'HbA1c (Glycated Hemoglobin)',
    sample_type: 'Whole Blood (EDTA)',
    collection_date: '2026-09-17',
    collection_time: '08:35 AM',
    collection_status: 'Completed',
    collected_by: 'Staff Phlebotomist Amit',
  },
  {
    sample_id: 'SMP-1003',
    patient_id: 2, // Ananya Sundaram
    patient_name: 'Ananya Sundaram',
    test_id: 1,
    test_name: 'Complete Blood Count (CBC) with ESR',
    sample_type: 'Whole Blood (EDTA)',
    collection_date: '2026-09-18',
    collection_time: '09:15 AM',
    collection_status: 'Processing',
    collected_by: 'Lab Tech Deepa',
  },
  {
    sample_id: 'SMP-1004',
    patient_id: 3, // Harpreet Singh Gill
    patient_name: 'Harpreet Singh Gill',
    test_id: 5,
    test_name: 'Kidney Function Test (KFT / RFT)',
    sample_type: 'Blood Serum',
    collection_date: '2026-09-19',
    collection_time: '10:00 AM',
    collection_status: 'Collected',
    collected_by: 'Staff Phlebotomist Amit',
  },
  {
    sample_id: 'SMP-1005',
    patient_id: 4, // Priyanka Banerjee
    patient_name: 'Priyanka Banerjee',
    test_id: 6,
    test_name: 'Thyroid Profile Total (T3, T4, TSH)',
    sample_type: 'Blood Serum',
    collection_date: '2026-09-19',
    collection_time: '10:30 AM',
    collection_status: 'Pending',
    collected_by: 'Unassigned',
  },
];

// 8. Laboratory Reports
const initialLabReports = [
  {
    report_id: 101,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    test_id: 2,
    test_name: 'Comprehensive Lipid Profile',
    doctor_id: 1,
    doctor_name: 'Dr. Rajesh Sharma',
    result: 'Total Cholesterol: 228 mg/dL (Borderline High), LDL: 146 mg/dL, HDL: 44 mg/dL, Triglycerides: 190 mg/dL',
    report_date: '2026-09-17',
    remarks: 'Moderate mixed dyslipidemia. Statin therapy advised along with aerobic exercise and diet restriction.',
    file_attachment: 'Lipid_Profile_Ramesh_Verma.pdf (Demo Document Attachment)',
  },
  {
    report_id: 102,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    test_id: 3,
    test_name: 'HbA1c (Glycated Hemoglobin)',
    doctor_id: 7,
    doctor_name: 'Dr. Arvind Menon',
    result: 'HbA1c: 7.2% (Estimated Average Glucose: 160 mg/dL)',
    report_date: '2026-09-17',
    remarks: 'Sub-optimal glycemic control. Maintain strict carbohydrate restriction and continue Metformin 500mg BID.',
    file_attachment: 'HbA1c_Ramesh_Verma.pdf (Demo Document Attachment)',
  },
  {
    report_id: 103,
    patient_id: 2,
    patient_name: 'Ananya Sundaram',
    test_id: 1,
    test_name: 'Complete Blood Count (CBC) with ESR',
    doctor_id: 4,
    doctor_name: 'Dr. Priya Nair',
    result: 'Hemoglobin: 12.8 g/dL, Total WBC: 7,400 /mcL, Platelets: 2.8 Lakhs/mcL, ESR: 14 mm/1st hr',
    report_date: '2026-09-18',
    remarks: 'Hematological parameters within normal clinical limits. No sign of acute infection.',
    file_attachment: 'CBC_Report_Ananya.pdf (Demo Document Attachment)',
  },
];

// 9. Bills & Invoices in INR (₹)
const initialBills = [
  {
    bill_id: 501,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    bill_date: '2026-09-05',
    total_amount: 12500.00,
    payment_status: 'Paid',
  },
  {
    bill_id: 502,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    bill_date: '2026-09-17',
    total_amount: 8750.00,
    payment_status: 'Paid',
  },
  {
    bill_id: 503,
    patient_id: 2,
    patient_name: 'Ananya Sundaram',
    bill_date: '2026-09-12',
    total_amount: 15200.00,
    payment_status: 'Paid',
  },
  {
    bill_id: 504,
    patient_id: 3,
    patient_name: 'Harpreet Singh Gill',
    bill_date: '2026-09-14',
    total_amount: 11800.00,
    payment_status: 'Unpaid',
  },
  {
    bill_id: 505,
    patient_id: 4,
    patient_name: 'Priyanka Banerjee',
    bill_date: '2026-09-16',
    total_amount: 8493.00,
    payment_status: 'Pending',
  },
];

// 10. Payment Transactions in INR (₹)
const initialPayments = [
  {
    payment_id: 901,
    bill_id: 501,
    patient_name: 'Ramesh Kumar Verma',
    amount_paid: 12500.00,
    payment_method: 'UPI / GooglePay',
    payment_date: '2026-09-05',
  },
  {
    payment_id: 902,
    bill_id: 502,
    patient_name: 'Ramesh Kumar Verma',
    amount_paid: 8750.00,
    payment_method: 'Credit Card (HDFC)',
    payment_date: '2026-09-17',
  },
  {
    payment_id: 903,
    bill_id: 503,
    patient_name: 'Ananya Sundaram',
    amount_paid: 15200.00,
    payment_method: 'UPI / PhonePe',
    payment_date: '2026-09-12',
  },
];

// 11. Insurance Policies in INR (₹) with Indian TPA Providers
const initialInsurance = [
  {
    insurance_id: 301,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    insurance_provider: 'Star Health & Allied Insurance',
    policy_number: 'SH-MED-9921-IN',
    coverage_amount: 500000.00,
    claim_status: 'Approved',
  },
  {
    insurance_id: 302,
    patient_id: 3,
    patient_name: 'Harpreet Singh Gill',
    insurance_provider: 'HDFC ERGO Health Insurance',
    policy_number: 'HE-POL-5412-PB',
    coverage_amount: 1000000.00,
    claim_status: 'Processing',
  },
  {
    insurance_id: 303,
    patient_id: 4,
    patient_name: 'Priyanka Banerjee',
    insurance_provider: 'Care Health Insurance',
    policy_number: 'CARE-7731-WB',
    coverage_amount: 750000.00,
    claim_status: 'Approved',
  },
  {
    insurance_id: 304,
    patient_id: 5,
    patient_name: 'Mohammed Farooq',
    insurance_provider: 'ICICI Lombard Health Care',
    policy_number: 'ICICI-8812-TS',
    coverage_amount: 1500000.00,
    claim_status: 'Approved',
  },
];

// 12. Medical Records
const initialMedicalRecords = [
  {
    record_id: 701,
    patient_id: 1, // Ramesh Kumar Verma
    patient_name: 'Ramesh Kumar Verma',
    diagnosis: 'Primary Essential Hypertension & Type 2 Diabetes Mellitus',
    symptoms: 'Mild morning headache, occasional dizziness, increased thirst',
    treatment: 'Lifestyle modifications, low sodium diet, daily brisk walking, Atorva 20mg, Glycomet 500mg',
    doctor_notes: 'Patient advised to chart blood pressure twice weekly. Review after 4 weeks with lipid profile and fasting glucose.',
    record_date: '2026-09-05',
  },
  {
    record_id: 702,
    patient_id: 2,
    patient_name: 'Ananya Sundaram',
    diagnosis: 'Allergic Rhinitis with Mild Pharyngitis',
    symptoms: 'Nasal congestion, sneezing paroxysms, watery eyes, scratchy throat',
    treatment: 'Montair LC once daily at bedtime for 14 days, steam inhalation, avoidance of cold beverages',
    doctor_notes: 'Symptoms triggered by seasonal pollen changes. No active sinus tenderness.',
    record_date: '2026-09-12',
  },
  {
    record_id: 703,
    patient_id: 3,
    patient_name: 'Harpreet Singh Gill',
    diagnosis: 'Bilateral Primary Knee Osteoarthritis (Kellgren-Lawrence Grade II)',
    symptoms: 'Morning stiffness lasting 25 minutes, knee crepitus on stair climbing',
    treatment: 'Quadriceps isometric strengthening, weight management, Voveran 50mg SOS for acute joint discomfort',
    doctor_notes: 'Weight reduction strongly recommended. Avoid high-impact jogging or deep squatting.',
    record_date: '2026-09-14',
  },
];

// LocalStorage helpers
function getLocalData(key, fallback) {
  try {
    const item = localStorage.getItem(key);
    if (!item) {
      localStorage.setItem(key, JSON.stringify(fallback));
      return fallback;
    }
    return JSON.parse(item);
  } catch (err) {
    console.warn(`localStorage read error for ${key}:`, err);
    return fallback;
  }
}

function setLocalData(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (err) {
    console.warn(`localStorage write error for ${key}:`, err);
  }
}

// Unified in-memory/localStorage API dispatcher
async function apiRequest(endpoint, method = 'GET', body = null, storageKey = null, fallbackData = []) {
  if (!storageKey) return fallbackData;

  const currentList = getLocalData(storageKey, fallbackData);

  if (method === 'GET') {
    return currentList;
  } else if (method === 'POST') {
    const newId = Date.now();
    const newItem = { ...body };
    const idKey = Object.keys(body).find((k) => k.endsWith('_id')) || 'id';
    if (!newItem[idKey]) newItem[idKey] = newId;
    const updated = [newItem, ...currentList];
    setLocalData(storageKey, updated);
    return newItem;
  } else if (method === 'PUT') {
    const idKey = Object.keys(body).find((k) => k.endsWith('_id')) || 'id';
    const updated = currentList.map((item) =>
      String(item[idKey]) === String(body[idKey]) ? { ...item, ...body } : item
    );
    setLocalData(storageKey, updated);
    return body;
  } else if (method === 'DELETE') {
    const idKey = body.idKey || 'id';
    const updated = currentList.filter((item) => String(item[idKey]) !== String(body.id));
    setLocalData(storageKey, updated);
    return { success: true };
  }

  return fallbackData;
}

export const API = {
  // Authentication & Demo Accounts
  getCurrentUser() {
    return getLocalData(STORAGE_KEYS.CURRENT_USER, null);
  },

  login(email, password) {
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPass = password.trim();

    // 1. Doctor / Admin
    if (trimmedEmail === 'admin@hospital.com' && trimmedPass === 'Admin@123') {
      const user = {
        user_id: 1,
        name: 'Dr. Rajesh Sharma (Chief Medical Officer)',
        email: 'admin@hospital.com',
        role: 'Doctor / Admin',
        phone: '+91 98201 44521',
      };
      setLocalData(STORAGE_KEYS.CURRENT_USER, user);
      return { success: true, user };
    }

    // 2. Patient: Bound strictly to Patient ID 1 (Ramesh Kumar Verma)
    if (trimmedEmail === 'patient@hospital.com' && trimmedPass === 'Patient@123') {
      const user = {
        user_id: 201,
        patient_id: 1,
        name: 'Ramesh Kumar Verma',
        email: 'patient@hospital.com',
        role: 'Patient',
        phone: '+91 98201 11223',
        city: 'Mumbai',
        blood_group: 'B+',
      };
      setLocalData(STORAGE_KEYS.CURRENT_USER, user);
      return { success: true, user };
    }

    // 3. Laboratory Staff
    if (trimmedEmail === 'lab@hospital.com' && trimmedPass === 'Lab@123') {
      const user = {
        user_id: 301,
        name: 'Dr. Kavita Reddy (Head Pathologist)',
        email: 'lab@hospital.com',
        role: 'Laboratory Staff',
        phone: '+91 98499 11024',
      };
      setLocalData(STORAGE_KEYS.CURRENT_USER, user);
      return { success: true, user };
    }

    return {
      success: false,
      message: 'Invalid credentials. Please use one of the demo credentials provided below.',
    };
  },

  logout() {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
  },

  // Admin / Doctor Dashboard Stats
  async getDashboardStats() {
    const patients = getLocalData(STORAGE_KEYS.PATIENTS, initialPatients);
    const doctors = getLocalData(STORAGE_KEYS.DOCTORS, initialDoctors);
    const medicines = getLocalData(STORAGE_KEYS.MEDICINES, initialMedicines);
    const prescriptions = getLocalData(STORAGE_KEYS.PRESCRIPTIONS, initialPrescriptions);
    const bills = getLocalData(STORAGE_KEYS.BILLS, initialBills);
    const labReports = getLocalData(STORAGE_KEYS.LAB_REPORTS, initialLabReports);
    const insurance = getLocalData(STORAGE_KEYS.INSURANCE, initialInsurance);

    const totalRevenue = bills.reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);
    const pendingBills = bills.filter((b) => b.payment_status !== 'Paid').length;
    const lowStockMedicines = medicines.filter((m) => m.quantity < 20).length;

    return {
      totalPatients: patients.length,
      totalDoctors: doctors.length,
      totalMedicines: medicines.length,
      totalPrescriptions: prescriptions.length,
      totalBills: bills.length,
      totalRevenue: totalRevenue.toFixed(2),
      pendingBills,
      totalLabReports: labReports.length,
      totalInsurance: insurance.length,
      lowStockMedicines,
      recentPrescriptions: prescriptions.slice(0, 5),
    };
  },

  // Patient Dashboard Stats (strictly for Patient 1)
  async getPatientDashboardStats(patientId = 1) {
    const prescriptions = (await this.getPrescriptions()).filter((p) => Number(p.patient_id) === Number(patientId));
    const labReports = (await this.getLabReports()).filter((r) => Number(r.patient_id) === Number(patientId));
    const bills = (await this.getBills()).filter((b) => Number(b.patient_id) === Number(patientId));
    const medicalRecords = (await this.getMedicalRecords()).filter((m) => Number(m.patient_id) === Number(patientId));

    const totalBilled = bills.reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);
    const pendingDues = bills
      .filter((b) => b.payment_status !== 'Paid')
      .reduce((acc, curr) => acc + (Number(curr.total_amount) || 0), 0);

    return {
      totalPrescriptions: prescriptions.length,
      totalLabReports: labReports.length,
      totalBills: bills.length,
      totalMedicalRecords: medicalRecords.length,
      totalBilled: totalBilled.toFixed(2),
      pendingDues: pendingDues.toFixed(2),
      prescriptions,
      labReports,
      bills,
      medicalRecords,
    };
  },

  // Laboratory Dashboard Stats
  async getLabDashboardStats() {
    const tests = await this.getLabTests();
    const samples = await this.getLabSamples();
    const reports = await this.getLabReports();

    const pendingSamples = samples.filter((s) => s.collection_status === 'Pending').length;
    const processingSamples = samples.filter((s) => s.collection_status === 'Processing' || s.collection_status === 'Collected').length;
    const completedReports = reports.length;

    return {
      totalTests: tests.length,
      pendingSamples,
      processingSamples,
      completedReports,
      recentSamples: samples.slice(0, 6),
      recentReports: reports.slice(0, 6),
    };
  },

  // Specializations
  getSpecializations: () => apiRequest('/specializations', 'GET', null, STORAGE_KEYS.SPECIALIZATIONS, initialSpecializations),
  addSpecialization: (data) => apiRequest('/specializations', 'POST', data, STORAGE_KEYS.SPECIALIZATIONS, initialSpecializations),
  updateSpecialization: (data) => apiRequest('/specializations', 'PUT', data, STORAGE_KEYS.SPECIALIZATIONS, initialSpecializations),
  deleteSpecialization: (id) => apiRequest('/specializations', 'DELETE', { id, idKey: 'specialization_id' }, STORAGE_KEYS.SPECIALIZATIONS, initialSpecializations),

  // Doctors
  getDoctors: () => apiRequest('/doctors', 'GET', null, STORAGE_KEYS.DOCTORS, initialDoctors),
  addDoctor: (data) => apiRequest('/doctors', 'POST', data, STORAGE_KEYS.DOCTORS, initialDoctors),
  updateDoctor: (data) => apiRequest('/doctors', 'PUT', data, STORAGE_KEYS.DOCTORS, initialDoctors),
  deleteDoctor: (id) => apiRequest('/doctors', 'DELETE', { id, idKey: 'doctor_id' }, STORAGE_KEYS.DOCTORS, initialDoctors),

  // Patients
  getPatients: () => apiRequest('/patients', 'GET', null, STORAGE_KEYS.PATIENTS, initialPatients),
  addPatient: (data) => apiRequest('/patients', 'POST', data, STORAGE_KEYS.PATIENTS, initialPatients),
  updatePatient: (data) => apiRequest('/patients', 'PUT', data, STORAGE_KEYS.PATIENTS, initialPatients),
  deletePatient: (id) => apiRequest('/patients', 'DELETE', { id, idKey: 'patient_id' }, STORAGE_KEYS.PATIENTS, initialPatients),

  // Medicines (Managed by Doctor/Admin)
  getMedicines: () => apiRequest('/medicines', 'GET', null, STORAGE_KEYS.MEDICINES, initialMedicines),
  addMedicine: (data) => apiRequest('/medicines', 'POST', data, STORAGE_KEYS.MEDICINES, initialMedicines),
  updateMedicine: (data) => apiRequest('/medicines', 'PUT', data, STORAGE_KEYS.MEDICINES, initialMedicines),
  deleteMedicine: (id) => apiRequest('/medicines', 'DELETE', { id, idKey: 'medicine_id' }, STORAGE_KEYS.MEDICINES, initialMedicines),

  // Prescriptions
  getPrescriptions: () => apiRequest('/prescriptions', 'GET', null, STORAGE_KEYS.PRESCRIPTIONS, initialPrescriptions),
  addPrescription: (data) => apiRequest('/prescriptions', 'POST', data, STORAGE_KEYS.PRESCRIPTIONS, initialPrescriptions),
  deletePrescription: (id) => apiRequest('/prescriptions', 'DELETE', { id, idKey: 'prescription_id' }, STORAGE_KEYS.PRESCRIPTIONS, initialPrescriptions),

  // Lab Tests Catalog
  getLabTests: () => apiRequest('/lab-tests', 'GET', null, STORAGE_KEYS.LAB_TESTS, initialLabTests),
  addLabTest: (data) => apiRequest('/lab-tests', 'POST', data, STORAGE_KEYS.LAB_TESTS, initialLabTests),
  updateLabTest: (data) => apiRequest('/lab-tests', 'PUT', data, STORAGE_KEYS.LAB_TESTS, initialLabTests),
  deleteLabTest: (id) => apiRequest('/lab-tests', 'DELETE', { id, idKey: 'test_id' }, STORAGE_KEYS.LAB_TESTS, initialLabTests),

  // Sample Collection (Dedicated Lab Module)
  getLabSamples: () => apiRequest('/lab-samples', 'GET', null, STORAGE_KEYS.LAB_SAMPLES, initialLabSamples),
  addLabSample: (data) => apiRequest('/lab-samples', 'POST', data, STORAGE_KEYS.LAB_SAMPLES, initialLabSamples),
  updateLabSample: (data) => apiRequest('/lab-samples', 'PUT', data, STORAGE_KEYS.LAB_SAMPLES, initialLabSamples),

  // Lab Reports
  getLabReports: () => apiRequest('/lab-reports', 'GET', null, STORAGE_KEYS.LAB_REPORTS, initialLabReports),
  addLabReport: (data) => apiRequest('/lab-reports', 'POST', data, STORAGE_KEYS.LAB_REPORTS, initialLabReports),
  updateLabReport: (data) => apiRequest('/lab-reports', 'PUT', data, STORAGE_KEYS.LAB_REPORTS, initialLabReports),
  deleteLabReport: (id) => apiRequest('/lab-reports', 'DELETE', { id, idKey: 'report_id' }, STORAGE_KEYS.LAB_REPORTS, initialLabReports),

  // Bills
  getBills: () => apiRequest('/bills', 'GET', null, STORAGE_KEYS.BILLS, initialBills),
  addBill: (data) => apiRequest('/bills', 'POST', data, STORAGE_KEYS.BILLS, initialBills),
  updateBill: (data) => apiRequest('/bills', 'PUT', data, STORAGE_KEYS.BILLS, initialBills),
  deleteBill: (id) => apiRequest('/bills', 'DELETE', { id, idKey: 'bill_id' }, STORAGE_KEYS.BILLS, initialBills),

  // Payments
  getPayments: () => apiRequest('/payments', 'GET', null, STORAGE_KEYS.PAYMENTS, initialPayments),
  addPayment: (data) => apiRequest('/payments', 'POST', data, STORAGE_KEYS.PAYMENTS, initialPayments),
  deletePayment: (id) => apiRequest('/payments', 'DELETE', { id, idKey: 'payment_id' }, STORAGE_KEYS.PAYMENTS, initialPayments),

  // Insurance
  getInsurance: () => apiRequest('/insurance', 'GET', null, STORAGE_KEYS.INSURANCE, initialInsurance),
  addInsurance: (data) => apiRequest('/insurance', 'POST', data, STORAGE_KEYS.INSURANCE, initialInsurance),
  updateInsurance: (data) => apiRequest('/insurance', 'PUT', data, STORAGE_KEYS.INSURANCE, initialInsurance),
  deleteInsurance: (id) => apiRequest('/insurance', 'DELETE', { id, idKey: 'insurance_id' }, STORAGE_KEYS.INSURANCE, initialInsurance),

  // Medical Records
  getMedicalRecords: () => apiRequest('/medical-records', 'GET', null, STORAGE_KEYS.MEDICAL_RECORDS, initialMedicalRecords),
  addMedicalRecord: (data) => apiRequest('/medical-records', 'POST', data, STORAGE_KEYS.MEDICAL_RECORDS, initialMedicalRecords),
  updateMedicalRecord: (data) => apiRequest('/medical-records', 'PUT', data, STORAGE_KEYS.MEDICAL_RECORDS, initialMedicalRecords),
  deleteMedicalRecord: (id) => apiRequest('/medical-records', 'DELETE', { id, idKey: 'record_id' }, STORAGE_KEYS.MEDICAL_RECORDS, initialMedicalRecords),
};
