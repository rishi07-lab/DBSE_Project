# Hospital Management System (CarePulse HMS) — Frontend

A **React + Vite**, frontend-only Hospital Management System with three role-based portals
(**Doctor/Admin**, **Patient**, **Laboratory Staff**), Indian Rupee (₹) currency throughout,
and realistic Indian demo data. There is currently **no backend, database, or server** — all
data lives in-memory and in your browser's `localStorage` via `src/services/api.js`, which is
structured so a real backend can be connected later without changing the pages that call it.

---

## 🔐 Demo Login Credentials

| Role | Email | Password | Lands On |
| :--- | :--- | :--- | :--- |
| **Doctor / Admin** | `admin@hospital.com` | `Admin@123` | Admin Dashboard |
| **Patient** | `patient@hospital.com` | `Patient@123` | Patient Dashboard (bound to Patient #1 — Ramesh Kumar Verma) |
| **Laboratory Staff** | `lab@hospital.com` | `Lab@123` | Laboratory Dashboard |

All three are shown with one-click "Quick Login" buttons on the login screen. Authentication is
frontend-only demo auth — there is no real backend verifying credentials.

---

## 🚀 How to Run

```bash
# 1. Install dependencies
npm install

# 2. Start the Vite development server
npm run dev
```

Then open **http://localhost:5173** in your browser. (Do **not** open `index.html` directly by
double-clicking it — browsers block ES module scripts over the `file://` protocol; you must use
the Vite dev server.)

On Windows you can also double-click `start.bat`, which runs `npm install` and `npm run dev` and
opens the browser automatically.

---

## 🏥 Role-Based Portals

### Doctor / Admin Portal
Full administrative access: Dashboard, Patients, Doctors, Specializations, Medical Records,
Prescriptions, Medicines & Stock, Lab Tests Catalog, Lab Reports, Bills, Payments, Insurance.

### Patient Portal
Scoped strictly to the logged-in patient's own record (**Patient #1 — Ramesh Kumar Verma** for
the demo account): My Dashboard, My Profile, My Medical Records, My Prescriptions, My Prescribed
Medicines (no stock/inventory data shown), My Lab Reports, My Bills & Payments, Hospital
Information. No appointment booking exists anywhere in the app, by design.

### Laboratory Staff Portal
Scoped to laboratory operations only: Lab Dashboard, Laboratory Tests (catalog with sample type,
price in ₹, and active/inactive status), Sample Collection, Test Results entry, Upload Reports.
Lab Staff cannot see medicine management, medicine stock, doctor management, billing, or general
administration.

### Route Protection
`src/App.jsx` keeps a `ROLE_ALLOWED_PAGES` map and re-checks the current page against it on every
render. If a page outside a role's allowed list is ever set as the current page (e.g. a Patient
account somehow lands on `medicines`), the app immediately redirects back to that role's own
dashboard. The sidebar also only ever renders links a role is allowed to open.

---

## 💰 Currency

All monetary values across cards, tables, forms, and printable slips use ₹ (Indian Rupees) with
`toLocaleString('en-IN')` formatting (e.g. `₹5,00,000`). There is no `$` anywhere in the app.

---

## 🧾 Demo Data Included

- **12 Indian doctors** across Cardiology, Neurology, Orthopedics, Pediatrics, General Surgery,
  Gynecology, General Medicine, Dermatology, ENT, Ophthalmology, Oncology, and Pathology.
- **10 Indian patients** (Mumbai, Chennai, Chandigarh, Kolkata, Hyderabad, Bengaluru, Indore, Pune,
  Nagpur) with realistic demographics, blood groups, and medical history. Patient #1 (Ramesh Kumar
  Verma) is the one bound to the demo Patient login.
- **26 Indian medicines** (Dolo 650, Augmentin 625 Duo, Azee 500, Glycomet 500, etc.) from
  manufacturers such as Cipla, Sun Pharma, Dr. Reddy's, Zydus Cadila, Torrent, and Abbott India.
- **8 laboratory tests** (CBC, Lipid Profile, HbA1c, LFT, KFT, Thyroid Profile, Chest X-Ray,
  Urine R/M) with sample type and pricing in ₹.
- **Insurance policies** with Indian TPA providers: Star Health, HDFC ERGO, Care Health Insurance,
  ICICI Lombard.

All of this is clearly demo/sample data — no real patient information is used.

---

## 📁 Project Structure

```
src/
├── App.jsx                      # Role-based routing + route guard
├── main.jsx
├── index.css
├── components/
│   ├── Sidebar.jsx               # Role-specific navigation menus
│   ├── Navbar.jsx                 # Page titles, role/portal badge, Demo Mode indicator
│   ├── Modal.jsx
│   └── Icons.jsx
├── services/
│   └── api.js                    # All demo data + localStorage-backed CRUD "API"
└── pages/
    ├── Login.jsx                  # 3-role demo authentication
    ├── Dashboard.jsx               # Doctor/Admin
    ├── Patients.jsx
    ├── Doctors.jsx
    ├── Specializations.jsx
    ├── MedicalRecords.jsx
    ├── Prescriptions.jsx
    ├── Medicines.jsx
    ├── LabTests.jsx
    ├── LabReports.jsx
    ├── Bills.jsx
    ├── Payments.jsx
    ├── Insurance.jsx
    ├── PatientDashboard.jsx        # Patient portal
    ├── PatientViews.jsx            # Patient sub-pages (profile/records/etc.)
    ├── LabDashboard.jsx            # Laboratory Staff portal
    ├── LabSampleCollection.jsx
    ├── LabTestResults.jsx
    └── LabUploadReport.jsx
```

---

## ⚠️ What Is and Isn't Real Here

- **Real**: All add/edit/delete/search flows work in the browser and persist to `localStorage`
  for the current browser/device.
- **Not real**: There is no server, no database, no file storage, and no authentication backend.
  Uploading a "report" in the Lab Staff → Upload Reports screen simulates the record being created
  and instantly visible in the matching patient's "My Lab Reports" — but no actual file is stored
  anywhere beyond this browser session's demo cache.
- Nothing in the UI claims a database or server connection is active; the Navbar shows a
  "Demo Mode" badge instead.

## 🔧 Backend Work Required Later

To make this production-ready, you would need to:
1. Replace the functions in `src/services/api.js` with real HTTP calls to a backend (the function
   signatures are already designed to be swapped in place).
2. Implement real authentication (hashed passwords, sessions/JWT) in place of the hardcoded demo
   credential check in `API.login()`.
3. Add real file storage (e.g. S3-compatible object storage) for the Lab report upload feature.
4. Move the seed data currently in `api.js` into an actual database with proper foreign keys.
