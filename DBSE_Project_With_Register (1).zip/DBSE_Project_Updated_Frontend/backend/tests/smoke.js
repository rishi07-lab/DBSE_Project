// End-to-end smoke test against the running gateway:  npm test   (start the backend first)
// Uses the demo accounts created by `npm run db:seed`. Test records it creates are deleted again.
const BASE = process.env.API_BASE || 'http://localhost:5000/api';
const ACCOUNTS = {
  admin: ['admin@hospital.com', process.env.ADMIN_PASSWORD || 'admin123'],
  doctor: ['doctor@hospital.com', 'Doctor@123'],
  patient: ['patient@hospital.com', 'Patient@123'],
  lab: ['lab@hospital.com', 'Lab@123'],
};
let pass = 0, fail = 0;
const check = (name, ok, extra = '') => {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${ok ? '' : '  ' + extra}`);
  ok ? pass++ : fail++;
};
async function call(method, path, token, body) {
  const res = await fetch(BASE + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  return { status: res.status, data };
}

const tokens = {}; const users = {};
for (const [role, [email, password]] of Object.entries(ACCOUNTS)) {
  const r = await call('POST', '/auth/login', null, { email, password });
  check(`login as ${role}`, r.status === 200 && r.data?.token, JSON.stringify(r.data));
  tokens[role] = r.data?.token; users[role] = r.data?.user;
}
check('wrong password rejected', (await call('POST', '/auth/login', null, { email: ACCOUNTS.admin[0], password: 'nope' })).status === 401);
check('no token -> 401', (await call('GET', '/patients')).status === 401);
check('garbage token -> 401', (await call('GET', '/patients', 'abc.def.ghi')).status === 401);
check('role labels', users.admin?.role === 'Admin' && users.doctor?.role === 'Doctor' && users.patient?.role === 'Patient' && users.lab?.role === 'Laboratory Staff');
check('patient has patient_id', !!users.patient?.patient_id);
check('doctor has doctor_id', !!users.doctor?.doctor_id);

// ---- RBAC ----
check('patient cannot list doctors', (await call('GET', '/doctors', tokens.patient)).status === 403);
check('patient cannot list medicines', (await call('GET', '/medicines', tokens.patient)).status === 403);
check('lab cannot read bills', (await call('GET', '/bills', tokens.lab)).status === 403);
check('doctor cannot create bill', (await call('POST', '/bills', tokens.doctor, { patient_id: 1, total_amount: 1 })).status === 403);
check('admin cannot read prescriptions', (await call('GET', '/prescriptions', tokens.admin)).status === 403);
check('doctor cannot hit admin dashboard', (await call('GET', '/dashboard/admin', tokens.doctor)).status === 403);

// ---- patient scoping ----
const myPatients = await call('GET', '/patients', tokens.patient);
check('patient sees only own patient row', myPatients.data?.length === 1 && myPatients.data[0].patient_id === users.patient.patient_id);
const allPatients = await call('GET', '/patients', tokens.doctor);
check('doctor sees all patients', allPatients.data?.length > 10, `got ${allPatients.data?.length}`);
const myRx = await call('GET', '/prescriptions', tokens.patient);
check('patient prescriptions are all own', myRx.data?.length > 0 && myRx.data.every((x) => x.patient_id === users.patient.patient_id));
check('prescription rows are joined (names)', !!myRx.data?.[0]?.medicine_name && !!myRx.data?.[0]?.doctor_name);

// ---- dashboards ----
for (const [role, path, key] of [['admin', 'admin', 'totalRevenue'], ['doctor', 'doctor', 'recentPrescriptions'], ['patient', 'patient', 'pendingDues'], ['lab', 'lab', 'pendingSamples']]) {
  const r = await call('GET', `/dashboard/${path}`, tokens[role]);
  check(`${role} dashboard`, r.status === 200 && r.data?.[key] !== undefined, JSON.stringify(r.data)?.slice(0, 120));
}

// ---- CRUD: patient (doctor) ----
const stamp = Date.now();
const created = await call('POST', '/patients', tokens.doctor, { name: 'Smoke Test', email: `smoke${stamp}@test.in`, phone: '9000099999', gender: 'Male', blood_group: 'O+', date_of_birth: '1990-01-01', city: 'Hyderabad', address: 'Test Street' });
check('create patient', created.status === 201 && created.data?.patient_id, JSON.stringify(created.data));
const pid = created.data?.patient_id;
check('duplicate email -> 409', (await call('POST', '/patients', tokens.doctor, { name: 'Dup', email: `smoke${stamp}@test.in` })).status === 409);
check('update patient', (await call('PUT', `/patients/${pid}`, tokens.doctor, { city: 'Guntur' })).data?.city === 'Guntur');

// ---- billing flow (admin) ----
const bill = await call('POST', '/bills', tokens.admin, { patient_id: pid, total_amount: 1000, payment_status: 'Unpaid' });
check('create bill', bill.status === 201, JSON.stringify(bill.data));
const pay = await call('POST', '/payments', tokens.admin, { bill_id: bill.data?.bill_id, amount_paid: 1000, payment_method: 'UPI' });
check('create payment', pay.status === 201, JSON.stringify(pay.data));
check('bill auto-marked Paid', (await call('GET', '/bills', tokens.admin)).data?.find((b) => b.bill_id === bill.data?.bill_id)?.payment_status === 'Paid');
check('cannot delete bill that has payments', (await call('DELETE', `/bills/${bill.data?.bill_id}`, tokens.admin)).status === 409);

// ---- lab flow ----
const tests = await call('GET', '/lab-tests', tokens.lab);
const sample = await call('POST', '/lab-samples', tokens.lab, { patient_id: pid, test_id: tests.data?.[0]?.test_id, collection_status: 'Pending' });
check('create lab sample (server code)', sample.status === 201 && /^SMP-\d+$/.test(sample.data?.sample_id || ''), JSON.stringify(sample.data));
const upd = await call('PUT', `/lab-samples/${sample.data?.sample_id}`, tokens.lab, { collection_status: 'Completed' });
check('update lab sample status', upd.data?.collection_status === 'Completed', JSON.stringify(upd.data));
const rep = await call('POST', '/lab-reports', tokens.lab, { patient_id: pid, test_id: tests.data?.[0]?.test_id, result: 'Normal', remarks: 'ok', file_attachment: 'x.pdf' });
check('lab staff creates report (doctor auto-resolved)', rep.status === 201 && rep.data?.doctor_name, JSON.stringify(rep.data));

// ---- prescription (doctor) ----
const meds = await call('GET', '/medicines', tokens.doctor);
const rx = await call('POST', '/prescriptions', tokens.doctor, { patient_id: pid, medicine_id: meds.data?.[0]?.medicine_id, dosage: '1 tab', duration: '3 days' });
check('doctor creates prescription (own doctor_id)', rx.status === 201 && rx.data?.doctor_id === users.doctor.doctor_id, JSON.stringify(rx.data));

// ---- cleanup ----
await call('DELETE', `/prescriptions/${rx.data?.prescription_id}`, tokens.doctor);
await call('DELETE', `/lab-reports/${rep.data?.report_id}`, tokens.lab);
await call('DELETE', `/payments/${pay.data?.payment_id}`, tokens.admin);
await call('DELETE', `/bills/${bill.data?.bill_id}`, tokens.admin);
const { pool } = await import('../shared/db.js');
await pool.query('DELETE FROM lab_samples WHERE sample_code = ?', [sample.data?.sample_id]);
check('delete patient', (await call('DELETE', `/patients/${pid}`, tokens.doctor)).status === 200);
await pool.end();

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
