// Analytics service: role-specific dashboard statistics.
import { Router } from 'express';
import { query } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, HttpError } from '../../shared/http.js';
import {
  listPrescriptions, listLabReports, listLabSamples, listBills, listMedicalRecords,
} from '../../shared/repo.js';

const { app, listen } = createService('analytics-service');
app.use('/api', authenticate);

const count = async (sql, params = []) => Number((await query(sql, params))[0].n);
const router = Router();

router.get('/admin', allow('Admin'), wrap(async (_req, res) => {
  const [revenue] = await query('SELECT COALESCE(SUM(amount_paid),0) AS total FROM payments');
  res.json({
    totalPatients: await count('SELECT COUNT(*) n FROM patients'),
    totalDoctors: await count('SELECT COUNT(*) n FROM doctors'),
    totalMedicines: await count('SELECT COUNT(*) n FROM medicines'),
    totalPrescriptions: await count('SELECT COUNT(*) n FROM prescriptions'),
    totalBills: await count('SELECT COUNT(*) n FROM bills'),
    totalRevenue: Number(revenue.total).toFixed(2),
    pendingBills: await count("SELECT COUNT(*) n FROM bills WHERE payment_status <> 'Paid'"),
    totalLabReports: await count('SELECT COUNT(*) n FROM lab_reports'),
    totalInsurance: await count('SELECT COUNT(*) n FROM insurance'),
    lowStockMedicines: await count('SELECT COUNT(*) n FROM medicines WHERE quantity < 20'),
  });
}));

router.get('/doctor', allow('Doctor'), wrap(async (_req, res) => {
  res.json({
    totalPatients: await count('SELECT COUNT(*) n FROM patients'),
    totalPrescriptions: await count('SELECT COUNT(*) n FROM prescriptions'),
    totalLabReports: await count('SELECT COUNT(*) n FROM lab_reports'),
    totalMedicalRecords: await count('SELECT COUNT(*) n FROM medical_records'),
    recentPrescriptions: await listPrescriptions({ limit: 5 }),
  });
}));

router.get('/patient', allow('Patient'), wrap(async (req, res) => {
  const patientId = req.user.patient_id;
  if (!patientId) throw new HttpError(403, 'No patient profile is linked to this account.');
  const [prescriptions, labReports, bills, medicalRecords] = await Promise.all([
    listPrescriptions({ patientId }), listLabReports({ patientId }), listBills({ patientId }), listMedicalRecords({ patientId }),
  ]);
  const totalBilled = bills.reduce((a, b) => a + Number(b.total_amount || 0), 0);
  const pendingDues = bills.filter((b) => b.payment_status !== 'Paid').reduce((a, b) => a + Number(b.total_amount || 0), 0);
  res.json({
    totalPrescriptions: prescriptions.length,
    totalLabReports: labReports.length,
    totalBills: bills.length,
    totalMedicalRecords: medicalRecords.length,
    totalBilled: totalBilled.toFixed(2),
    pendingDues: pendingDues.toFixed(2),
    prescriptions, labReports, bills, medicalRecords,
  });
}));

router.get('/lab', allow('Laboratory Staff'), wrap(async (_req, res) => {
  res.json({
    totalTests: await count('SELECT COUNT(*) n FROM lab_tests'),
    pendingSamples: await count("SELECT COUNT(*) n FROM lab_samples WHERE collection_status = 'Pending'"),
    processingSamples: await count("SELECT COUNT(*) n FROM lab_samples WHERE collection_status IN ('Processing','Collected')"),
    completedReports: await count('SELECT COUNT(*) n FROM lab_reports'),
    recentSamples: await listLabSamples({ limit: 6 }),
    recentReports: await listLabReports({ limit: 6 }),
  });
}));

app.use('/api/dashboard', router);
listen(config.ports.analytics);
