// Auth service: JWT login, patient self-registration, session check, password change.
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { query, withTransaction, ensureUsernameColumn, dbRole } from '../../shared/db.js';
import { config, ROLE_FROM_DB, canonicalRole } from '../../shared/config.js';
import { signToken, authenticate } from '../../shared/auth.js';
import { createService, wrap, HttpError } from '../../shared/http.js';

const { app, listen } = createService('auth-service');

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many login attempts. Please try again in a few minutes.' },
});

// users.username is added on demand, so registration works even if db:migrate was not re-run.
let usernameReady = false;
async function ensureReady() {
  if (usernameReady) return;
  await ensureUsernameColumn();
  usernameReady = true;
}
ensureReady().catch((e) => console.warn('[auth-service] could not prepare users.username yet:', e.message));

const registerLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many sign-up attempts. Please try again later.' },
});

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const USERNAME_RE = /^[a-z0-9][a-z0-9._-]{2,29}$/;

const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);

async function buildSessionUser(row) {
  const role = ROLE_FROM_DB[canonicalRole(row.role)];
  if (!role) throw new HttpError(403, `This account has an unsupported role (${row.role}).`);
  const user = { user_id: row.user_id, name: row.name, username: row.username || null, email: row.email, phone: row.phone, role };

  if (role === 'Patient') {
    const [p] = await query('SELECT patient_id, city, blood_group FROM patients WHERE user_id = ?', [row.user_id]);
    if (p) Object.assign(user, { patient_id: p.patient_id, city: p.city, blood_group: p.blood_group });
  } else if (role === 'Doctor') {
    const [d] = await query(
      `SELECT d.doctor_id, s.specialization_name FROM doctors d
         LEFT JOIN specializations s ON s.specialization_id = d.specialization_id WHERE d.user_id = ?`,
      [row.user_id]
    );
    if (d) {
      user.doctor_id = d.doctor_id;
      user.designation = d.specialization_name ? `${d.specialization_name} Specialist` : 'Doctor';
    }
  } else if (role === 'Admin') {
    user.designation = 'Hospital Administrator';
  } else {
    user.designation = 'Laboratory Staff';
  }
  return user;
}

const tokenPayload = (u) => ({
  user_id: u.user_id, name: u.name, email: u.email, role: u.role,
  ...(u.patient_id ? { patient_id: u.patient_id } : {}),
  ...(u.doctor_id ? { doctor_id: u.doctor_id } : {}),
});

app.post('/api/auth/login', loginLimiter, wrap(async (req, res) => {
  await ensureReady();
  // "email" may hold either the person's email or their chosen username
  const email = String(req.body?.email ?? req.body?.username ?? '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) throw new HttpError(400, 'Username/email and password are required.');

  const [row] = await query('SELECT * FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? LIMIT 1', [email, email]);
  // always run a bcrypt compare so response time does not reveal whether the email exists
  const ok = await bcrypt.compare(password, row ? row.password : DUMMY_HASH);
  if (!row || !ok) throw new HttpError(401, 'Invalid username/email or password.');

  const user = await buildSessionUser(row);
  const token = signToken(tokenPayload(user));
  res.json({ success: true, token, expiresIn: config.jwt.expiresIn, user });
}));

// Public sign-up. Always creates a PATIENT account (staff accounts are created by an Admin),
// stores a bcrypt hash of the chosen password and signs the new user straight in.
app.post('/api/auth/register', registerLimiter, wrap(async (req, res) => {
  await ensureReady();
  const b = req.body || {};
  const name = String(b.name || '').trim();
  const username = String(b.username || '').trim().toLowerCase();
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  const phone = b.phone ? String(b.phone).replace(/[^\d+]/g, '').slice(0, 20) : null;

  if (name.length < 2) throw new HttpError(400, 'Please enter your full name.');
  if (!USERNAME_RE.test(username)) {
    throw new HttpError(400, 'Username must be 3-30 characters: lowercase letters, numbers, dot, dash or underscore.');
  }
  if (!EMAIL_RE.test(email)) throw new HttpError(400, 'A valid email address is required.');
  if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    throw new HttpError(400, 'Password must be at least 8 characters and include a letter and a number.');
  }

  const [taken] = await query('SELECT email, username FROM users WHERE LOWER(email) = ? OR LOWER(username) = ? LIMIT 1', [email, username]);
  if (taken) {
    throw new HttpError(409, String(taken.username || '').toLowerCase() === username
      ? 'That username is already taken. Please choose another.'
      : 'An account with this email already exists. Try signing in.');
  }

  const hashed = await bcrypt.hash(password, 10);
  const userId = await withTransaction(async (conn) => {
    const [u] = await conn.query(
      'INSERT INTO users (name, username, email, password, role, phone) VALUES (?,?,?,?,?,?)',
      [name, username, email, hashed, await dbRole('PATIENT'), phone]
    );
    await conn.query('INSERT INTO patients (user_id) VALUES (?)', [u.insertId]);
    return u.insertId;
  });

  const [row] = await query('SELECT * FROM users WHERE user_id = ?', [userId]);
  const user = await buildSessionUser(row);
  res.status(201).json({ success: true, token: signToken(tokenPayload(user)), expiresIn: config.jwt.expiresIn, user });
}));

app.get('/api/auth/me', authenticate, wrap(async (req, res) => {
  const [row] = await query('SELECT * FROM users WHERE user_id = ?', [req.user.user_id]);
  if (!row) throw new HttpError(401, 'Account no longer exists.');
  res.json({ user: await buildSessionUser(row) });
}));

app.post('/api/auth/change-password', authenticate, wrap(async (req, res) => {
  const { current_password, new_password } = req.body || {};
  if (!current_password || !new_password) throw new HttpError(400, 'Current and new password are required.');
  if (String(new_password).length < 8) throw new HttpError(400, 'New password must be at least 8 characters.');
  const [row] = await query('SELECT password FROM users WHERE user_id = ?', [req.user.user_id]);
  if (!row || !(await bcrypt.compare(String(current_password), row.password))) {
    throw new HttpError(401, 'Current password is incorrect.');
  }
  await query('UPDATE users SET password = ? WHERE user_id = ?', [await bcrypt.hash(String(new_password), 10), req.user.user_id]);
  res.json({ success: true });
}));

listen(config.ports.auth);
