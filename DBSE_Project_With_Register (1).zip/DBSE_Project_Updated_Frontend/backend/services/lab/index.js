// Lab service: test catalogue, sample collection, lab reports.
import { Router } from 'express';
import { query, withTransaction } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, pick, HttpError, isId, patientScope } from '../../shared/http.js';
import { listLabReports, listLabSamples } from '../../shared/repo.js';

const { app, listen } = createService('lab-service');
app.use('/api', authenticate);
const today = () => new Date().toISOString().slice(0, 10);
const need = (cond, msg) => { if (!cond) throw new HttpError(400, msg); };

// ============================ LAB TESTS (catalogue) ============================
const TEST_COLS = 'test_id, test_name, test_description, test_cost, sample_type, test_status';
const tests = Router();
tests.get('/', allow('Admin', 'Doctor', 'Laboratory Staff'), wrap(async (_req, res) => {
  res.json(await query(`SELECT ${TEST_COLS} FROM lab_tests ORDER BY test_id DESC`));
}));
tests.post('/', allow('Admin', 'Laboratory Staff'), wrap(async (req, res) => {
  const d = pick(req.body || {}, ['test_name', 'test_description', 'test_cost', 'sample_type', 'test_status']);
  need(d.test_name, 'Test name is required.');
  const r = await query('INSERT INTO lab_tests SET ?', [d]);
  const [row] = await query(`SELECT ${TEST_COLS} FROM lab_tests WHERE test_id = ?`, [r.insertId]);
  res.status(201).json(row);
}));
tests.put('/:id', allow('Admin', 'Laboratory Staff'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const d = pick(req.body || {}, ['test_name', 'test_description', 'test_cost', 'sample_type', 'test_status']);
  if (Object.keys(d).length) await query('UPDATE lab_tests SET ? WHERE test_id = ?', [d, req.params.id]);
  const [row] = await query(`SELECT ${TEST_COLS} FROM lab_tests WHERE test_id = ?`, [req.params.id]);
  if (!row) throw new HttpError(404, 'Lab test not found.');
  res.json(row);
}));
tests.delete('/:id', allow('Admin', 'Laboratory Staff'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM lab_tests WHERE test_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Lab test not found.');
  res.json({ success: true });
}));
app.use('/api/lab-tests', tests);

// ============================ LAB SAMPLES ============================
const SAMPLE_FIELDS = ['patient_id', 'test_id', 'sample_type', 'collection_date', 'collection_time', 'collection_status', 'collected_by'];
const samples = Router();
samples.get('/', allow('Doctor', 'Laboratory Staff'), wrap(async (_req, res) => res.json(await listLabSamples())));
samples.post('/', allow('Laboratory Staff'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.patient_id) && isId(b.test_id), 'Patient and test are required.');
  const id = await withTransaction(async (conn) => {
    // server-generated, sequential sample code: SMP-1001, SMP-1002, ...
    const [[m]] = await conn.query("SELECT COALESCE(MAX(CAST(SUBSTRING(sample_code, 5) AS UNSIGNED)), 1000) AS n FROM lab_samples WHERE sample_code REGEXP '^SMP-[0-9]+$' FOR UPDATE");
    const code = `SMP-${Number(m.n) + 1}`;
    const d = pick(b, SAMPLE_FIELDS);
    d.sample_code = code;
    d.collection_date = d.collection_date || today();
    d.collection_status = d.collection_status || 'Pending';
    d.collected_by = d.collected_by || req.user.name;
    if (!d.sample_type) {
      const [t] = await conn.query('SELECT sample_type FROM lab_tests WHERE test_id = ?', [d.test_id]);
      d.sample_type = t[0]?.sample_type || null;
    }
    await conn.query('INSERT INTO lab_samples SET ?', [d]);
    return code;
  });
  const [row] = await listLabSamples({ id });
  res.status(201).json(row);
}));
samples.put('/:id', allow('Laboratory Staff'), wrap(async (req, res) => {
  const d = pick(req.body || {}, SAMPLE_FIELDS);
  if (Object.keys(d).length) {
    const r = await query('UPDATE lab_samples SET ? WHERE sample_code = ?', [d, req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Sample not found.');
  }
  const [row] = await listLabSamples({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Sample not found.');
  res.json(row);
}));
app.use('/api/lab-samples', samples);

// ============================ LAB REPORTS ============================
const REPORT_FIELDS = ['patient_id', 'test_id', 'doctor_id', 'result', 'report_date', 'remarks', 'file_attachment', 'file_size'];
const reports = Router();

// lab_reports.doctor_id is mandatory: fall back to the logged-in doctor, the patient's latest
// prescribing doctor, then any doctor.
async function resolveDoctor(req, b) {
  if (isId(b.doctor_id)) {
    const [d] = await query('SELECT doctor_id FROM doctors WHERE doctor_id = ?', [b.doctor_id]);
    if (d) return d.doctor_id;
  }
  if (req.user.doctor_id) return req.user.doctor_id;
  const [rx] = await query('SELECT doctor_id FROM prescriptions WHERE patient_id = ? ORDER BY prescription_date DESC LIMIT 1', [b.patient_id]);
  if (rx) return rx.doctor_id;
  const [any] = await query('SELECT doctor_id FROM doctors ORDER BY doctor_id LIMIT 1');
  if (any) return any.doctor_id;
  throw new HttpError(400, 'No doctor exists to attach this report to.');
}

reports.get('/', allow('Doctor', 'Laboratory Staff', 'Patient'), wrap(async (req, res) => res.json(await listLabReports(patientScope(req)))));
reports.post('/', allow('Doctor', 'Laboratory Staff'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.patient_id) && isId(b.test_id), 'Patient and test are required.');
  const d = pick(b, REPORT_FIELDS);
  d.doctor_id = await resolveDoctor(req, b);
  d.report_date = d.report_date || today();
  const r = await query('INSERT INTO lab_reports SET ?', [d]);
  const [row] = await listLabReports({ id: r.insertId });
  res.status(201).json(row);
}));
reports.put('/:id', allow('Doctor', 'Laboratory Staff'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const d = pick(req.body || {}, REPORT_FIELDS);
  if (d.doctor_id) d.doctor_id = await resolveDoctor(req, { ...req.body, doctor_id: d.doctor_id });
  if (Object.keys(d).length) {
    const r = await query('UPDATE lab_reports SET ? WHERE report_id = ?', [d, req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Report not found.');
  }
  const [row] = await listLabReports({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Report not found.');
  res.json(row);
}));
reports.delete('/:id', allow('Doctor', 'Laboratory Staff'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM lab_reports WHERE report_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Report not found.');
  res.json({ success: true });
}));
app.use('/api/lab-reports', reports);

listen(config.ports.lab);
