// API gateway: the single entry point (port 5000) the React app talks to.
// Verifies the JWT once, then reverse-proxies each /api/<resource> to its microservice.
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { config } from '../../shared/config.js';
import { authenticate } from '../../shared/auth.js';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: config.corsOrigin }));
app.use(morgan('[gateway] :method :url :status :response-time ms'));
// NOTE: no body parser here - request bodies are streamed straight through to the services.

const ROUTES = [
  { service: 'auth', url: config.urls.auth, prefixes: ['/api/auth'] },
  { service: 'clinical', url: config.urls.clinical, prefixes: ['/api/patients', '/api/doctors', '/api/specializations', '/api/medical-records', '/api/prescriptions'] },
  { service: 'pharmacy', url: config.urls.pharmacy, prefixes: ['/api/medicines'] },
  { service: 'lab', url: config.urls.lab, prefixes: ['/api/lab-tests', '/api/lab-samples', '/api/lab-reports'] },
  { service: 'billing', url: config.urls.billing, prefixes: ['/api/bills', '/api/payments', '/api/insurance'] },
  { service: 'analytics', url: config.urls.analytics, prefixes: ['/api/dashboard'] },
];

// Aggregated health check (public)
app.get('/api/health', async (_req, res) => {
  const results = await Promise.all(
    ROUTES.map(async (r) => {
      try {
        const resp = await fetch(`${r.url}/health`, { signal: AbortSignal.timeout(2500) });
        return [r.service, resp.ok ? 'ok' : `error (${resp.status})`];
      } catch {
        return [r.service, 'unreachable'];
      }
    })
  );
  const services = Object.fromEntries(results);
  const healthy = Object.values(services).every((s) => s === 'ok');
  res.status(healthy ? 200 : 503).json({ gateway: 'ok', services });
});

// JWT guard for everything under /api except the login and register endpoints
const PUBLIC = new Set(['/api/auth/login', '/api/auth/register']);
app.use('/api', (req, res, next) => {
  if (req.method === 'OPTIONS' || PUBLIC.has(req.originalUrl.split('?')[0])) return next();
  return authenticate(req, res, next);
});

for (const r of ROUTES) {
  app.use(
    createProxyMiddleware({
      target: r.url,
      changeOrigin: true,
      pathFilter: r.prefixes,
      on: {
        error: (err, _req, res) => {
          console.error(`[gateway] ${r.service} service unreachable:`, err.code || err.message);
          if (!res.headersSent) res.status(502).json({ message: `The ${r.service} service is currently unavailable.` });
        },
      },
    })
  );
}

app.use((req, res) => res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` }));

app.listen(config.ports.gateway, () => console.log(`[gateway] listening on :${config.ports.gateway}`));
