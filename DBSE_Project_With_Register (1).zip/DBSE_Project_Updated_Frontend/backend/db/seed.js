// Adds the frontend's demo data to the EXISTING database, alongside what is already there.
//  * idempotent: every row is looked up by a natural key first (email, name, policy number...)
//  * never updates or deletes existing rows
//  * normalises demo values to the existing data's conventions (10-digit phones, 'Tablet'
//    medicine category, 'UPI'/'Card' payment methods, existing lab-test and specialization names)
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pool, query, dbRole } from '../shared/db.js';
import { config } from '../shared/config.js';
import { migrate } from './migrate.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const demo = JSON.parse(fs.readFileSync(path.join(here, 'demoData.json'), 'utf8'));

const stats = {};
const bump = (k, n = 1) => { stats[k] = (stats[k] || 0) + n; };

const digits10 = (s) => String(s || '').replace(/\D/g, '').slice(-10) || null;
const stripParens = (s) => String(s || '').replace(/\s*\(.*?\)\s*/g, ' ').replace(/\s+/g, ' ').trim();

// ---- normalisation maps (demo vocabulary -> existing database vocabulary) ----
const SPEC_MAP = {
  'Gynecology & Obstetrics': 'Gynecology',
  'ENT (Otorhinolaryngology)': 'ENT',
  'Pathology & Lab Medicine': 'Pathology',
};
const AVAILABILITY = { Available: 'Available', 'In Surgery': 'In Surgery', 'On Leave': 'On Leave' };
// demo lab test -> test that already exists in the database (so no duplicates are created)
const LABTEST_MAP = {
  'Complete Blood Count (CBC) with ESR': 'Blood Test',
  'Comprehensive Lipid Profile': 'Lipid Profile',
  'HbA1c (Glycated Hemoglobin)': 'HbA1c Test',
  'Liver Function Test (LFT Profile)': 'Liver Function Test',
  'Kidney Function Test (KFT / RFT)': 'Kidney Function Test',
  'Thyroid Profile Total (T3, T4, TSH)': 'Thyroid Test',
  'Digital Chest X-Ray (PA View)': 'X-Ray',
  'Urine Routine & Microscopic Examination': 'Urine Test',
};
const PAYMENT_METHOD = (m) => (/upi/i.test(m) ? 'UPI' : /card/i.test(m) ? 'Card' : /cash/i.test(m) ? 'Cash' : m);
const PROVIDER = (p) =>
  /star health/i.test(p) ? 'Star Health Insurance'
    : /hdfc/i.test(p) ? 'HDFC ERGO'
      : /icici/i.test(p) ? 'ICICI Lombard'
        : /care health/i.test(p) ? 'Care Health Insurance'
          : p;
// keep the demo medicine list compact (the database already has 40) - every medicine used by a prescription is included
const KEEP_MEDICINE_IDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 19, 25];

const hash = (pw) => bcrypt.hash(pw, 10);

async function findOne(sql, params) {
  const rows = await query(sql, params);
  return rows[0] || null;
}

async function ensureUser({ name, email, password, role, phone }) {
  const existing = await findOne('SELECT user_id FROM users WHERE email = ?', [email]);
  if (existing) return existing.user_id;
  const res = await query(
    'INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)',
    [name, email, await hash(password), await dbRole(role), phone]
  );
  bump(`users (${role})`);
  return res.insertId;
}

export async function seed() {
  console.log('Step 1/3: schema migration');
  await migrate({});

  console.log('\nStep 2/3: inserting demo data (existing rows are never modified)');

  // ---------- staff accounts ----------
  await ensureUser({ name: 'Admin User', email: 'admin@hospital.com', password: 'Admin@123', role: 'ADMIN', phone: '9876500001' }); // no-op if your admin already exists
  await ensureUser({ name: 'Dr. Kavita Reddy (Head Pathologist)', email: 'lab@hospital.com', password: 'Lab@123', role: 'LAB', phone: '9849911024' });

  // ---------- specializations ----------
  const specId = {};
  for (const s of demo.specializations) {
    const name = SPEC_MAP[s.specialization_name] || s.specialization_name;
    let row = await findOne('SELECT specialization_id FROM specializations WHERE specialization_name = ?', [name]);
    if (!row) {
      const r = await query('INSERT INTO specializations (specialization_name) VALUES (?)', [name]);
      row = { specialization_id: r.insertId };
      bump('specializations');
    }
    specId[s.specialization_id] = row.specialization_id;
  }

  // ---------- doctors ----------
  const docCols = (await query("SELECT COLUMN_NAME c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME='doctors'", [config.db.database])).map((r) => r.c);
  const hasSpecText = docCols.includes('specialization');
  const doctorId = {};
  for (const d of demo.doctors) {
    const email = d.doctor_id === 1 ? 'doctor@hospital.com' : d.email; // demo "Doctor" login
    const userId = await ensureUser({ name: d.name, email, password: 'Doctor@123', role: 'DOCTOR', phone: digits10(d.phone) });
    let row = await findOne('SELECT doctor_id FROM doctors WHERE user_id = ?', [userId]);
    if (!row) {
      const specName = SPEC_MAP[d.specialization_name] || d.specialization_name;
      const cols = ['user_id', 'specialization_id', 'qualification', 'experience_years', 'availability_status'];
      const vals = [userId, specId[d.specialization_id], stripParens(d.qualification), d.experience_years, AVAILABILITY[d.availability_status] || 'Available'];
      if (hasSpecText) { cols.push('specialization'); vals.push(specName); }
      const r = await query(`INSERT INTO doctors (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, vals);
      row = { doctor_id: r.insertId };
      bump('doctors');
    }
    doctorId[d.doctor_id] = row.doctor_id;
  }

  // ---------- patients ----------
  const patientId = {};
  for (const p of demo.patients) {
    const userId = await ensureUser({ name: p.name, email: p.email, password: 'Patient@123', role: 'PATIENT', phone: digits10(p.phone) });
    let row = await findOne('SELECT patient_id FROM patients WHERE user_id = ?', [userId]);
    if (!row) {
      const r = await query(
        `INSERT INTO patients (user_id, date_of_birth, gender, blood_group, address, emergency_contact, city, medical_history)
         VALUES (?,?,?,?,?,?,?,?)`,
        [userId, p.date_of_birth, p.gender, p.blood_group, p.address, digits10(p.emergency_contact), p.city, p.medical_history || null]
      );
      row = { patient_id: r.insertId };
      bump('patients');
    }
    patientId[p.patient_id] = row.patient_id;
  }

  // ---------- medicines ----------
  const medId = {};
  for (const m of demo.medicines.filter((x) => KEEP_MEDICINE_IDS.includes(x.medicine_id))) {
    let row = await findOne('SELECT medicine_id FROM medicines WHERE medicine_name = ?', [m.medicine_name]);
    if (!row) {
      const r = await query(
        'INSERT INTO medicines (medicine_name, category, manufacturer, price, quantity, expiry_date) VALUES (?,?,?,?,?,?)',
        [m.medicine_name, 'Tablet', m.manufacturer, m.price, m.quantity, m.expiry_date]
      );
      row = { medicine_id: r.insertId };
      bump('medicines');
    }
    medId[m.medicine_id] = row.medicine_id;
  }

  // ---------- lab tests (re-use the existing equivalents) ----------
  const testId = {};
  for (const t of demo.labTests) {
    const name = LABTEST_MAP[t.test_name] || t.test_name;
    let row = await findOne('SELECT test_id FROM lab_tests WHERE test_name = ?', [name]);
    if (!row) {
      const r = await query(
        'INSERT INTO lab_tests (test_name, test_description, test_cost, sample_type, test_status) VALUES (?,?,?,?,?)',
        [name, t.test_description, t.test_cost, t.sample_type, t.test_status || 'Active']
      );
      row = { test_id: r.insertId };
      bump('lab_tests');
    }
    testId[t.test_id] = row.test_id;
  }

  // ---------- prescriptions ----------
  for (const x of demo.prescriptions) {
    if (!medId[x.medicine_id]) continue;
    const key = [patientId[x.patient_id], doctorId[x.doctor_id], medId[x.medicine_id], x.prescription_date];
    const ex = await findOne('SELECT prescription_id FROM prescriptions WHERE patient_id=? AND doctor_id=? AND medicine_id=? AND prescription_date=?', key);
    if (!ex) {
      await query('INSERT INTO prescriptions (patient_id, doctor_id, medicine_id, dosage, duration, prescription_date) VALUES (?,?,?,?,?,?)',
        [...key.slice(0, 3), x.dosage, x.duration, x.prescription_date]);
      bump('prescriptions');
    }
  }

  // ---------- medical records ----------
  for (const x of demo.medicalRecords) {
    const ex = await findOne('SELECT record_id FROM medical_records WHERE patient_id=? AND diagnosis=? AND record_date=?', [patientId[x.patient_id], x.diagnosis, x.record_date]);
    if (!ex) {
      await query('INSERT INTO medical_records (patient_id, diagnosis, symptoms, treatment, doctor_notes, record_date) VALUES (?,?,?,?,?,?)',
        [patientId[x.patient_id], x.diagnosis, x.symptoms, x.treatment, x.doctor_notes, x.record_date]);
      bump('medical_records');
    }
  }

  // ---------- lab samples ----------
  for (const x of demo.labSamples) {
    const ex = await findOne('SELECT sample_code FROM lab_samples WHERE sample_code = ?', [x.sample_id]);
    if (!ex) {
      await query(
        `INSERT INTO lab_samples (sample_code, patient_id, test_id, sample_type, collection_date, collection_time, collection_status, collected_by)
         VALUES (?,?,?,?,?,?,?,?)`,
        [x.sample_id, patientId[x.patient_id], testId[x.test_id], x.sample_type, x.collection_date, x.collection_time, x.collection_status, x.collected_by]
      );
      bump('lab_samples');
    }
  }

  // ---------- lab reports ----------
  for (const x of demo.labReports) {
    const key = [patientId[x.patient_id], testId[x.test_id], x.report_date];
    const ex = await findOne('SELECT report_id FROM lab_reports WHERE patient_id=? AND test_id=? AND report_date=?', key);
    if (!ex) {
      await query(
        'INSERT INTO lab_reports (patient_id, test_id, doctor_id, result, report_date, remarks, file_attachment) VALUES (?,?,?,?,?,?,?)',
        [key[0], key[1], doctorId[x.doctor_id], x.result, x.report_date, x.remarks, stripParens(x.file_attachment)]
      );
      bump('lab_reports');
    }
  }

  // ---------- bills & payments ----------
  const billId = {};
  for (const x of demo.bills) {
    const key = [patientId[x.patient_id], x.bill_date, x.total_amount];
    let row = await findOne('SELECT bill_id FROM bills WHERE patient_id=? AND bill_date=? AND total_amount=?', key);
    if (!row) {
      const r = await query('INSERT INTO bills (patient_id, bill_date, total_amount, payment_status) VALUES (?,?,?,?)', [...key, x.payment_status]);
      row = { bill_id: r.insertId };
      bump('bills');
    }
    billId[x.bill_id] = row.bill_id;
  }
  for (const x of demo.payments) {
    const key = [billId[x.bill_id], x.amount_paid, x.payment_date];
    const ex = await findOne('SELECT payment_id FROM payments WHERE bill_id=? AND amount_paid=? AND payment_date=?', key);
    if (!ex) {
      await query('INSERT INTO payments (bill_id, amount_paid, payment_method, payment_date) VALUES (?,?,?,?)',
        [key[0], key[1], PAYMENT_METHOD(x.payment_method), key[2]]);
      bump('payments');
    }
  }

  // ---------- insurance ----------
  for (const x of demo.insurance) {
    const ex = await findOne('SELECT insurance_id FROM insurance WHERE policy_number = ?', [x.policy_number]);
    if (!ex) {
      await query('INSERT INTO insurance (patient_id, insurance_provider, policy_number, coverage_amount, claim_status) VALUES (?,?,?,?,?)',
        [patientId[x.patient_id], PROVIDER(x.insurance_provider), x.policy_number, x.coverage_amount, x.claim_status]);
      bump('insurance');
    }
  }

  console.log('\nStep 3/3: done. Rows added this run:');
  if (!Object.keys(stats).length) console.log('  (nothing - demo data was already present)');
  for (const [k, v] of Object.entries(stats)) console.log(`  ${k.padEnd(22)} +${v}`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  seed()
    .then(() => pool.end())
    .catch(async (err) => {
      console.error('SEED FAILED:', err.message);
      await pool.end();
      process.exit(1);
    });
}
