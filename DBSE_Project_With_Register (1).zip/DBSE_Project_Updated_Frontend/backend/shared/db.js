import mysql from 'mysql2/promise';
import { config, canonicalRole } from './config.js';

// One pool per service process. dateStrings keeps DATE columns as 'YYYY-MM-DD'
// (no timezone shifting) and decimalNumbers returns DECIMAL as JS numbers.
export const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,
  decimalNumbers: true,
});

export async function query(sql, params = []) {
  const [rows] = await pool.query(sql, params);
  return rows;
}

export async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

// Does the given column exist on the table in the live database?
export async function hasColumn(table, column) {
  const rows = await query(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1`,
    [config.db.database, table, column]
  );
  return rows.length > 0;
}

// Self-registration lets people pick their own username. Adds users.username (unique) if the
// live database does not have it yet. Safe to call repeatedly.
export async function ensureUsernameColumn() {
  if (!(await hasColumn('users', 'username'))) {
    await query('ALTER TABLE users ADD COLUMN username VARCHAR(50) NULL');
  }
  const idx = await query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND COLUMN_NAME = 'username' AND NON_UNIQUE = 0 LIMIT 1`,
    [config.db.database]
  );
  if (!idx.length) await query('ALTER TABLE users ADD UNIQUE KEY uq_users_username (username)');
}

// The exact spelling the live `users.role` column uses for a role ('PATIENT' -> 'Patient' etc.),
// read from the column's ENUM definition or from existing rows. Falls back to the canonical key.
const roleCache = {};
export async function dbRole(canon) {
  if (roleCache[canon]) return roleCache[canon];
  let found = null;
  const [col] = await query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role'`,
    [config.db.database]
  );
  if (col && /^enum\(/i.test(col.COLUMN_TYPE)) {
    const vals = [...col.COLUMN_TYPE.matchAll(/'((?:[^']|'')*)'/g)].map((m) => m[1].replace(/''/g, "'"));
    found = vals.find((v) => canonicalRole(v) === canon) || null;
  }
  if (!found) {
    const rows = await query('SELECT DISTINCT role FROM users');
    found = rows.map((r) => r.role).find((v) => canonicalRole(v) === canon) || null;
  }
  return (roleCache[canon] = found || canon);
}
