import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { config } from './config.js';
import { pool } from './db.js';

// Wraps async route handlers so thrown errors reach the error middleware.
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Translate MySQL errors into friendly HTTP responses.
export function errorHandler(err, req, res, _next) {
  if (err instanceof HttpError) return res.status(err.status).json({ message: err.message });
  switch (err.code) {
    case 'ER_DUP_ENTRY':
      return res.status(409).json({ message: 'A record with the same unique value (e.g. email or policy number) already exists.' });
    case 'ER_ROW_IS_REFERENCED_2':
    case 'ER_ROW_IS_REFERENCED':
      return res.status(409).json({ message: 'Cannot delete: this record is referenced by other records.' });
    case 'ER_NO_REFERENCED_ROW_2':
    case 'ER_NO_REFERENCED_ROW':
      return res.status(400).json({ message: 'Invalid reference: a related record (patient, doctor, test, ...) does not exist.' });
    case 'ER_BAD_NULL_ERROR':
      return res.status(400).json({ message: 'A required field is missing.' });
    default:
      console.error(`[${req.method} ${req.originalUrl}]`, err);
      return res.status(500).json({ message: 'Internal server error.' });
  }
}

// Standard Express app for a microservice: JSON body, security headers,
// request logging, /health and the shared error handler.
export function createService(name) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet());
  app.use(cors({ origin: config.corsOrigin }));
  app.use(express.json({ limit: '1mb' }));
  app.use(morgan(`[${name}] :method :url :status :response-time ms`));

  app.get('/health', async (_req, res) => {
    try {
      await pool.query('SELECT 1');
      res.json({ service: name, status: 'ok', db: 'connected' });
    } catch {
      res.status(503).json({ service: name, status: 'degraded', db: 'unreachable' });
    }
  });

  const listen = (port) => {
    app.use((req, res) => res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` }));
    app.use(errorHandler);
    return app.listen(port, () => console.log(`[${name}] listening on :${port}`));
  };

  return { app, listen };
}

// Pick only whitelisted keys that were actually sent ('' becomes NULL).
export function pick(body, keys) {
  const out = {};
  for (const k of keys) if (body[k] !== undefined) out[k] = body[k] === '' ? null : body[k];
  return out;
}

export const isId = (v) => /^\d+$/.test(String(v));

// For Patient tokens, every read is restricted to the patient's own records.
export function patientScope(req) {
  if (req.user?.role !== 'Patient') return {};
  if (!req.user.patient_id) throw new HttpError(403, 'No patient profile is linked to this account.');
  return { patientId: req.user.patient_id };
}
