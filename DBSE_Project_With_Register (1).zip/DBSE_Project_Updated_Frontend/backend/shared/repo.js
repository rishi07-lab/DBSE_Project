// Read-side SQL (JOINs) shared by the domain services and the analytics service.
// Every function returns rows shaped exactly like the objects the React app expects
// (e.g. prescriptions carry patient_name, doctor_name, medicine_name, expiry_date).
import { query } from './db.js';

function where(conds) {
  const parts = conds.filter(Boolean);
  return parts.length ? `WHERE ${parts.join(' AND ')}` : '';
}

export async function listPatients({ id, patientId } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('p.patient_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('p.patient_id = ?'); params.push(patientId); }
  return query(
    `SELECT p.patient_id, p.user_id, u.name, u.email, u.phone,
            p.date_of_birth, TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) AS age,
            p.gender, p.blood_group, p.city, p.address, p.emergency_contact, p.medical_history
       FROM patients p JOIN users u ON u.user_id = p.user_id
       ${where(conds)} ORDER BY p.patient_id DESC`,
    params
  );
}

export async function listDoctors({ id } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('d.doctor_id = ?'); params.push(id); }
  return query(
    `SELECT d.doctor_id, d.user_id, u.name, u.email, u.phone,
            d.specialization_id, s.specialization_name,
            d.qualification, d.experience_years, d.availability_status
       FROM doctors d
       JOIN users u ON u.user_id = d.user_id
       LEFT JOIN specializations s ON s.specialization_id = d.specialization_id
       ${where(conds)} ORDER BY d.doctor_id DESC`,
    params
  );
}

export async function listMedicalRecords({ id, patientId } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('m.record_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('m.patient_id = ?'); params.push(patientId); }
  return query(
    `SELECT m.record_id, m.patient_id, u.name AS patient_name, m.diagnosis, m.symptoms,
            m.treatment, m.doctor_notes, m.record_date
       FROM medical_records m
       JOIN patients p ON p.patient_id = m.patient_id
       JOIN users u ON u.user_id = p.user_id
       ${where(conds)} ORDER BY m.record_date DESC, m.record_id DESC`,
    params
  );
}

export async function listPrescriptions({ id, patientId, limit } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('rx.prescription_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('rx.patient_id = ?'); params.push(patientId); }
  const lim = limit ? `LIMIT ${Number(limit)}` : '';
  return query(
    `SELECT rx.prescription_id, rx.patient_id, pu.name AS patient_name,
            rx.doctor_id, du.name AS doctor_name,
            rx.medicine_id, m.medicine_name, m.expiry_date,
            rx.dosage, rx.duration, rx.prescription_date
       FROM prescriptions rx
       JOIN patients p ON p.patient_id = rx.patient_id
       JOIN users pu ON pu.user_id = p.user_id
       JOIN doctors d ON d.doctor_id = rx.doctor_id
       JOIN users du ON du.user_id = d.user_id
       JOIN medicines m ON m.medicine_id = rx.medicine_id
       ${where(conds)} ORDER BY rx.prescription_date DESC, rx.prescription_id DESC ${lim}`,
    params
  );
}

export async function listLabReports({ id, patientId, limit } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('r.report_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('r.patient_id = ?'); params.push(patientId); }
  const lim = limit ? `LIMIT ${Number(limit)}` : '';
  return query(
    `SELECT r.report_id, r.patient_id, pu.name AS patient_name,
            r.test_id, t.test_name, r.doctor_id, du.name AS doctor_name,
            r.result, r.report_date, r.remarks, r.file_attachment, r.file_size
       FROM lab_reports r
       JOIN patients p ON p.patient_id = r.patient_id
       JOIN users pu ON pu.user_id = p.user_id
       JOIN lab_tests t ON t.test_id = r.test_id
       JOIN doctors d ON d.doctor_id = r.doctor_id
       JOIN users du ON du.user_id = d.user_id
       ${where(conds)} ORDER BY r.report_date DESC, r.report_id DESC ${lim}`,
    params
  );
}

export async function listLabSamples({ id, limit } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('s.sample_code = ?'); params.push(id); }
  const lim = limit ? `LIMIT ${Number(limit)}` : '';
  return query(
    `SELECT s.sample_code AS sample_id, s.patient_id, pu.name AS patient_name,
            s.test_id, t.test_name, s.sample_type, s.collection_date, s.collection_time,
            s.collection_status, s.collected_by
       FROM lab_samples s
       JOIN patients p ON p.patient_id = s.patient_id
       JOIN users pu ON pu.user_id = p.user_id
       JOIN lab_tests t ON t.test_id = s.test_id
       ${where(conds)} ORDER BY s.collection_date DESC, s.sample_code DESC ${lim}`,
    params
  );
}

export async function listBills({ id, patientId } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('b.bill_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('b.patient_id = ?'); params.push(patientId); }
  return query(
    `SELECT b.bill_id, b.patient_id, u.name AS patient_name, b.bill_date, b.total_amount, b.payment_status
       FROM bills b
       JOIN patients p ON p.patient_id = b.patient_id
       JOIN users u ON u.user_id = p.user_id
       ${where(conds)} ORDER BY b.bill_date DESC, b.bill_id DESC`,
    params
  );
}

export async function listPayments({ id, patientId } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('pay.payment_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('b.patient_id = ?'); params.push(patientId); }
  return query(
    `SELECT pay.payment_id, pay.bill_id, b.patient_id, u.name AS patient_name,
            pay.amount_paid, pay.payment_method, pay.payment_date
       FROM payments pay
       JOIN bills b ON b.bill_id = pay.bill_id
       JOIN patients p ON p.patient_id = b.patient_id
       JOIN users u ON u.user_id = p.user_id
       ${where(conds)} ORDER BY pay.payment_date DESC, pay.payment_id DESC`,
    params
  );
}

export async function listInsurance({ id, patientId } = {}) {
  const params = [];
  const conds = [];
  if (id != null) { conds.push('i.insurance_id = ?'); params.push(id); }
  if (patientId != null) { conds.push('i.patient_id = ?'); params.push(patientId); }
  return query(
    `SELECT i.insurance_id, i.patient_id, u.name AS patient_name, i.insurance_provider,
            i.policy_number, i.coverage_amount, i.claim_status
       FROM insurance i
       JOIN patients p ON p.patient_id = i.patient_id
       JOIN users u ON u.user_id = p.user_id
       ${where(conds)} ORDER BY i.insurance_id DESC`,
    params
  );
}
