import React from 'react';
import { MenuIcon, PlusIcon } from './Icons';

const PAGE_TITLES = {
  // Doctor Portal
  'doctor-dashboard': 'Clinical Overview & Dashboard',
  'patients': 'Patients Directory',
  'medical-records': 'Clinical Medical Records',
  'prescriptions': 'Pharmacy Prescriptions',
  'lab-reports': 'Patient Pathology Reports',

  // Admin Portal
  'dashboard': 'Hospital Administration Overview',
  'doctors': 'Medical Doctors & Specialists',
  'specializations': 'Medical Departments & Specializations',
  'medicines': 'Medicines & Inventory Control',
  'lab-tests': 'Laboratory Diagnostic Tests',
  'bills': 'Patient Billing & Invoices',
  'payments': 'Payment Transactions History',
  'insurance': 'Medical Insurance & Claims',

  // Patient Portal
  'patient-dashboard': 'My Patient Dashboard',
  'patient-profile': 'My Profile',
  'patient-records': 'My Medical Records',
  'patient-prescriptions': 'My Prescriptions',
  'patient-medicines': 'My Prescribed Medicines',
  'patient-lab-reports': 'My Laboratory Reports',
  'patient-bills': 'My Bills & Payments',
  'patient-hospital-info': 'Hospital Information',

  // Laboratory Staff Portal
  'lab-dashboard': 'Laboratory Diagnostic Center Dashboard',
  'lab-samples': 'Laboratory Sample Collection',
  'lab-results': 'Laboratory Test Results Entry',
  'lab-upload': 'Upload Patient Laboratory Reports',
};

const ROLE_PORTAL_LABEL = {
  'Doctor': 'Doctor Portal',
  'Admin': 'Admin Portal',
  'Patient': 'Patient Portal',
  'Laboratory Staff': 'Laboratory Portal',
};

const QUICK_ACTION_LABEL = {
  'Doctor': 'Admit Patient',
  'Admin': 'Add Doctor',
  'Patient': 'My Prescriptions',
  'Laboratory Staff': 'New Sample',
};

export default function Navbar({ currentPage, onToggleSidebar, user, onQuickAction }) {
  const role = user?.role || 'Admin';

  const todayStr = new Date().toLocaleDateString('en-IN', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  return (
    <header className="top-navbar">
      <div className="navbar-left">
        <button className="menu-toggle-btn" onClick={onToggleSidebar} aria-label="Toggle menu">
          <MenuIcon size={20} />
        </button>
        <div>
          <h1 className="navbar-page-title">{PAGE_TITLES[currentPage] || 'Dashboard'}</h1>
        </div>
      </div>

      <div className="navbar-right">
        {/* Role / Portal Badge */}
        <div className="hospital-badge">
          <span style={{ width: '8px', height: '8px', borderRadius: '50%', backgroundColor: '#0ea5e9', display: 'inline-block' }} />
          <span>{ROLE_PORTAL_LABEL[role] || 'Hospital Portal'}</span>
        </div>

        {/* Live database indicator */}
        <div
          className="hospital-badge"
          style={{ background: '#dcfce7', color: '#166534' }}
          title="Connected to the MySQL hospital_management database via the API gateway"
        >
          <span>Live DB</span>
        </div>

        {/* Date Display */}
        <div style={{ fontSize: '13px', color: '#64748b', fontWeight: '500' }}>
          {todayStr}
        </div>

        {/* Role-Aware Quick Action Button */}
        {onQuickAction && (
          <button
            className="btn btn-primary btn-sm"
            onClick={onQuickAction}
            title="Quick Action"
          >
            <PlusIcon size={16} />
            <span>{QUICK_ACTION_LABEL[role] || 'Quick Action'}</span>
          </button>
        )}
      </div>
    </header>
  );
}
