import React, { useState, useEffect } from 'react';
import { API } from './services/api';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';

// Auth
import Login from './pages/Login';

// Doctor Pages (Clinical)
import DoctorDashboard from './pages/DoctorDashboard';
import Patients from './pages/Patients';
import MedicalRecords from './pages/MedicalRecords';
import Prescriptions from './pages/Prescriptions';
import LabReports from './pages/LabReports';

// Admin Pages (Administrative)
import Dashboard from './pages/Dashboard';
import Doctors from './pages/Doctors';
import Specializations from './pages/Specializations';
import Medicines from './pages/Medicines';
import LabTests from './pages/LabTests';
import Bills from './pages/Bills';
import Payments from './pages/Payments';
import Insurance from './pages/Insurance';

// Patient Portal Pages
import PatientDashboard from './pages/PatientDashboard';
import PatientViews from './pages/PatientViews';

// Laboratory Staff Portal Pages
import LabDashboard from './pages/LabDashboard';
import LabSampleCollection from './pages/LabSampleCollection';
import LabTestResults from './pages/LabTestResults';
import LabUploadReport from './pages/LabUploadReport';

// -----------------------------------------------------------------------
// Role-Based Route Access Control
// -----------------------------------------------------------------------
// Every valid "page" key in the app must be listed under exactly the
// role(s) permitted to view it. App.jsx uses this map as a frontend route
// guard: if a user's current page is not present in their role's list,
// they are redirected to their role's default landing page.
const ROLE_HOME = {
  'Doctor': 'doctor-dashboard',
  'Admin': 'dashboard',
  'Patient': 'patient-dashboard',
  'Laboratory Staff': 'lab-dashboard',
};

const ROLE_ALLOWED_PAGES = {
  // Doctor: clinical workflow only
  'Doctor': [
    'doctor-dashboard',
    'patients',
    'medical-records',
    'prescriptions',
    'lab-reports',
  ],
  // Admin: hospital administration only
  'Admin': [
    'dashboard',
    'doctors',
    'specializations',
    'medicines',
    'lab-tests',
    'bills',
    'payments',
    'insurance',
  ],
  'Patient': [
    'patient-dashboard',
    'patient-profile',
    'patient-records',
    'patient-prescriptions',
    'patient-medicines',
    'patient-lab-reports',
    'patient-bills',
    'patient-hospital-info',
  ],
  'Laboratory Staff': [
    'lab-dashboard',
    'lab-tests',
    'lab-samples',
    'lab-results',
    'lab-upload',
    'lab-reports',
  ],
};

export default function App() {
  const [user, setUser] = useState(null);
  const [currentPage, setCurrentPage] = useState('doctor-dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    // Validate any stored JWT with the server before showing the app
    let cancelled = false;
    (async () => {
      const existing = await API.restoreSession();
      if (cancelled) return;
      if (existing) {
        setUser(existing);
        setCurrentPage(ROLE_HOME[existing.role] || 'doctor-dashboard');
      }
      setAuthChecked(true);
    })();
    return () => { cancelled = true; };
  }, []);

  const handleLoginSuccess = (loggedInUser) => {
    setUser(loggedInUser);
    setCurrentPage(ROLE_HOME[loggedInUser.role] || 'doctor-dashboard');
  };

  const handleLogout = () => {
    API.logout();
    setUser(null);
    setCurrentPage('doctor-dashboard');
  };

  // -----------------------------------------------------------------------
  // FRONTEND ROUTE GUARD
  // -----------------------------------------------------------------------
  useEffect(() => {
    if (!user) return;
    const allowed = ROLE_ALLOWED_PAGES[user.role] || [];
    if (!allowed.includes(currentPage)) {
      setCurrentPage(ROLE_HOME[user.role] || 'doctor-dashboard');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, currentPage]);

  if (!authChecked) {
    return null;
  }

  if (!user) {
    return <Login onLoginSuccess={handleLoginSuccess} />;
  }

  const allowedPages = ROLE_ALLOWED_PAGES[user.role] || [];
  const safePage = allowedPages.includes(currentPage) ? currentPage : ROLE_HOME[user.role];

  // Doctor: clinical pages
  const renderDoctorPage = () => {
    switch (safePage) {
      case 'doctor-dashboard':
        return <DoctorDashboard onNavigate={setCurrentPage} />;
      case 'patients':
        return <Patients />;
      case 'medical-records':
        return <MedicalRecords />;
      case 'prescriptions':
        return <Prescriptions />;
      case 'lab-reports':
        return <LabReports />;
      default:
        return <DoctorDashboard onNavigate={setCurrentPage} />;
    }
  };

  // Admin: administrative pages
  const renderAdminPage = () => {
    switch (safePage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'doctors':
        return <Doctors />;
      case 'specializations':
        return <Specializations />;
      case 'medicines':
        return <Medicines />;
      case 'lab-tests':
        return <LabTests />;
      case 'bills':
        return <Bills />;
      case 'payments':
        return <Payments />;
      case 'insurance':
        return <Insurance />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  const renderPatientPage = () => {
    switch (safePage) {
      case 'patient-dashboard':
        return <PatientDashboard user={user} onNavigate={setCurrentPage} />;
      case 'patient-profile':
      case 'patient-records':
      case 'patient-prescriptions':
      case 'patient-medicines':
      case 'patient-lab-reports':
      case 'patient-bills':
      case 'patient-hospital-info':
        return <PatientViews viewType={safePage} user={user} />;
      default:
        return <PatientDashboard user={user} onNavigate={setCurrentPage} />;
    }
  };

  const renderLabStaffPage = () => {
    switch (safePage) {
      case 'lab-dashboard':
        return <LabDashboard onNavigate={setCurrentPage} />;
      case 'lab-tests':
        return <LabTests />;
      case 'lab-samples':
        return <LabSampleCollection />;
      case 'lab-results':
        return <LabTestResults />;
      case 'lab-upload':
        return <LabUploadReport />;
      case 'lab-reports':
        return <LabReports />;
      default:
        return <LabDashboard onNavigate={setCurrentPage} />;
    }
  };

  const renderPage = () => {
    if (user.role === 'Doctor') return renderDoctorPage();
    if (user.role === 'Admin') return renderAdminPage();
    if (user.role === 'Patient') return renderPatientPage();
    if (user.role === 'Laboratory Staff') return renderLabStaffPage();
    return null;
  };

  const handleQuickAction = () => {
    if (user.role === 'Doctor') {
      setCurrentPage('patients');
    } else if (user.role === 'Admin') {
      setCurrentPage('doctors');
    } else if (user.role === 'Patient') {
      setCurrentPage('patient-prescriptions');
    } else if (user.role === 'Laboratory Staff') {
      setCurrentPage('lab-samples');
    }
  };

  return (
    <div className="app-layout">
      <Sidebar
        currentPage={safePage}
        setCurrentPage={setCurrentPage}
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        user={user}
        onLogout={handleLogout}
      />

      <div className="main-wrapper">
        <Navbar
          currentPage={safePage}
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          user={user}
          onQuickAction={handleQuickAction}
        />

        <main>
          {renderPage()}
        </main>
      </div>
    </div>
  );
}
