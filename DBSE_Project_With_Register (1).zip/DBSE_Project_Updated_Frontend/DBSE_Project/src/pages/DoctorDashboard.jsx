import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  PatientsIcon,
  MedicalRecordIcon,
  PrescriptionIcon,
  LabReportIcon,
  PlusIcon,
} from '../components/Icons';

export default function DoctorDashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      const data = await API.getDoctorDashboardStats();
      setStats(data);
      setLoading(false);
    }
    loadStats();
  }, []);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading clinical dashboard...
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: 'Registered Patients',
      value: stats.totalPatients,
      icon: PatientsIcon,
      bgColor: '#e0f2fe',
      iconColor: '#0284c7',
      page: 'patients',
    },
    {
      label: 'Prescriptions Issued',
      value: stats.totalPrescriptions,
      icon: PrescriptionIcon,
      bgColor: '#ede9fe',
      iconColor: '#7c3aed',
      page: 'prescriptions',
    },
    {
      label: 'Medical Records',
      value: stats.totalMedicalRecords,
      icon: MedicalRecordIcon,
      bgColor: '#d1fae5',
      iconColor: '#059669',
      page: 'medical-records',
    },
    {
      label: 'Lab Reports',
      value: stats.totalLabReports,
      icon: LabReportIcon,
      bgColor: '#fee2e2',
      iconColor: '#dc2626',
      page: 'lab-reports',
    },
  ];

  return (
    <div className="page-container">
      {/* Page Heading */}
      <div className="page-header">
        <div>
          <h1>Clinical Overview</h1>
          <p>Active caseloads, prescriptions, and clinical records at a glance.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('patients')}>
            <PlusIcon size={16} />
            <span>Admit Patient</span>
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('prescriptions')}>
            <PlusIcon size={16} />
            <span>New Prescription</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="stats-grid">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="stat-card"
              style={{ cursor: 'pointer' }}
              onClick={() => onNavigate(card.page)}
            >
              <div
                className="stat-icon-wrapper"
                style={{ backgroundColor: card.bgColor, color: card.iconColor }}
              >
                <Icon size={26} />
              </div>
              <div className="stat-card-info">
                <span className="stat-card-value">{card.value}</span>
                <span className="stat-card-label">{card.label}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Lower Section: Recent Prescriptions & Quick Module Launch */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>

        {/* Recent Prescriptions Table Card */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>
              Recent Prescriptions Issued
            </h3>
            <button
              className="btn btn-sm btn-secondary"
              onClick={() => onNavigate('prescriptions')}
            >
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Doctor</th>
                  <th>Medicine</th>
                  <th>Dosage</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentPrescriptions?.length > 0 ? (
                  stats.recentPrescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td style={{ fontWeight: '600' }}>{p.patient_name}</td>
                      <td style={{ color: '#0284c7' }}>{p.doctor_name}</td>
                      <td>{p.medicine_name}</td>
                      <td><span className="badge badge-gray">{p.dosage}</span></td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>
                      No prescriptions recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Module Launch */}
        <div className="table-card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '16px' }}>
            Clinical Modules Quick Launch
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            {[
              { title: 'Patients', desc: 'Patient directory', page: 'patients' },
              { title: 'Medical Records', desc: 'Diagnoses & history', page: 'medical-records' },
              { title: 'Prescriptions', desc: 'Issue & track Rx', page: 'prescriptions' },
              { title: 'Lab Reports', desc: 'Pathology results', page: 'lab-reports' },
            ].map((m, i) => (
              <div
                key={i}
                onClick={() => onNavigate(m.page)}
                style={{
                  padding: '14px',
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  transition: 'all 0.18s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#e0f2fe';
                  e.currentTarget.style.borderColor = '#0284c7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#f8fafc';
                  e.currentTarget.style.borderColor = '#e2e8f0';
                }}
              >
                <div style={{ fontWeight: '700', fontSize: '13.5px', color: '#0f172a' }}>{m.title}</div>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
