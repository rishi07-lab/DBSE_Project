# CarePulse HMS — React + Express microservices + MySQL

The React app now talks to **real APIs** backed by your **existing** MySQL database
`hospital_management` (MySQL 8, `localhost:3306`, user `root`, password `Root` — see `backend/.env`).
Authentication is **JWT**; every role (Admin, Doctor, Patient, Laboratory Staff) has its own dashboard
and its own server-enforced permissions.

```
React (Vite :5173)  ──/api──►  API Gateway :5000 ──► auth-service      :5001  login / JWT / change password
                               (verifies JWT)     ├─► clinical-service  :5002  patients, doctors, specializations, medical records, prescriptions
                                                  ├─► pharmacy-service  :5003  medicines & stock
                                                  ├─► lab-service       :5004  lab tests, samples, reports
                                                  ├─► billing-service   :5005  bills, payments, insurance
                                                  └─► analytics-service :5006  role dashboards
                                                                  │
                                                       MySQL 8  hospital_management  (existing DB)
```
All services share the one existing database (you asked to keep using it); each service owns its own tables
and every service re-verifies the JWT, so nothing is reachable without a valid token.

## Run it (Windows)
1. Make sure MySQL is running (port 3306).
2. Double-click **`setup-and-run.bat`** — it installs packages, applies the schema changes + demo data,
   starts the backend, then the frontend. Open http://localhost:5173.

### Or manually
```bash
cd backend
npm install
npm run db:migrate:dry   # OPTIONAL: prints exactly what would change, touches nothing
npm run db:seed          # migration + demo data (safe to re-run)
npm start                # gateway :5000 + all services
npm test                 # optional end-to-end checks (creates and removes its own test rows)

cd ../DBSE_Project
npm install
npm run dev              # http://localhost:5173
```

## Self-registration (new patients)
The login page has a **Create an account** link. New users pick their own username, email and password and are
signed in immediately as a **Patient** (staff accounts are still created by an Admin).

- `POST /api/auth/register` `{name, username, email, phone?, password}` → `{token, user}` (public, rate-limited)
- Username: 3-30 chars (`a-z 0-9 . _ -`), unique. Password: 8+ chars with a letter and a number, stored as a bcrypt hash.
- Everyone can now sign in with **username or email** (`POST /api/auth/login`).
- A `users.username` column is added automatically (by `db:migrate` or when the auth service starts).

## Sample logins
| Role | Email | Password | Dashboard |
|---|---|---|---|
| Admin | admin@hospital.com | `admin123` (your existing password, unchanged) | Admin dashboard |
| Doctor | doctor@hospital.com | `Doctor@123` | Doctor dashboard (Dr. Rajesh Sharma) |
| Patient | patient@hospital.com | `Patient@123` | Patient dashboard (Ramesh Kumar Verma) |
| Lab Staff | lab@hospital.com | `Lab@123` | Laboratory dashboard |

Your **existing** users keep their old passwords (e.g. `doctor123`, `pass123`) — they were converted to bcrypt
hashes, so the same passwords still work. Accounts created from the UI get `DEFAULT_PATIENT_PASSWORD` /
`DEFAULT_DOCTOR_PASSWORD` from `backend/.env`.

## What was changed in your database (nothing is dropped or deleted)
`npm run db:migrate:dry` shows this list live. Summary:
- `users`: `password` now stores bcrypt hashes (plain-text values are hashed in place); `phone` widened to 20.
  New role value `LAB` (lab staff).
- `patients`: + `city`, + `medical_history`; `emergency_contact` widened to 100.
- `doctors`: + `specialization_id` (FK to `specializations`) filled from your existing text specialization;
  the old text column is kept (made nullable) and kept in sync.
- `lab_tests`: + `sample_type`, + `test_status`. `lab_reports`: + `file_attachment`, + `file_size`.
- `lab_samples`: your existing table is kept; missing columns are added (`sample_code`, `collection_date`, …).
- Demo data is **added alongside** yours (+1 lab user, +12 doctors, +10 patients, +12 medicines, 5 prescriptions, 3 records,
  5 lab samples, 3 lab reports, 5 bills, 3 payments, 4 policies). Rows are matched by natural keys, so re-running adds nothing twice.
- Demo data was normalised to match yours: 10-digit phones, medicine category `Tablet`, payment methods `UPI`/`Card`/`Cash`,
  existing lab-test names reused (no duplicate "Lipid Profile" etc.), specialization names aligned (`Gynecology`, `ENT`).

## Who can do what (enforced on the server)
| Resource | Admin | Doctor | Lab Staff | Patient |
|---|---|---|---|---|
| patients | R/W | R/W | R | own only (R) |
| doctors, specializations | R/W | R | R | – |
| medical records, prescriptions | – | R/W | – | own only (R) |
| medicines | R/W | R | – | – |
| lab tests | R/W | R | R/W | – |
| lab samples | – | R | R/W | – |
| lab reports | – | R/W | R/W | own only (R) |
| bills, payments, insurance | R/W | – | – | own only (R) |
| dashboards | admin | doctor | lab | patient |

## API (all under the gateway, `Authorization: Bearer <token>` except login)
- `POST /api/auth/login` `{email,password}` → `{token,user}` · `GET /api/auth/me` · `POST /api/auth/change-password`
- REST resources (`GET /`, `GET /:id`, `POST /`, `PUT /:id`, `DELETE /:id` where allowed):
  `/api/patients` `/api/doctors` `/api/specializations` `/api/medical-records` `/api/prescriptions`
  `/api/medicines` `/api/lab-tests` `/api/lab-samples` `/api/lab-reports` `/api/bills` `/api/payments` `/api/insurance`
- `GET /api/dashboard/{admin|doctor|patient|lab}` · `GET /api/health` (aggregated service health, public)

Errors are JSON `{message}` with proper codes: 400 validation, 401 no/expired token, 403 wrong role,
404, 409 duplicate or "still referenced by other records" (deleting something in use is refused, never cascaded).

## Docker (optional)
MySQL is **not** containerised — containers reach your existing MySQL via `host.docker.internal:3306`.
```bash
docker compose --profile tools run --rm db-seed   # one-time: migration + demo data
docker compose up --build                         # app on http://localhost:8080, gateway on :5000
```
MySQL must accept connections from Docker (check `bind-address` and that `root` may connect from the Docker network).

## Notes / limits
- Uploading a lab report stores the record (file name, size, findings), not the file itself — add S3/disk storage later.
- Change `JWT_SECRET` in `backend/.env` before any real deployment (a random one was generated for you), and use a
  non-root MySQL user with a real password outside local development.
- There is no appointment booking, by design (as in the original app).
