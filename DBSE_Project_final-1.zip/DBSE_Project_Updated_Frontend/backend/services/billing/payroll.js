// Staff payroll: salary + bank details (Admin) and "salary credited" info (Doctor / Laboratory Staff).
// Lives in the billing service (finance). Routes: /api/payroll
import { Router } from 'express';
import { query, ensurePayrollTables } from '../../shared/db.js';
import { canonicalRole } from '../../shared/config.js';
import { allow } from '../../shared/auth.js';
import { wrap, pick, HttpError, isId } from '../../shared/http.js';

const need = (cond, msg) => { if (!cond) throw new HttpError(400, msg); };
const today = () => new Date().toISOString().slice(0, 10);
const thisMonth = () => today().slice(0, 7);
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;
const IFSC_RE = /^[A-Z]{4}0[A-Z0-9]{6}$/;
const ACCT_RE = /^\d{9,18}$/;
const MODES = ['Bank Transfer', 'NEFT', 'RTGS', 'IMPS', 'UPI', 'Cheque'];

const last4 = (n) => (n ? String(n).slice(-4) : null);
const masked = (n) => (n ? `${'•'.repeat(Math.max(String(n).length - 4, 4))}${last4(n)}` : null);
const monthOk = (m) => { need(MONTH_RE.test(String(m)), 'Month must look like YYYY-MM.'); return String(m); };
const bankReady = (r) => Number(r.monthly_salary) > 0 && r.bank_name && r.account_number && r.ifsc_code;

let ready;
const ensure = () => (ready ||= ensurePayrollTables().catch((e) => { ready = null; throw e; }));

// Every doctor + lab staff member (identified by the users.role column), with payroll columns.
async function staffRows() {
  const users = await query(
    `SELECT u.user_id, u.name, u.email, u.phone, u.role, d.doctor_id, s.specialization_name
       FROM users u
       LEFT JOIN doctors d ON d.user_id = u.user_id
       LEFT JOIN specializations s ON s.specialization_id = d.specialization_id`
  );
  return users
    .map((u) => ({ ...u, canon: canonicalRole(u.role) }))
    .filter((u) => u.canon === 'DOCTOR' || u.canon === 'LAB')
    .map((u) => ({
      user_id: u.user_id, name: u.name, email: u.email, phone: u.phone, doctor_id: u.doctor_id || null,
      staff_type: u.canon === 'DOCTOR' ? 'Doctor' : 'Laboratory Staff',
      designation: u.canon === 'DOCTOR' ? (u.specialization_name ? `${u.specialization_name} Specialist` : 'Doctor') : 'Laboratory Staff',
    }));
}

async function staffMember(userId) {
  const row = (await staffRows()).find((s) => Number(s.user_id) === Number(userId));
  if (!row) throw new HttpError(404, 'Doctor or laboratory staff member not found.');
  return row;
}

const payrollOf = async (userId) => (await query('SELECT * FROM staff_payroll WHERE user_id = ?', [userId]))[0] || null;

async function creditOne(staff, pay, { month, credited_on, payment_mode, reference_no, amount }) {
  const amt = amount != null && amount !== '' ? Number(amount) : Number(pay.monthly_salary);
  need(amt > 0, 'Salary amount must be greater than zero.');
  const existing = await query('SELECT 1 FROM salary_payments WHERE user_id = ? AND pay_month = ?', [staff.user_id, month]);
  if (existing.length) throw new HttpError(409, `${staff.name}'s salary for ${month} is already credited.`);
  const ref = reference_no || `SAL-${month.replace('-', '')}-${staff.user_id}`;
  await query(
    `INSERT INTO salary_payments (user_id, pay_month, amount, status, credited_on, payment_mode, reference_no, bank_name, account_last4)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [staff.user_id, month, amt, 'Credited', credited_on || today(), payment_mode || 'Bank Transfer', ref, pay.bank_name, last4(pay.account_number)]
  );
}

export const payroll = Router();
payroll.use(wrap(async (_req, _res, next) => { await ensure(); next(); }));

// ---------- Admin: everyone, for one month ----------
payroll.get('/', allow('Admin'), wrap(async (req, res) => {
  const month = monthOk(req.query.month || thisMonth());
  const [staff, pays, credits] = await Promise.all([
    staffRows(),
    query('SELECT * FROM staff_payroll'),
    query('SELECT * FROM salary_payments WHERE pay_month = ?', [month]),
  ]);
  const payBy = new Map(pays.map((p) => [Number(p.user_id), p]));
  const credBy = new Map(credits.map((c) => [Number(c.user_id), c]));
  const rows = staff.map((s) => {
    const p = payBy.get(Number(s.user_id));
    const c = credBy.get(Number(s.user_id));
    const configured = !!p && Number(p.monthly_salary) > 0;
    return {
      ...s,
      monthly_salary: p ? Number(p.monthly_salary) : 0,
      bank_name: p?.bank_name || '', account_holder: p?.account_holder || '', account_number: p?.account_number || '',
      ifsc_code: p?.ifsc_code || '', branch: p?.branch || '',
      bank_ready: !!p && !!bankReady(p),
      month,
      salary_status: c ? 'Credited' : configured ? 'Pending' : 'Not Set',
      credited_on: c?.credited_on || null, credited_amount: c ? Number(c.amount) : null,
      payment_mode: c?.payment_mode || null, reference_no: c?.reference_no || null,
    };
  }).sort((a, b) => a.staff_type.localeCompare(b.staff_type) || a.name.localeCompare(b.name));
  res.json(rows);
}));

// ---------- Doctor / Lab staff: my own salary (account number is masked) ----------
payroll.get('/me', allow('Doctor', 'Laboratory Staff'), wrap(async (req, res) => {
  const userId = req.user.user_id;
  const p = await payrollOf(userId);
  const history = await query('SELECT * FROM salary_payments WHERE user_id = ? ORDER BY pay_month DESC LIMIT 12', [userId]);
  const month = thisMonth();
  const current = history.find((h) => h.pay_month === month) || null;
  res.json({
    configured: !!p && Number(p.monthly_salary) > 0,
    monthly_salary: p ? Number(p.monthly_salary) : 0,
    bank_name: p?.bank_name || null, account_holder: p?.account_holder || null,
    account_masked: masked(p?.account_number), ifsc_code: p?.ifsc_code || null, branch: p?.branch || null,
    current_month: month,
    current_status: current ? 'Credited' : 'Pending',
    latest: history[0] ? {
      pay_month: history[0].pay_month, amount: Number(history[0].amount), credited_on: history[0].credited_on,
      payment_mode: history[0].payment_mode, reference_no: history[0].reference_no, status: history[0].status,
      bank_name: history[0].bank_name, account_last4: history[0].account_last4,
    } : null,
    history: history.map((h) => ({
      salary_payment_id: h.salary_payment_id, pay_month: h.pay_month, amount: Number(h.amount), status: h.status,
      credited_on: h.credited_on, payment_mode: h.payment_mode, reference_no: h.reference_no,
    })),
  });
}));

// ---------- Admin: credit every pending salary for a month ----------
payroll.post('/credit-all', allow('Admin'), wrap(async (req, res) => {
  const b = req.body || {};
  const month = monthOk(b.month || thisMonth());
  const staff = await staffRows();
  const credited = []; const skipped = [];
  for (const s of staff) {
    const p = await payrollOf(s.user_id);
    if (!p || !bankReady(p)) { skipped.push({ name: s.name, reason: 'Salary or bank details missing' }); continue; }
    try {
      await creditOne(s, p, { month, credited_on: b.credited_on, payment_mode: b.payment_mode });
      credited.push(s.name);
    } catch (e) {
      if (e.status === 409) skipped.push({ name: s.name, reason: 'Already credited' }); else throw e;
    }
  }
  res.json({ month, creditedCount: credited.length, credited, skipped });
}));

// ---------- Admin: update salary + bank details ----------
payroll.put('/:userId', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.userId), 'Invalid id.');
  const staff = await staffMember(req.params.userId);
  const d = pick(req.body || {}, ['monthly_salary', 'bank_name', 'account_holder', 'account_number', 'ifsc_code', 'branch']);
  if (d.monthly_salary !== undefined) {
    need(d.monthly_salary !== null && Number(d.monthly_salary) >= 0 && Number(d.monthly_salary) < 10000000, 'Enter a valid monthly salary.');
  }
  if (d.account_number) { d.account_number = String(d.account_number).replace(/\s+/g, ''); need(ACCT_RE.test(d.account_number), 'Account number must be 9 to 18 digits.'); }
  if (d.ifsc_code) { d.ifsc_code = String(d.ifsc_code).trim().toUpperCase(); need(IFSC_RE.test(d.ifsc_code), 'IFSC code looks invalid (example: HDFC0001234).'); }
  if (!Object.keys(d).length) throw new HttpError(400, 'Nothing to update.');
  const cols = Object.keys(d);
  await query(
    `INSERT INTO staff_payroll (user_id, ${cols.map((c) => `\`${c}\``).join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})
     ON DUPLICATE KEY UPDATE ${cols.map((c) => `\`${c}\` = VALUES(\`${c}\`)`).join(', ')}`,
    [staff.user_id, ...cols.map((c) => d[c])]
  );
  res.json({ success: true, user_id: staff.user_id });
}));

// ---------- Admin: credit one person's salary for a month ----------
payroll.post('/:userId/credit', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.userId), 'Invalid id.');
  const b = req.body || {};
  const month = monthOk(b.month || thisMonth());
  need(!b.payment_mode || MODES.includes(b.payment_mode), 'Unknown payment mode.');
  if (b.credited_on) need(/^\d{4}-\d{2}-\d{2}$/.test(b.credited_on), 'Invalid credit date.');
  const staff = await staffMember(req.params.userId);
  const p = await payrollOf(staff.user_id);
  need(p && Number(p.monthly_salary) > 0, 'Set the monthly salary first.');
  need(p.bank_name && p.account_number && p.ifsc_code, 'Add the bank name, account number and IFSC first.');
  await creditOne(staff, p, { month, credited_on: b.credited_on, payment_mode: b.payment_mode, reference_no: b.reference_no, amount: b.amount });
  res.status(201).json({ success: true, month });
}));

// ---------- Admin: salary history of one person ----------
payroll.get('/:userId/history', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.userId), 'Invalid id.');
  await staffMember(req.params.userId);
  res.json(await query('SELECT * FROM salary_payments WHERE user_id = ? ORDER BY pay_month DESC', [req.params.userId]));
}));

// ---------- Admin: undo a credit entry made by mistake ----------
payroll.delete('/:userId/credit/:month', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.userId), 'Invalid id.');
  monthOk(req.params.month);
  const r = await query('DELETE FROM salary_payments WHERE user_id = ? AND pay_month = ?', [req.params.userId, req.params.month]);
  if (!r.affectedRows) throw new HttpError(404, 'No credited salary found for that month.');
  res.json({ success: true });
}));
