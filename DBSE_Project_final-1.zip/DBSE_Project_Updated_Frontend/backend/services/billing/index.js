// Billing service: bills, payments, insurance.
import { Router } from 'express';
import { query, withTransaction } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, pick, HttpError, isId, patientScope } from '../../shared/http.js';
import { listBills, listPayments, listInsurance } from '../../shared/repo.js';
import { payroll } from './payroll.js';

const { app, listen } = createService('billing-service');
app.use('/api', authenticate);
const today = () => new Date().toISOString().slice(0, 10);
const need = (cond, msg) => { if (!cond) throw new HttpError(400, msg); };

// ============================ BILLS ============================
const bills = Router();
bills.get('/', allow('Admin', 'Patient'), wrap(async (req, res) => res.json(await listBills(patientScope(req)))));
bills.post('/', allow('Admin'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.patient_id), 'Patient is required.');
  need(Number(b.total_amount) >= 0 && b.total_amount !== '' && b.total_amount != null, 'A valid total amount is required.');
  const r = await query('INSERT INTO bills (patient_id, bill_date, total_amount, payment_status) VALUES (?,?,?,?)',
    [b.patient_id, b.bill_date || today(), b.total_amount, b.payment_status || 'Unpaid']);
  const [row] = await listBills({ id: r.insertId });
  res.status(201).json(row);
}));
bills.put('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const d = pick(req.body || {}, ['patient_id', 'bill_date', 'total_amount', 'payment_status']);
  if (Object.keys(d).length) {
    const r = await query('UPDATE bills SET ? WHERE bill_id = ?', [d, req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Bill not found.');
  }
  const [row] = await listBills({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Bill not found.');
  res.json(row);
}));
bills.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM bills WHERE bill_id = ?', [req.params.id]); // 409 if payments exist
  if (!r.affectedRows) throw new HttpError(404, 'Bill not found.');
  res.json({ success: true });
}));
app.use('/api/bills', bills);

// ============================ PAYMENTS ============================
const payments = Router();
payments.get('/', allow('Admin', 'Patient'), wrap(async (req, res) => res.json(await listPayments(patientScope(req)))));
payments.post('/', allow('Admin'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.bill_id), 'Bill is required.');
  need(Number(b.amount_paid) > 0, 'Amount paid must be greater than zero.');
  const id = await withTransaction(async (conn) => {
    const [[bill]] = await conn.query('SELECT bill_id, total_amount FROM bills WHERE bill_id = ? FOR UPDATE', [b.bill_id]);
    if (!bill) throw new HttpError(400, 'Bill not found.');
    const [r] = await conn.query('INSERT INTO payments (bill_id, amount_paid, payment_method, payment_date) VALUES (?,?,?,?)',
      [b.bill_id, b.amount_paid, b.payment_method || 'Cash', b.payment_date || today()]);
    const [[sum]] = await conn.query('SELECT COALESCE(SUM(amount_paid),0) AS paid FROM payments WHERE bill_id = ?', [b.bill_id]);
    if (Number(sum.paid) >= Number(bill.total_amount)) {
      await conn.query("UPDATE bills SET payment_status = 'Paid' WHERE bill_id = ?", [b.bill_id]);
    }
    return r.insertId;
  });
  const [row] = await listPayments({ id });
  res.status(201).json(row);
}));
payments.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM payments WHERE payment_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Payment not found.');
  res.json({ success: true });
}));
app.use('/api/payments', payments);

// ============================ INSURANCE ============================
const INS_FIELDS = ['patient_id', 'insurance_provider', 'policy_number', 'coverage_amount', 'claim_status'];
const ins = Router();
ins.get('/', allow('Admin', 'Patient'), wrap(async (req, res) => res.json(await listInsurance(patientScope(req)))));
ins.post('/', allow('Admin'), wrap(async (req, res) => {
  const d = pick(req.body || {}, INS_FIELDS);
  need(isId(d.patient_id), 'Patient is required.');
  need(d.policy_number, 'Policy number is required.');
  const r = await query('INSERT INTO insurance SET ?', [d]);
  const [row] = await listInsurance({ id: r.insertId });
  res.status(201).json(row);
}));
ins.put('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const d = pick(req.body || {}, INS_FIELDS);
  if (Object.keys(d).length) {
    const r = await query('UPDATE insurance SET ? WHERE insurance_id = ?', [d, req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Insurance policy not found.');
  }
  const [row] = await listInsurance({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Insurance policy not found.');
  res.json(row);
}));
ins.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM insurance WHERE insurance_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Insurance policy not found.');
  res.json({ success: true });
}));
app.use('/api/insurance', ins);

// ============================ STAFF PAYROLL (salary + bank details) ============================
app.use('/api/payroll', payroll);

listen(config.ports.billing);
