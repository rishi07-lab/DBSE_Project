// Analytics service: role-specific dashboard statistics.
import { Router } from 'express';
import { query, ensurePayrollTables, ensureOperationsTable } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, HttpError } from '../../shared/http.js';
import {
  listPrescriptions, listLabReports, listLabSamples, listBills, listMedicalRecords, listPatients, listDoctors, listPayments,
} from '../../shared/repo.js';

const { app, listen } = createService('analytics-service');
app.use('/api', authenticate);

const count = async (sql, params = []) => Number((await query(sql, params))[0].n);
const router = Router();

const todayStr = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

// Operations / surgeries (table is created on demand; zeros if it cannot be).
async function operationStats(doctorId) {
  const empty = { operationsToday: 0, operationsCompletedToday: 0, operationsInProgress: 0, operationsUpcoming: 0, operationsTotal: 0, todaysOperations: [] };
  try {
    await ensureOperationsTable();
    const today = todayStr();
    const w = doctorId ? 'AND o.doctor_id = ?' : '';
    const p = (...a) => (doctorId ? [...a, doctorId] : a);
    const n = async (cond, ...a) => Number((await query(`SELECT COUNT(*) n FROM operations o WHERE ${cond} ${w}`, p(...a)))[0].n);
    const todays = await query(
      `SELECT o.operation_id, o.patient_id, pu.name AS patient_name, o.doctor_id, du.name AS doctor_name,
              o.procedure_name, o.operation_date, o.start_time, o.theatre, o.status
         FROM operations o
         JOIN patients pt ON pt.patient_id = o.patient_id JOIN users pu ON pu.user_id = pt.user_id
         JOIN doctors d ON d.doctor_id = o.doctor_id JOIN users du ON du.user_id = d.user_id
        WHERE o.operation_date = ? ${w} ORDER BY o.start_time`, p(today));
    return {
      operationsToday: todays.length,
      operationsCompletedToday: todays.filter((x) => x.status === 'Completed').length,
      operationsInProgress: todays.filter((x) => x.status === 'In Progress').length,
      operationsUpcoming: await n('o.operation_date > ?', today),
      operationsTotal: await n('1=1'),
      todaysOperations: todays,
    };
  } catch (e) { console.error('operations stats failed:', e.message); return empty; }
}

// Payroll tables are created on demand; before that, report zeros instead of failing the dashboard.
async function payrollStats() {
  try {
    await ensurePayrollTables();
    const month = new Date().toISOString().slice(0, 7);
    const [t] = await query('SELECT COALESCE(SUM(monthly_salary),0) AS total, COUNT(*) AS n FROM staff_payroll WHERE monthly_salary > 0');
    const [c] = await query('SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS n FROM salary_payments WHERE pay_month = ?', [month]);
    return { monthlyPayroll: Number(t.total), salariesSet: Number(t.n), salariesCreditedThisMonth: Number(c.n), salaryCreditedAmount: Number(c.total) };
  } catch { return { monthlyPayroll: 0, salariesSet: 0, salariesCreditedThisMonth: 0, salaryCreditedAmount: 0 }; }
}

router.get('/admin', allow('Admin'), wrap(async (_req, res) => {
  const [revenue] = await query('SELECT COALESCE(SUM(amount_paid),0) AS total FROM payments');
  res.json({
    totalPatients: await count('SELECT COUNT(*) n FROM patients'),
    totalDoctors: await count('SELECT COUNT(*) n FROM doctors'),
    totalMedicines: await count('SELECT COUNT(*) n FROM medicines'),
    totalPrescriptions: await count('SELECT COUNT(*) n FROM prescriptions'),
    totalBills: await count('SELECT COUNT(*) n FROM bills'),
    totalRevenue: Number(revenue.total).toFixed(2),
    pendingBills: await count("SELECT COUNT(*) n FROM bills WHERE payment_status <> 'Paid'"),
    totalLabReports: await count('SELECT COUNT(*) n FROM lab_reports'),
    totalInsurance: await count('SELECT COUNT(*) n FROM insurance'),
    lowStockMedicines: await count('SELECT COUNT(*) n FROM medicines WHERE quantity < 20'),
    ...(await payrollStats()),
    ...(await operationStats(null)),
  });
}));

// Personal dashboard for the logged-in doctor (identified by the doctor_id inside the JWT).
// Uses existing relationships only: prescriptions.doctor_id and lab_reports.doctor_id. A doctor's "patients"
// are those with a prescription or lab report from that doctor; medical_records has no doctor column, so
// "medical records" are the records of those patients.
router.get('/doctor', allow('Doctor'), wrap(async (req, res) => {
  const doctorId = req.user.doctor_id;
  if (!doctorId) throw new HttpError(403, 'No doctor profile is linked to this account.');
  const [profile] = await listDoctors({ id: doctorId });
  if (!profile) throw new HttpError(403, 'No doctor profile is linked to this account.');

  const [patients, prescriptions, labReports, records, doctors] = await Promise.all([
    listPatients({ doctorId }), listPrescriptions({ doctorId }), listLabReports({ doctorId }),
    listMedicalRecords({ doctorId }), listDoctors(),
  ]);

  // all doctors grouped by specialization, the logged-in doctor's own department first
  const byDept = new Map();
  for (const d of doctors) {
    const name = d.specialization_name || 'General';
    if (!byDept.has(name)) byDept.set(name, []);
    byDept.get(name).push({ doctor_id: d.doctor_id, name: d.name, availability_status: d.availability_status });
  }
  const mine = profile.specialization_name || 'General';
  const departments = [...byDept.entries()]
    .map(([specialization_name, list]) => ({ specialization_name, doctorCount: list.length, isMine: specialization_name === mine, doctors: list }))
    .sort((a, b) => Number(b.isMine) - Number(a.isMine) || a.specialization_name.localeCompare(b.specialization_name));

  const today = todayStr();
  const seenIds = new Set([...prescriptions.map((x) => x.patient_id), ...labReports.map((x) => x.patient_id)]);
  const seenTodayIds = new Set(prescriptions.filter((x) => x.prescription_date === today).map((x) => x.patient_id));
  const ops = await operationStats(doctorId);
  ops.todaysOperations.forEach((o) => { if (o.status !== 'Scheduled') seenTodayIds.add(o.patient_id); });
  const monthStart = today.slice(0, 7);
  const seenMonth = new Set(prescriptions.filter((x) => String(x.prescription_date).startsWith(monthStart)).map((x) => x.patient_id));

  res.json({
    patientsSeen: seenIds.size,
    patientsSeenToday: seenTodayIds.size,
    patientsSeenThisMonth: seenMonth.size,
    ...ops,
    profile: {
      doctor_id: profile.doctor_id, name: profile.name, email: profile.email, phone: profile.phone,
      specialization_name: profile.specialization_name, qualification: profile.qualification,
      experience_years: profile.experience_years, availability_status: profile.availability_status,
    },
    totalPatients: patients.length,
    totalPrescriptions: prescriptions.length,
    totalLabReports: labReports.length,
    totalMedicalRecords: records.length,
    recentPrescriptions: prescriptions.slice(0, 5),
    myPatients: patients.slice(0, 6),
    departments,
  });
}));

router.get('/patient', allow('Patient'), wrap(async (req, res) => {
  const patientId = req.user.patient_id;
  if (!patientId) throw new HttpError(403, 'No patient profile is linked to this account.');
  const [prescriptions, labReports, bills, medicalRecords, payments] = await Promise.all([
    listPrescriptions({ patientId }), listLabReports({ patientId }), listBills({ patientId }), listMedicalRecords({ patientId }),
    listPayments({ patientId }),
  ]);
  const totalPaid = payments.reduce((a, x) => a + Number(x.amount_paid || 0), 0);
  const totalBilled = bills.reduce((a, b) => a + Number(b.total_amount || 0), 0);
  const pendingDues = bills.filter((b) => b.payment_status !== 'Paid').reduce((a, b) => a + Number(b.total_amount || 0), 0);
  res.json({
    totalPrescriptions: prescriptions.length,
    totalLabReports: labReports.length,
    totalBills: bills.length,
    totalMedicalRecords: medicalRecords.length,
    totalBilled: totalBilled.toFixed(2),
    pendingDues: pendingDues.toFixed(2),
    totalPayments: payments.length,
    totalPaid: totalPaid.toFixed(2),
    prescriptions, labReports, bills, medicalRecords, payments,
  });
}));

router.get('/lab', allow('Laboratory Staff'), wrap(async (_req, res) => {
  res.json({
    totalTests: await count('SELECT COUNT(*) n FROM lab_tests'),
    pendingSamples: await count("SELECT COUNT(*) n FROM lab_samples WHERE collection_status = 'Pending'"),
    processingSamples: await count("SELECT COUNT(*) n FROM lab_samples WHERE collection_status IN ('Processing','Collected')"),
    completedReports: await count('SELECT COUNT(*) n FROM lab_reports'),
    recentSamples: await listLabSamples({ limit: 6 }),
    recentReports: await listLabReports({ limit: 6 }),
  });
}));

app.use('/api/dashboard', router);
listen(config.ports.analytics);
