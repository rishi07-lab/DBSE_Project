// Pharmacy service: medicines & stock.
import { Router } from 'express';
import { query } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, pick, HttpError, isId } from '../../shared/http.js';

const { app, listen } = createService('pharmacy-service');
app.use('/api', authenticate);

const COLS = ['medicine_id', 'medicine_name', 'category', 'manufacturer', 'price', 'quantity', 'expiry_date'];
const FIELDS = COLS.slice(1);
const router = Router();

router.get('/', allow('Admin', 'Doctor'), wrap(async (_req, res) => {
  res.json(await query(`SELECT ${COLS.join(',')} FROM medicines ORDER BY medicine_id DESC`));
}));
router.get('/:id', allow('Admin', 'Doctor'), wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, 'Invalid id.');
  const [row] = await query(`SELECT ${COLS.join(',')} FROM medicines WHERE medicine_id = ?`, [req.params.id]);
  if (!row) throw new HttpError(404, 'Medicine not found.');
  res.json(row);
}));
router.post('/', allow('Admin'), wrap(async (req, res) => {
  const d = pick(req.body || {}, FIELDS);
  if (!d.medicine_name) throw new HttpError(400, 'Medicine name is required.');
  const r = await query('INSERT INTO medicines SET ?', [d]);
  const [row] = await query(`SELECT ${COLS.join(',')} FROM medicines WHERE medicine_id = ?`, [r.insertId]);
  res.status(201).json(row);
}));
router.put('/:id', allow('Admin'), wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, 'Invalid id.');
  const d = pick(req.body || {}, FIELDS);
  if (Object.keys(d).length) await query('UPDATE medicines SET ? WHERE medicine_id = ?', [d, req.params.id]);
  const [row] = await query(`SELECT ${COLS.join(',')} FROM medicines WHERE medicine_id = ?`, [req.params.id]);
  if (!row) throw new HttpError(404, 'Medicine not found.');
  res.json(row);
}));
router.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  if (!isId(req.params.id)) throw new HttpError(400, 'Invalid id.');
  const r = await query('DELETE FROM medicines WHERE medicine_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Medicine not found.');
  res.json({ success: true });
}));
app.use('/api/medicines', router);

listen(config.ports.pharmacy);
