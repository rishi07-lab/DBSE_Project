// Clinical service: patients, doctors, specializations, medical records, prescriptions.
import bcrypt from 'bcryptjs';
import { Router } from 'express';
import { query, withTransaction, hasColumn, dbRole } from '../../shared/db.js';
import { config } from '../../shared/config.js';
import { authenticate, allow } from '../../shared/auth.js';
import { createService, wrap, pick, HttpError, isId, patientScope, doctorScope, validPassword, PASSWORD_MSG } from '../../shared/http.js';
import {
  listPatients, listDoctors, listMedicalRecords, listPrescriptions,
} from '../../shared/repo.js';

const { app, listen } = createService('clinical-service');
app.use('/api', authenticate);

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const digits = (v) => (v == null ? null : String(v).replace(/[^\d+]/g, '') || null);
const need = (cond, msg) => { if (!cond) throw new HttpError(400, msg); };
// password chosen by the admin / doctor who creates the account (falls back to the default only if none is sent)
const chosenPassword = (b, fallback) => {
  if (b.password === undefined || b.password === null || b.password === '') return fallback;
  need(validPassword(String(b.password)), PASSWORD_MSG);
  return String(b.password);
};
const emailTaken = async (email, exceptUserId) => {
  const [r] = await query('SELECT user_id FROM users WHERE LOWER(email) = ? LIMIT 1', [String(email).trim().toLowerCase()]);
  if (r && Number(r.user_id) !== Number(exceptUserId)) throw new HttpError(409, 'An account with this email already exists.');
};

// ============================ PATIENTS ============================
const patients = Router();
patients.get('/', allow('Admin', 'Doctor', 'Laboratory Staff', 'Patient'), wrap(async (req, res) => {
  res.json(await listPatients(patientScope(req)));
}));
patients.get('/:id', allow('Admin', 'Doctor', 'Laboratory Staff', 'Patient'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [row] = await listPatients({ id: req.params.id, ...patientScope(req) });
  if (!row) throw new HttpError(404, 'Patient not found.');
  res.json(row);
}));
patients.post('/', allow('Admin', 'Doctor'), wrap(async (req, res) => {
  const b = req.body || {};
  need(b.name?.trim(), 'Patient name is required.');
  need(EMAIL_RE.test(b.email || ''), 'A valid email is required.');
  const password = chosenPassword(b, config.defaults.patientPassword);
  await emailTaken(b.email);
  const id = await withTransaction(async (conn) => {
    const hashed = await bcrypt.hash(password, 10);
    const [u] = await conn.query(
      'INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)',
      [b.name.trim(), b.email.trim().toLowerCase(), hashed, await dbRole('PATIENT'), digits(b.phone)]
    );
    const [p] = await conn.query(
      `INSERT INTO patients (user_id, date_of_birth, gender, blood_group, address, emergency_contact, city, medical_history)
       VALUES (?,?,?,?,?,?,?,?)`,
      [u.insertId, b.date_of_birth || null, b.gender || null, b.blood_group || null, b.address || null,
        b.emergency_contact || null, b.city || null, b.medical_history || null]
    );
    return p.insertId;
  });
  const [row] = await listPatients({ id });
  res.status(201).json(row);
}));
patients.put('/:id', allow('Admin', 'Doctor'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [existing] = await listPatients({ id: req.params.id });
  if (!existing) throw new HttpError(404, 'Patient not found.');
  const b = req.body || {};
  if (b.email !== undefined) { need(EMAIL_RE.test(b.email), 'A valid email is required.'); await emailTaken(b.email, existing.user_id); }
  const newPassword = b.password ? chosenPassword(b, null) : null;   // optional: reset the patient's password
  await withTransaction(async (conn) => {
    const u = pick({ ...b, email: b.email?.trim().toLowerCase(), phone: b.phone != null ? digits(b.phone) : undefined }, ['name', 'email', 'phone']);
    if (newPassword) u.password = await bcrypt.hash(newPassword, 10);
    if (Object.keys(u).length) await conn.query('UPDATE users SET ? WHERE user_id = ?', [u, existing.user_id]);
    const p = pick(b, ['date_of_birth', 'gender', 'blood_group', 'address', 'emergency_contact', 'city', 'medical_history']);
    if (Object.keys(p).length) await conn.query('UPDATE patients SET ? WHERE patient_id = ?', [p, existing.patient_id]);
  });
  const [row] = await listPatients({ id: req.params.id });
  res.json(row);
}));
patients.delete('/:id', allow('Admin', 'Doctor'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [existing] = await listPatients({ id: req.params.id });
  if (!existing) throw new HttpError(404, 'Patient not found.');
  // fails with a 409 (FK) if the patient still has bills, prescriptions, reports, ...
  await withTransaction(async (conn) => {
    await conn.query('DELETE FROM patients WHERE patient_id = ?', [existing.patient_id]);
    await conn.query('DELETE FROM users WHERE user_id = ?', [existing.user_id]);
  });
  res.json({ success: true });
}));
app.use('/api/patients', patients);

// ============================ SPECIALIZATIONS ============================
const specs = Router();
specs.get('/', allow('Admin', 'Doctor', 'Laboratory Staff'), wrap(async (_req, res) => {
  res.json(await query('SELECT specialization_id, specialization_name FROM specializations ORDER BY specialization_name'));
}));
specs.post('/', allow('Admin'), wrap(async (req, res) => {
  const name = String(req.body?.specialization_name || '').trim();
  need(name, 'Specialization name is required.');
  const r = await query('INSERT INTO specializations (specialization_name) VALUES (?)', [name]);
  res.status(201).json({ specialization_id: r.insertId, specialization_name: name });
}));
specs.put('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const name = String(req.body?.specialization_name || '').trim();
  need(name, 'Specialization name is required.');
  const r = await query('UPDATE specializations SET specialization_name = ? WHERE specialization_id = ?', [name, req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Specialization not found.');
  res.json({ specialization_id: Number(req.params.id), specialization_name: name });
}));
specs.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM specializations WHERE specialization_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Specialization not found.');
  res.json({ success: true });
}));
app.use('/api/specializations', specs);

// ============================ DOCTORS ============================
const doctors = Router();
const hasSpecText = await hasColumn('doctors', 'specialization'); // legacy text column, kept in sync if present
doctors.get('/', allow('Admin', 'Doctor', 'Laboratory Staff'), wrap(async (_req, res) => res.json(await listDoctors())));
doctors.get('/:id', allow('Admin', 'Doctor', 'Laboratory Staff'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [row] = await listDoctors({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Doctor not found.');
  res.json(row);
}));
async function specName(id) {
  const [s] = await query('SELECT specialization_name FROM specializations WHERE specialization_id = ?', [id]);
  if (!s) throw new HttpError(400, 'Selected specialization does not exist.');
  return s.specialization_name;
}
doctors.post('/', allow('Admin'), wrap(async (req, res) => {
  const b = req.body || {};
  need(b.name?.trim(), 'Doctor name is required.');
  need(EMAIL_RE.test(b.email || ''), 'A valid email is required.');
  need(isId(b.specialization_id), 'Specialization is required.');
  const sName = await specName(b.specialization_id);
  const password = chosenPassword(b, config.defaults.doctorPassword);
  await emailTaken(b.email);
  const id = await withTransaction(async (conn) => {
    const hashed = await bcrypt.hash(password, 10);
    const [u] = await conn.query(
      'INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)',
      [b.name.trim(), b.email.trim().toLowerCase(), hashed, await dbRole('DOCTOR'), digits(b.phone)]
    );
    const cols = ['user_id', 'specialization_id', 'qualification', 'experience_years', 'availability_status'];
    const vals = [u.insertId, b.specialization_id, b.qualification || null, Number(b.experience_years) || 0, b.availability_status || 'Available'];
    if (hasSpecText) { cols.push('specialization'); vals.push(sName); }
    const [d] = await conn.query(`INSERT INTO doctors (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, vals);
    return d.insertId;
  });
  const [row] = await listDoctors({ id });
  res.status(201).json(row);
}));
doctors.put('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [existing] = await listDoctors({ id: req.params.id });
  if (!existing) throw new HttpError(404, 'Doctor not found.');
  const b = req.body || {};
  if (b.email !== undefined) { need(EMAIL_RE.test(b.email), 'A valid email is required.'); await emailTaken(b.email, existing.user_id); }
  const newPassword = b.password ? chosenPassword(b, null) : null;   // optional: reset the doctor's password
  await withTransaction(async (conn) => {
    const u = pick({ ...b, email: b.email?.trim().toLowerCase(), phone: b.phone != null ? digits(b.phone) : undefined }, ['name', 'email', 'phone']);
    if (newPassword) u.password = await bcrypt.hash(newPassword, 10);
    if (Object.keys(u).length) await conn.query('UPDATE users SET ? WHERE user_id = ?', [u, existing.user_id]);
    const d = pick(b, ['specialization_id', 'qualification', 'experience_years', 'availability_status']);
    if (d.specialization_id && hasSpecText) d.specialization = await specName(d.specialization_id);
    if (Object.keys(d).length) await conn.query('UPDATE doctors SET ? WHERE doctor_id = ?', [d, existing.doctor_id]);
  });
  const [row] = await listDoctors({ id: req.params.id });
  res.json(row);
}));
doctors.delete('/:id', allow('Admin'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const [existing] = await listDoctors({ id: req.params.id });
  if (!existing) throw new HttpError(404, 'Doctor not found.');
  await withTransaction(async (conn) => {
    await conn.query('DELETE FROM doctors WHERE doctor_id = ?', [existing.doctor_id]);
    await conn.query('DELETE FROM users WHERE user_id = ?', [existing.user_id]);
  });
  res.json({ success: true });
}));
app.use('/api/doctors', doctors);

// ============================ MEDICAL RECORDS ============================
const records = Router();
records.get('/', allow('Doctor', 'Patient'), wrap(async (req, res) => res.json(await listMedicalRecords(patientScope(req)))));
records.post('/', allow('Doctor'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.patient_id), 'Patient is required.');
  const r = await query(
    'INSERT INTO medical_records (patient_id, diagnosis, symptoms, treatment, doctor_notes, record_date) VALUES (?,?,?,?,?,?)',
    [b.patient_id, b.diagnosis || null, b.symptoms || null, b.treatment || null, b.doctor_notes || null, b.record_date || new Date().toISOString().slice(0, 10)]
  );
  const [row] = await listMedicalRecords({ id: r.insertId });
  res.status(201).json(row);
}));
records.put('/:id', allow('Doctor'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const d = pick(req.body || {}, ['patient_id', 'diagnosis', 'symptoms', 'treatment', 'doctor_notes', 'record_date']);
  if (Object.keys(d).length) {
    const r = await query('UPDATE medical_records SET ? WHERE record_id = ?', [d, req.params.id]);
    if (!r.affectedRows) throw new HttpError(404, 'Record not found.');
  }
  const [row] = await listMedicalRecords({ id: req.params.id });
  if (!row) throw new HttpError(404, 'Record not found.');
  res.json(row);
}));
records.delete('/:id', allow('Doctor'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM medical_records WHERE record_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Record not found.');
  res.json({ success: true });
}));
app.use('/api/medical-records', records);

// ============================ PRESCRIPTIONS ============================
const rx = Router();
rx.get('/', allow('Doctor', 'Patient'), wrap(async (req, res) => res.json(await listPrescriptions({ ...patientScope(req), ...doctorScope(req) }))));
rx.post('/', allow('Doctor'), wrap(async (req, res) => {
  const b = req.body || {};
  need(isId(b.patient_id) && isId(b.medicine_id), 'Patient and medicine are required.');
  // the prescribing doctor is the logged-in doctor unless an explicit doctor was chosen
  const doctorId = b.doctor_id || req.user.doctor_id;
  need(isId(doctorId), 'Doctor is required.');
  const r = await query(
    'INSERT INTO prescriptions (patient_id, doctor_id, medicine_id, dosage, duration, prescription_date) VALUES (?,?,?,?,?,?)',
    [b.patient_id, doctorId, b.medicine_id, b.dosage || null, b.duration || null, b.prescription_date || new Date().toISOString().slice(0, 10)]
  );
  const [row] = await listPrescriptions({ id: r.insertId });
  res.status(201).json(row);
}));
rx.delete('/:id', allow('Doctor'), wrap(async (req, res) => {
  need(isId(req.params.id), 'Invalid id.');
  const r = await query('DELETE FROM prescriptions WHERE prescription_id = ?', [req.params.id]);
  if (!r.affectedRows) throw new HttpError(404, 'Prescription not found.');
  res.json({ success: true });
}));
app.use('/api/prescriptions', rx);

listen(config.ports.clinical);
