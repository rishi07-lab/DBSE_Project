// Starts all microservices + the gateway in one terminal (local development).
import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const here = path.dirname(fileURLToPath(import.meta.url));
const services = ['auth', 'clinical', 'pharmacy', 'lab', 'billing', 'analytics', 'gateway'];
const children = services.map((s) => {
  const child = spawn(process.execPath, [path.join(here, 'services', s, 'index.js')], { stdio: 'inherit' });
  child.on('exit', (code) => console.log(`[start-all] ${s} exited (${code})`));
  return child;
});
const stop = () => children.forEach((c) => c.kill());
process.on('SIGINT', () => { stop(); process.exit(0); });
process.on('SIGTERM', () => { stop(); process.exit(0); });
