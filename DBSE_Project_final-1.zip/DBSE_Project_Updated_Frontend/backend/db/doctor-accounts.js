// Gives every doctor that ALREADY exists in the database their own login (username + password).
//
//   npm run db:doctor-accounts             -> dry run: shows what would change, writes nothing
//   npm run db:doctor-accounts -- --apply  -> applies it
//
// Safe by design:
//  * never inserts doctors or users (no duplicates) and never changes the table structure
//  * a doctor's email, name, specialization and doctor_id are never touched
//  * a password is replaced only while it is still the shared demo password (Doctor@123); passwords
//    a doctor already changed are left alone
//  * the documented demo login (doctor@hospital.com / Doctor@123) is left exactly as it is
//  * re-runnable: running it again just prints the credentials again
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'node:url';
import { pool, query, hasColumn } from '../shared/db.js';

const APPLY = process.argv.includes('--apply');
const SHARED_DEFAULT = 'Doctor@123';
const DEMO_EMAIL = 'doctor@hospital.com';

const words = (name) => String(name).replace(/^dr\.?\s+/i, '').trim().split(/\s+/).filter(Boolean);
const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
const usernameFor = (name) => `dr.${words(name).map(slug).filter(Boolean).join('.')}`.slice(0, 30).replace(/[.]+$/, '');
// individual starting password: Surname@Doc<doctor_id>  (e.g. Deshmukh@Doc2) - change it after first login
const passwordFor = (name, id) => {
  const w = words(name);
  const sur = (w[w.length - 1] || 'Doctor').replace(/[^A-Za-z]/g, '');
  return `${sur.charAt(0).toUpperCase()}${sur.slice(1).toLowerCase()}@Doc${id}`;
};

async function main() {
  const hasUsername = await hasColumn('users', 'username');
  const rows = await query(
    `SELECT d.doctor_id, d.user_id, u.name, u.email, u.password, ${hasUsername ? 'u.username' : 'NULL AS username'},
            s.specialization_name
       FROM doctors d
       JOIN users u ON u.user_id = d.user_id
       LEFT JOIN specializations s ON s.specialization_id = d.specialization_id
      ORDER BY d.doctor_id`
  );
  if (!rows.length) { console.log('No doctors found in the database.'); return; }

  const taken = new Set((hasUsername ? await query('SELECT username FROM users WHERE username IS NOT NULL') : []).map((r) => String(r.username).toLowerCase()));
  const plan = [];
  for (const r of rows) {
    // username (only if the column already exists - this script never alters the structure)
    let username = r.username || null;
    let usernameNote = username ? 'existing' : '';
    if (hasUsername && !username) {
      let u = usernameFor(r.name);
      if (taken.has(u)) u = `${u.slice(0, 26)}.${r.doctor_id}`;
      taken.add(u);
      username = u;
      usernameNote = 'new';
    }

    // password
    const wanted = passwordFor(r.name, r.doctor_id);
    const isDemo = String(r.email).toLowerCase() === DEMO_EMAIL;
    let password = '(unchanged)';
    let newHash = null;
    if (isDemo) {
      password = `${SHARED_DEFAULT} (demo login, unchanged)`;
    } else if (await bcrypt.compare(wanted, r.password).catch(() => false)) {
      password = wanted;
    } else if (await bcrypt.compare(SHARED_DEFAULT, r.password).catch(() => false)) {
      password = wanted;
      newHash = await bcrypt.hash(wanted, 10);
    }
    plan.push({ ...r, username, usernameNote, password, newHash });
  }

  console.log(APPLY ? '\nApplying doctor accounts...\n' : '\nDRY RUN - nothing is written. Add "-- --apply" to apply.\n');
  console.table(plan.map((p) => ({
    doctor_id: p.doctor_id,
    name: p.name,
    specialization: p.specialization_name || '-',
    login_email: p.email,
    username: p.username ? `${p.username}${p.usernameNote === 'new' ? ' (new)' : ''}` : '(column missing)',
    password: p.password + (p.newHash ? ' (new)' : ''),
  })));

  if (!hasUsername) console.log('Note: users.username does not exist yet, so usernames were skipped. Run `npm run db:migrate` (or start the auth service once), then re-run this.\n');

  if (APPLY) {
    let n = 0;
    for (const p of plan) {
      const sets = []; const vals = [];
      if (hasUsername && p.usernameNote === 'new') { sets.push('username = ?'); vals.push(p.username); }
      if (p.newHash) { sets.push('password = ?'); vals.push(p.newHash); }
      if (!sets.length) continue;
      await query(`UPDATE users SET ${sets.join(', ')} WHERE user_id = ?`, [...vals, p.user_id]);
      n += 1;
    }
    console.log(`Updated ${n} of ${plan.length} doctor accounts.`);
  } else {
    const pending = plan.filter((p) => p.newHash || p.usernameNote === 'new').length;
    console.log(`${pending} of ${plan.length} doctor accounts would be updated.`);
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main().then(() => pool.end()).catch(async (e) => { console.error('FAILED:', e.message); await pool.end(); process.exit(1); });
}
