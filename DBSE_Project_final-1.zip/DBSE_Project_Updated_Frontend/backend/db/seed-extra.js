// Specialization-aware demo data. Idempotent: run it as often as you like  ->  npm run db:seed-extra
//  * every doctor gets 10 NEW patients of their OWN specialization (cardiology patients have cardiac
//    diagnoses, ECG / lipid reports, cardiac medicines ...), each with records, prescriptions, lab reports,
//    bills and payments
//  * every doctor gets patients seen TODAY, plus operations: 3 today, 3 completed earlier, 3 upcoming
//  * existing patients that still have no data (e.g. "Ramesh Kumar Verma") are filled in too and are
//    assigned to a doctor whose specialization matches their medical history
//  * a doctor only sees patients they treated (prescription / lab report), so each doctor sees patients of their own field
import bcrypt from 'bcryptjs';
import { fileURLToPath } from 'url';
import { pool, query, dbRole, ensureOperationsTable } from '../shared/db.js';

const NEW_PER_DOCTOR = 10;
const stats = {};
const bump = (k, n = 1) => { stats[k] = (stats[k] || 0) + n; };
const one = async (sql, p = []) => (await query(sql, p))[0] || null;
const ymd = (o = 0) => { const d = new Date(); d.setDate(d.getDate() + o); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const at = (arr, i) => arr[((i % arr.length) + arr.length) % arr.length];

// ---------- lab test catalogue (matched to existing tests by keyword, created only when missing) ----------
const T = {
  ecg: { kw: 'ECG', name: 'ECG (12 Lead)', cost: 600, sample: 'Diagnostic Procedure (No Sample)', res: ['Sinus rhythm, rate 78/min, no acute ST-T changes', 'Sinus tachycardia 104/min, nonspecific ST-T changes', 'LV hypertrophy pattern with strain, axis normal'] },
  lipid: { kw: 'Lipid', name: 'Lipid Profile', cost: 900, sample: 'Blood Serum (Fasting)', res: ['Total Cholesterol 228 mg/dL, LDL 146, HDL 44, TG 190 (borderline high)', 'Total Cholesterol 196 mg/dL, LDL 118, HDL 48, TG 150', 'Total Cholesterol 254 mg/dL, LDL 172, HDL 38, TG 240 (high)'] },
  blood: { kw: 'Blood Test', name: 'Blood Test', cost: 450, sample: 'Whole Blood (EDTA)', res: ['Hb 13.8 g/dL, WBC 7,200/cumm, Platelets 2.4 lakh/cumm, ESR 12', 'Hb 10.9 g/dL (mild anemia), WBC 8,100/cumm, Platelets 2.1 lakh/cumm', 'Hb 14.6 g/dL, WBC 11,800/cumm (raised), Platelets 3.0 lakh/cumm'] },
  kft: { kw: 'Kidney', name: 'Kidney Function Test', cost: 800, sample: 'Blood Serum', res: ['Creatinine 0.9 mg/dL, Urea 26 mg/dL, eGFR 96', 'Creatinine 1.4 mg/dL, Urea 44 mg/dL, eGFR 61 (mildly reduced)'] },
  lft: { kw: 'Liver', name: 'Liver Function Test', cost: 850, sample: 'Blood Serum', res: ['SGOT 32 U/L, SGPT 36 U/L, Bilirubin 0.8 mg/dL', 'SGOT 78 U/L, SGPT 92 U/L, Bilirubin 1.4 mg/dL (raised)'] },
  thy: { kw: 'Thyroid', name: 'Thyroid Test', cost: 700, sample: 'Blood Serum', res: ['TSH 2.8 mIU/L, T3 112 ng/dL, T4 8.1 ug/dL (normal)', 'TSH 7.9 mIU/L, T4 5.2 ug/dL (hypothyroid pattern)'] },
  hba1c: { kw: 'HbA1c', name: 'HbA1c Test', cost: 650, sample: 'Whole Blood (EDTA)', res: ['HbA1c 6.4% (pre-diabetic range)', 'HbA1c 8.1% (poor control)', 'HbA1c 7.0% (acceptable control)'] },
  urine: { kw: 'Urine', name: 'Urine Test', cost: 300, sample: 'Clean Catch Midstream Urine', res: ['Routine and microscopy normal', 'Pus cells 12-15/hpf, mild proteinuria (UTI suspected)'] },
  xray: { kw: 'X-Ray', name: 'X-Ray', cost: 500, sample: 'Radiological Imaging', res: ['No acute bony injury, joint spaces preserved', 'Reduced joint space with osteophytes (degenerative change)', 'Hairline fracture noted, alignment satisfactory'] },
  mri: { kw: 'MRI', name: 'MRI Scan', cost: 6500, sample: 'Radiological Imaging', res: ['No acute intracranial abnormality', 'Disc bulge at L4-L5 compressing the thecal sac', 'Small chronic ischemic changes, no mass lesion'] },
  ct: { kw: 'CT Scan', name: 'CT Scan', cost: 4800, sample: 'Radiological Imaging', res: ['No acute abnormality detected', 'Well-defined lesion noted; correlation and biopsy advised', 'Mild sinus mucosal thickening bilaterally'] },
  eeg: { kw: 'EEG', name: 'EEG', cost: 1800, sample: 'Diagnostic Procedure (No Sample)', res: ['Normal background activity, no epileptiform discharges', 'Intermittent generalized spike-wave activity'] },
  usg: { kw: 'Ultrasound', name: 'Ultrasound', cost: 1200, sample: 'Radiological Imaging', res: ['Gallbladder with multiple calculi, wall thickness normal', 'Normal study; no focal lesion', 'Single live intrauterine fetus, growth appropriate for dates'] },
  eye: { kw: 'Eye Test', name: 'Eye Test', cost: 400, sample: 'Diagnostic Procedure (No Sample)', res: ['Visual acuity 6/12 right, 6/9 left; early cataract changes', 'IOP 15 mmHg both eyes, fundus normal', 'Myopia -2.5 D right, -2.0 D left'] },
  culture: { kw: 'Culture', name: 'Culture & Sensitivity', cost: 900, sample: 'Whole Blood (EDTA)', res: ['No growth after 48 hours', 'Growth of E. coli, sensitive to ceftriaxone and nitrofurantoin'] },
};

// ---------- one profile per specialization ----------
const PROFILES = {
  cardio: {
    match: /cardio/, hist: /hypert|heart|cardi|cholest|angina|coronary|blood pressure/, base: 12000,
    conditions: [
      ['Essential hypertension', 'Morning headache, dizziness', 'Low-sodium diet, daily walking, antihypertensives', 'Chart BP twice weekly; review in 4 weeks.'],
      ['Stable angina', 'Chest tightness on exertion', 'Antiplatelet, statin, nitrates SOS', 'Stress test advised; avoid strenuous exertion.'],
      ['Coronary artery disease', 'Exertional breathlessness', 'Dual antiplatelet, statin, beta blocker', 'Angiography planned if symptoms persist.'],
      ['Atrial fibrillation', 'Palpitations, fatigue', 'Rate control and anticoagulation', 'ECG and INR follow-up in 2 weeks.'],
      ['Dyslipidemia', 'Asymptomatic, raised lipids', 'Statin therapy and diet restriction', 'Repeat lipid profile in 3 months.'],
    ],
    tests: ['ecg', 'lipid', 'blood', 'kft'],
    meds: [['Atorvastatin', 'Atorvastatin 20mg', '1 tablet once daily after dinner', '30 Days'], ['Amlodipine', 'Amlodipine 5mg', '1 tablet once daily in the morning', '30 Days'], ['Aspirin', 'Aspirin 75mg', '1 tablet once daily after lunch', '30 Days'], ['Metoprolol', 'Metoprolol 50mg', '1 tablet twice daily', '30 Days']],
    ops: ['Coronary Angiography', 'Coronary Angioplasty (PTCA)', 'Cardiac Stent Placement', 'Pacemaker Implantation'],
  },
  neuro: {
    match: /neuro/, hist: /migraine|epilep|stroke|neuro|seizure|parkinson/, base: 11000,
    conditions: [
      ['Migraine with aura', 'Throbbing headache, light sensitivity, nausea', 'Triptans SOS, preventive therapy, trigger avoidance', 'Maintain headache diary; review in 6 weeks.'],
      ['Epilepsy - focal seizures', 'Recurrent brief seizures', 'Antiepileptic therapy', 'EEG and drug-level monitoring advised.'],
      ['Ischemic stroke - recovery', 'Right-sided weakness, slurred speech', 'Antiplatelet, statin, physiotherapy', 'Rehabilitation plan started.'],
      ['Peripheral neuropathy', 'Tingling and numbness in feet', 'Neuropathic pain agents, B12 supplementation', 'Nerve conduction study suggested.'],
      ['Tension-type headache', 'Band-like headache, neck stiffness', 'Analgesics, stress management', 'Review if headaches become daily.'],
    ],
    tests: ['mri', 'eeg', 'blood', 'ct'],
    meds: [['Levetiracetam', 'Levetiracetam 500mg', '1 tablet twice daily', '30 Days'], ['Gabapentin', 'Gabapentin 300mg', '1 capsule at bedtime', '30 Days'], ['Sumatriptan', 'Sumatriptan 50mg', '1 tablet at onset of headache', '10 Days'], ['Clopidogrel', 'Clopidogrel 75mg', '1 tablet once daily', '30 Days']],
    ops: ['Lumbar Puncture', 'Cerebral Angiography', 'Nerve Conduction Study', 'Craniotomy (Tumour Excision)'],
  },
  ortho: {
    match: /ortho/, hist: /arthrit|knee|fracture|bone|spine|joint|back pain/, base: 14000,
    conditions: [
      ['Knee osteoarthritis', 'Knee pain on climbing stairs, stiffness', 'Physiotherapy, NSAIDs, weight reduction', 'Consider joint replacement if no relief.'],
      ['Lumbar disc prolapse', 'Low back pain radiating to leg', 'Rest, analgesics, physiotherapy', 'MRI reviewed; surgery only if deficit develops.'],
      ['Fracture - distal radius', 'Wrist swelling and pain after fall', 'Cast immobilization, calcium and vitamin D', 'Check X-ray after 3 weeks.'],
      ['Rotator cuff tear', 'Shoulder pain, limited abduction', 'Physiotherapy, subacromial injection', 'Arthroscopic repair if persistent.'],
      ['Osteoporosis', 'Back pain, height loss', 'Calcium, vitamin D, bisphosphonate', 'DEXA scan every 2 years.'],
    ],
    tests: ['xray', 'mri', 'blood', 'ct'],
    meds: [['Diclofenac', 'Diclofenac 50mg', '1 tablet twice daily after meals', '7 Days'], ['Calcium', 'Calcium + Vitamin D3', '1 tablet once daily', '60 Days'], ['Pregabalin', 'Pregabalin 75mg', '1 capsule at bedtime', '15 Days'], ['Paracetamol', 'Paracetamol 650mg', '1 tablet thrice daily if pain', '5 Days']],
    ops: ['Total Knee Replacement', 'Knee Arthroscopy', 'Fracture Fixation (ORIF)', 'Spinal Decompression'],
  },
  peds: {
    match: /pediat|paediat/, hist: /child|infant|pediat|toddler/, base: 3500, kids: true,
    conditions: [
      ['Acute viral fever', 'Fever, runny nose, poor appetite', 'Paracetamol syrup, fluids, rest', 'Review if fever lasts beyond 3 days.'],
      ['Childhood asthma', 'Night cough, wheeze', 'Inhaled bronchodilator and controller', 'Avoid dust and cold triggers.'],
      ['Acute gastroenteritis', 'Loose stools, vomiting', 'ORS, zinc supplementation', 'Hydration monitored; review in 48 hours.'],
      ['Iron deficiency anemia', 'Pallor, tiredness', 'Iron supplementation and diet advice', 'Repeat hemoglobin in 6 weeks.'],
      ['Tonsillitis', 'Sore throat, difficulty swallowing', 'Antibiotic course, warm fluids', 'ENT opinion if recurrent.'],
    ],
    tests: ['blood', 'urine', 'xray', 'culture'],
    meds: [['Paracetamol', 'Paracetamol Syrup 125mg/5ml', '5 ml thrice daily', '5 Days'], ['Zinc', 'Zinc Sulphate Syrup', '5 ml once daily', '14 Days'], ['Amoxicillin', 'Amoxicillin 250mg', '1 tablet twice daily', '5 Days'], ['Salbutamol', 'Salbutamol Inhaler', '2 puffs when breathless', '30 Days']],
    ops: ['Tonsillectomy', 'Hernia Repair (Pediatric)', 'Circumcision', 'Adenoidectomy'],
  },
  surgery: {
    match: /surg/, hist: /gallstone|hernia|append|piles|hemorrhoid|surg/, base: 22000,
    conditions: [
      ['Acute appendicitis', 'Right lower abdominal pain, fever', 'Appendectomy advised', 'Pre-operative work-up completed.'],
      ['Symptomatic gallstones', 'Upper abdominal pain after meals', 'Laparoscopic cholecystectomy planned', 'Fat-restricted diet until surgery.'],
      ['Inguinal hernia', 'Groin swelling on straining', 'Mesh hernioplasty advised', 'Avoid heavy lifting.'],
      ['Hemorrhoids - grade III', 'Bleeding with stools, discomfort', 'Stool softeners, surgical banding', 'High-fiber diet advised.'],
      ['Thyroid nodule', 'Neck swelling, no pain', 'FNAC and observation', 'Surgery if FNAC suspicious.'],
    ],
    tests: ['usg', 'blood', 'lft', 'ct'],
    meds: [['Pantoprazole', 'Pantoprazole 40mg', '1 tablet before breakfast', '14 Days'], ['Ceftriaxone', 'Cefixime 200mg', '1 tablet twice daily', '5 Days'], ['Tramadol', 'Tramadol 50mg', '1 tablet if severe pain', '3 Days'], ['Lactulose', 'Lactulose Syrup', '10 ml at bedtime', '10 Days']],
    ops: ['Laparoscopic Appendectomy', 'Laparoscopic Cholecystectomy', 'Hernia Repair', 'Hemorrhoidectomy'],
  },
  gyn: {
    match: /gyn|obst/, hist: /pregnan|pcos|menstru|fibroid|gyn/, base: 9000, female: true,
    conditions: [
      ['Antenatal care - 2nd trimester', 'Routine visit, mild back ache', 'Iron, folic acid, calcium supplementation', 'Anomaly scan scheduled.'],
      ['Polycystic ovarian syndrome', 'Irregular cycles, weight gain', 'Lifestyle modification, metformin', 'Review hormonal profile in 3 months.'],
      ['Uterine fibroid', 'Heavy menstrual bleeding', 'Tranexamic acid, iron, observation', 'Surgery if symptoms persist.'],
      ['Menorrhagia with anemia', 'Heavy periods, weakness', 'Iron therapy and hormonal control', 'Repeat hemoglobin in 6 weeks.'],
      ['Gestational diabetes', 'Raised glucose in pregnancy', 'Diet control, glucose monitoring', 'Weekly sugar charting.'],
    ],
    tests: ['usg', 'blood', 'thy', 'hba1c'],
    meds: [['Folic', 'Folic Acid 5mg', '1 tablet once daily', '60 Days'], ['Iron', 'Ferrous Sulphate 200mg', '1 tablet once daily after lunch', '60 Days'], ['Metformin', 'Metformin 500mg', '1 tablet twice daily after meals', '30 Days'], ['Tranexamic', 'Tranexamic Acid 500mg', '1 tablet thrice daily during periods', '5 Days']],
    ops: ['Caesarean Section', 'Hysteroscopy', 'Laparoscopic Myomectomy', 'Dilatation & Curettage'],
  },
  ent: {
    match: /\bent\b|otorhino/, hist: /sinus|ear|throat|tonsil|hearing/, base: 7500,
    conditions: [
      ['Chronic sinusitis', 'Nasal block, facial pressure', 'Saline irrigation, nasal steroid spray', 'CT sinus reviewed; FESS if no relief.'],
      ['Acute otitis media', 'Ear pain, fever', 'Antibiotics and analgesics', 'Review after 5 days.'],
      ['Chronic tonsillitis', 'Recurrent sore throat', 'Antibiotics, gargles', 'Tonsillectomy considered.'],
      ['Deviated nasal septum', 'Persistent nasal obstruction', 'Decongestants, surgical correction advised', 'Septoplasty planned.'],
      ['Sensorineural hearing loss', 'Reduced hearing, tinnitus', 'Audiometry, hearing aid trial', 'Repeat audiogram in 3 months.'],
    ],
    tests: ['ct', 'blood', 'culture', 'xray'],
    meds: [['Cetirizine', 'Cetirizine 10mg', '1 tablet at bedtime', '10 Days'], ['Fluticasone', 'Fluticasone Nasal Spray', '2 sprays each nostril daily', '30 Days'], ['Azithromycin', 'Azithromycin 500mg', '1 tablet once daily', '3 Days'], ['Montelukast', 'Montelukast 10mg', '1 tablet at bedtime', '15 Days']],
    ops: ['Septoplasty', 'Tonsillectomy', 'Functional Endoscopic Sinus Surgery', 'Tympanoplasty'],
  },
  eye: {
    match: /ophth|eye/, hist: /cataract|glaucoma|vision|retina|myopia/, base: 8000,
    conditions: [
      ['Senile cataract', 'Blurred vision, glare', 'Phacoemulsification with IOL advised', 'Pre-operative biometry done.'],
      ['Primary open-angle glaucoma', 'Gradual peripheral vision loss', 'Pressure-lowering eye drops', 'Visual field test every 6 months.'],
      ['Diabetic retinopathy', 'Floaters, blurred vision', 'Laser photocoagulation, sugar control', 'Retina review in 3 months.'],
      ['Myopia', 'Difficulty seeing distant objects', 'Corrective lenses', 'Annual eye check.'],
      ['Allergic conjunctivitis', 'Itchy red eyes, watering', 'Antihistamine eye drops', 'Avoid dust exposure.'],
    ],
    tests: ['eye', 'hba1c', 'blood'],
    meds: [['Timolol', 'Timolol 0.5% Eye Drops', '1 drop twice daily', '30 Days'], ['Moxifloxacin', 'Moxifloxacin Eye Drops', '1 drop four times daily', '7 Days'], ['Carboxymethyl', 'Lubricant Eye Drops', '1 drop thrice daily', '30 Days'], ['Olopatadine', 'Olopatadine Eye Drops', '1 drop twice daily', '14 Days']],
    ops: ['Cataract Surgery (Phaco)', 'Retinal Laser Photocoagulation', 'Glaucoma Trabeculectomy', 'Pterygium Excision'],
  },
  onco: {
    match: /onco/, hist: /cancer|tumou?r|lymphoma|carcinoma|oncolog/, base: 35000,
    conditions: [
      ['Breast carcinoma - Stage II', 'Breast lump, axillary node', 'Surgery followed by adjuvant chemotherapy', 'Cycle 2 of chemotherapy due.'],
      ['Colon adenocarcinoma', 'Altered bowel habit, weight loss', 'Resection and adjuvant chemotherapy', 'CEA monitoring every 3 months.'],
      ['Non-Hodgkin lymphoma', 'Painless neck nodes, night sweats', 'R-CHOP chemotherapy', 'PET-CT after cycle 3.'],
      ['Oral cavity carcinoma', 'Non-healing ulcer', 'Surgery with radiotherapy', 'Dental and speech rehabilitation.'],
      ['Lung nodule - under evaluation', 'Persistent cough', 'CT-guided biopsy planned', 'Smoking cessation counseling.'],
    ],
    tests: ['ct', 'blood', 'lft', 'kft'],
    meds: [['Ondansetron', 'Ondansetron 4mg', '1 tablet before chemotherapy', '5 Days'], ['Pantoprazole', 'Pantoprazole 40mg', '1 tablet before breakfast', '30 Days'], ['Dexamethasone', 'Dexamethasone 4mg', '1 tablet once daily', '3 Days'], ['Paracetamol', 'Paracetamol 650mg', '1 tablet if fever or pain', '7 Days']],
    ops: ['Lumpectomy / Mastectomy', 'Tumour Biopsy', 'Port-a-cath Insertion', 'Hemicolectomy'],
  },
  derma: {
    match: /derma/, hist: /skin|acne|eczema|psoria|rash|dermat/, base: 4500,
    conditions: [
      ['Acne vulgaris', 'Facial pimples and scarring', 'Topical retinoid, oral antibiotics', 'Review in 6 weeks.'],
      ['Atopic dermatitis', 'Itchy dry patches', 'Emollients, topical steroids', 'Avoid harsh soaps.'],
      ['Plaque psoriasis', 'Scaly red plaques on elbows', 'Topical therapy, phototherapy', 'Review response in 8 weeks.'],
      ['Fungal skin infection', 'Ring-shaped itchy lesions', 'Oral and topical antifungals', 'Keep area dry; review in 2 weeks.'],
      ['Urticaria', 'Recurrent itchy wheals', 'Antihistamines, trigger avoidance', 'Allergy work-up if persistent.'],
    ],
    tests: ['blood', 'culture', 'thy'],
    meds: [['Isotretinoin', 'Adapalene Gel 0.1%', 'Apply at night', '30 Days'], ['Fexofenadine', 'Fexofenadine 120mg', '1 tablet once daily', '14 Days'], ['Itraconazole', 'Itraconazole 100mg', '1 capsule twice daily', '14 Days'], ['Clobetasol', 'Clobetasol Cream', 'Apply thinly twice daily', '10 Days']],
    ops: ['Skin Biopsy', 'Wart Cauterization', 'Chemical Peel Procedure', 'Mole Excision'],
  },
  genmed: {
    match: /general med|physician|internal|family/, hist: /diabet|fever|thyroid|infection|anemia|kidney/, base: 6000,
    conditions: [
      ['Type 2 diabetes mellitus', 'Increased thirst, fatigue', 'Diet control and oral hypoglycemics', 'Repeat HbA1c in 3 months.'],
      ['Seasonal viral fever', 'Fever, body ache, sore throat', 'Rest, fluids, paracetamol', 'Review if fever persists beyond 3 days.'],
      ['Hypothyroidism', 'Weight gain, tiredness', 'Levothyroxine replacement', 'TSH check in 6 weeks.'],
      ['Urinary tract infection', 'Burning micturition, frequency', 'Antibiotics and hydration', 'Urine culture on follow-up.'],
      ['Iron deficiency anemia', 'Weakness, pallor', 'Iron supplements, dietary advice', 'Repeat hemoglobin in 6 weeks.'],
    ],
    tests: ['hba1c', 'blood', 'thy', 'urine'],
    meds: [['Metformin', 'Metformin 500mg', '1 tablet twice daily after meals', '30 Days'], ['Levothyroxine', 'Levothyroxine 50mcg', '1 tablet on empty stomach', '30 Days'], ['Paracetamol', 'Paracetamol 650mg', '1 tablet thrice daily if fever', '5 Days'], ['Nitrofurantoin', 'Nitrofurantoin 100mg', '1 capsule twice daily', '5 Days']],
    ops: ['Bone Marrow Aspiration', 'Pleural Tapping', 'Ascitic Fluid Tapping', 'Minor Wound Suturing'],
  },
  patho: {
    match: /patholog/, hist: /zzzz/, base: 5000,
    conditions: [
      ['Anemia - work-up', 'Fatigue and pallor', 'Peripheral smear and iron studies', 'Treatment per smear findings.'],
      ['Thyroid disorder - evaluation', 'Weight change, fatigue', 'Thyroid profile and antibodies', 'Endocrine follow-up.'],
      ['Liver enzyme elevation', 'Incidental raised enzymes', 'LFT, viral markers, ultrasound', 'Repeat LFT in 4 weeks.'],
      ['Proteinuria - evaluation', 'Foamy urine', 'Urine protein-creatinine ratio', 'Nephrology opinion if persistent.'],
      ['Pre-operative screening', 'Routine pre-op work-up', 'CBC, coagulation, renal and liver panel', 'Fit for surgery from lab standpoint.'],
    ],
    tests: ['blood', 'lft', 'kft', 'thy'],
    meds: [['Folic', 'Folic Acid 5mg', '1 tablet once daily', '30 Days'], ['Iron', 'Ferrous Sulphate 200mg', '1 tablet once daily', '60 Days'], ['Vitamin', 'Vitamin B12 1500mcg', '1 tablet once daily', '30 Days'], ['Silymarin', 'Silymarin 140mg', '1 tablet twice daily', '30 Days']],
    ops: ['Bone Marrow Biopsy', 'FNAC Procedure', 'Core Needle Biopsy', 'Fluid Cytology Collection'],
  },
};
// fallback for any specialization not listed above
PROFILES.general = { ...PROFILES.genmed, match: /./, hist: /zzzz/ };
const PROFILE_ORDER = ['cardio', 'neuro', 'ortho', 'peds', 'surgery', 'gyn', 'ent', 'eye', 'onco', 'derma', 'patho', 'genmed', 'general'];
const profileKeyFor = (spec) => PROFILE_ORDER.find((k) => PROFILES[k].match.test(String(spec || '').toLowerCase())) || 'general';

const MALE = ['Aarav', 'Vivaan', 'Aditya', 'Arjun', 'Rohan', 'Kabir', 'Ishaan', 'Rahul', 'Amit', 'Sandeep', 'Manoj', 'Vikram', 'Suresh', 'Naveen', 'Harish', 'Anil', 'Deepak', 'Gaurav', 'Nikhil', 'Pranav', 'Imran', 'Karthik', 'Sanjay', 'Rohit'];
const FEMALE = ['Ananya', 'Diya', 'Isha', 'Kavya', 'Meera', 'Neha', 'Pooja', 'Priya', 'Riya', 'Sneha', 'Divya', 'Anjali', 'Swati', 'Lakshmi', 'Fatima', 'Shreya', 'Tanvi', 'Radhika', 'Sunita', 'Geeta', 'Nandini', 'Pallavi', 'Rekha', 'Aditi'];
const LAST = ['Sharma', 'Verma', 'Iyer', 'Nair', 'Reddy', 'Patel', 'Gupta', 'Khan', 'Singh', 'Das', 'Joshi', 'Mehta', 'Kulkarni', 'Rao', 'Menon', 'Banerjee', 'Chatterjee', 'Pillai', 'Naidu', 'Shetty', 'Bhatt', 'Agarwal', 'Malhotra', 'Kapoor', 'Desai'];
const CITIES = ['Mumbai', 'Delhi', 'Hyderabad', 'Chennai', 'Bengaluru', 'Pune', 'Kolkata', 'Ahmedabad', 'Jaipur', 'Lucknow', 'Kochi', 'Nagpur', 'Coimbatore', 'Indore'];
const BLOOD = ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'O+', 'B+', 'A+'];
const THEATRES = ['OT-1', 'OT-2', 'OT-3', 'OT-4'];
const TIMES = ['08:00', '09:30', '11:00', '13:30', '15:00', '16:30'];

const medCache = {}; const testCache = {};
async function ensureMed([kw, name]) {
  if (medCache[name]) return medCache[name];
  let r = await one('SELECT medicine_id FROM medicines WHERE medicine_name LIKE ? ORDER BY medicine_id LIMIT 1', [`%${kw}%`]);
  if (!r) {
    const ins = await query('INSERT INTO medicines (medicine_name, category, manufacturer, price, quantity, expiry_date) VALUES (?,?,?,?,?,?)',
      [name, 'Tablet', 'CarePulse Pharma', 45 + (name.length % 7) * 12, 200, ymd(450)]);
    r = { medicine_id: ins.insertId }; bump('medicines');
  }
  return (medCache[name] = r.medicine_id);
}
async function ensureTest(key) {
  if (testCache[key]) return testCache[key];
  const t = T[key];
  let r = await one('SELECT test_id FROM lab_tests WHERE test_name LIKE ? ORDER BY test_id LIMIT 1', [`%${t.kw}%`]);
  if (!r) {
    const ins = await query('INSERT INTO lab_tests (test_name, test_description, test_cost, sample_type, test_status) VALUES (?,?,?,?,?)',
      [t.name, `${t.name} - diagnostic investigation`, t.cost, t.sample, 'Active']);
    r = { test_id: ins.insertId }; bump('lab_tests');
  }
  return (testCache[key] = r.test_id);
}

async function addRecord(pid, prof, i, daysAgo) {
  const [dx, sym, tx, notes] = at(prof.conditions, i);
  if (await one('SELECT 1 x FROM medical_records WHERE patient_id=? AND diagnosis=? LIMIT 1', [pid, dx])) return;
  await query('INSERT INTO medical_records (patient_id, diagnosis, symptoms, treatment, doctor_notes, record_date) VALUES (?,?,?,?,?,?)', [pid, dx, sym, tx, notes, ymd(-daysAgo)]);
  bump('medical_records');
}
async function addRx(pid, did, prof, i, date) {
  const m = at(prof.meds, i);
  if (await one('SELECT 1 x FROM prescriptions WHERE patient_id=? AND doctor_id=? AND prescription_date=? LIMIT 1', [pid, did, date])) return;
  await query('INSERT INTO prescriptions (patient_id, doctor_id, medicine_id, dosage, duration, prescription_date) VALUES (?,?,?,?,?,?)',
    [pid, did, await ensureMed(m), m[2], m[3], date]);
  bump('prescriptions');
}
async function addLab(pid, did, prof, i, date) {
  const key = at(prof.tests, i); const t = T[key];
  if (await one('SELECT 1 x FROM lab_reports WHERE patient_id=? AND doctor_id=? AND report_date=? LIMIT 1', [pid, did, date])) return;
  await query('INSERT INTO lab_reports (patient_id, test_id, doctor_id, result, report_date, remarks, file_attachment) VALUES (?,?,?,?,?,?,?)',
    [pid, await ensureTest(key), did, at(t.res, i), date, 'Reviewed by consulting doctor.', `${t.name.replace(/\W+/g, '_')}_P${pid}.pdf`]);
  bump('lab_reports');
}
async function addBills(pid, prof, i) {
  const plan = [[-24, 1.0, 'Paid', 'UPI'], [-11, 0.65, 'Paid', 'Card'], [-3, 0.4, 'Pending', null]];
  for (const [off, f, status, method] of plan) {
    const amt = Math.round((prof.base * f + (i % 5) * 450) / 10) * 10;
    const r = await query('INSERT INTO bills (patient_id, bill_date, total_amount, payment_status) VALUES (?,?,?,?)', [pid, ymd(off), amt, status]);
    bump('bills');
    if (method) {
      await query('INSERT INTO payments (bill_id, amount_paid, payment_method, payment_date) VALUES (?,?,?,?)', [r.insertId, amt, method, ymd(off)]);
      bump('payments');
    }
  }
}

async function main() {
  await ensureOperationsTable();
  const hash = await bcrypt.hash('Patient@123', 10);
  const patientRole = await dbRole('PATIENT');

  const doctors = await query(
    `SELECT d.doctor_id, u.name, s.specialization_name FROM doctors d
       JOIN users u ON u.user_id = d.user_id
       LEFT JOIN specializations s ON s.specialization_id = d.specialization_id ORDER BY d.doctor_id`);
  if (!doctors.length) throw new Error('No doctors found in the database. Run `npm run db:seed` first.');
  doctors.forEach((d) => { d.pkey = profileKeyFor(d.specialization_name); d.prof = PROFILES[d.pkey]; d.mine = []; });

  // ---------- 1. each doctor: 10 new patients of their own specialization ----------
  for (const d of doctors) {
    for (let k = 0; k < NEW_PER_DOCTOR; k++) {
      const n = d.doctor_id * 10 + k;
      const female = d.prof.female ? true : (n % 2 === 0);
      const first = at(female ? FEMALE : MALE, n * 7 + k);
      const name = `${first} ${at(LAST, n * 3 + Math.floor(n / 24))}`;
      const email = `pt${d.doctor_id}.${k + 1}@carepulse.demo`;
      const phone = `9${String(800000000 + n * 13).slice(-9)}`;
      const age = d.prof.kids ? 2 + ((n * 5) % 13) : 24 + ((n * 11) % 52);
      const dob = `${new Date().getFullYear() - age}-${String(1 + (n % 12)).padStart(2, '0')}-${String(1 + (n % 27)).padStart(2, '0')}`;
      const [dx] = at(d.prof.conditions, k);

      let u = await one('SELECT user_id FROM users WHERE email = ?', [email]);
      if (!u) {
        const r = await query('INSERT INTO users (name, email, password, role, phone) VALUES (?,?,?,?,?)', [name, email, hash, patientRole, phone]);
        u = { user_id: r.insertId }; bump('users');
      }
      let p = await one('SELECT patient_id FROM patients WHERE user_id = ?', [u.user_id]);
      if (!p) {
        const city = at(CITIES, n);
        const r = await query('INSERT INTO patients (user_id, date_of_birth, gender, blood_group, address, emergency_contact, city, medical_history) VALUES (?,?,?,?,?,?,?,?)',
          [u.user_id, dob, female ? 'Female' : 'Male', at(BLOOD, n), city, phone, city, dx]);
        p = { patient_id: r.insertId }; bump('patients');
      }
      d.mine.push(p.patient_id);
      const pid = p.patient_id;

      await addRecord(pid, d.prof, k, 6 + k);
      if (k % 2 === 0) await addRecord(pid, d.prof, k + 1, 20 + k);
      if (!(await one('SELECT 1 x FROM prescriptions WHERE patient_id=? AND doctor_id=? LIMIT 1', [pid, d.doctor_id]))) {
        await addRx(pid, d.doctor_id, d.prof, k, ymd(-(4 + k)));
        await addRx(pid, d.doctor_id, d.prof, k + 1, ymd(-(14 + k)));
      }
      if (!(await one('SELECT 1 x FROM lab_reports WHERE patient_id=? AND doctor_id=? LIMIT 1', [pid, d.doctor_id]))) {
        await addLab(pid, d.doctor_id, d.prof, k, ymd(-(3 + k)));
        await addLab(pid, d.doctor_id, d.prof, k + 1, ymd(-(12 + k)));
      }
      if (!(await one('SELECT 1 x FROM bills WHERE patient_id = ? LIMIT 1', [pid]))) await addBills(pid, d.prof, k);
    }
  }

  // ---------- 2. patients seen TODAY + operations (today / completed / upcoming) ----------
  const today = ymd(0);
  for (const [di, d] of doctors.entries()) {
    for (let k = 0; k < 6; k++) {
      const pid = d.mine[k];
      await addRx(pid, d.doctor_id, d.prof, k + 2, today);
      if (k < 2) await addLab(pid, d.doctor_id, d.prof, k + 2, today);
    }
    const count = async (cond, p) => Number((await one(`SELECT COUNT(*) n FROM operations WHERE doctor_id = ? AND ${cond}`, [d.doctor_id, ...p])).n);
    const groups = [
      [await count('operation_date = ?', [today]), [[0, 'Completed'], [1, 'In Progress'], [2, 'Scheduled']], () => 0],
      [await count('operation_date < ?', [today]), [[-2, 'Completed'], [-5, 'Completed'], [-9, 'Completed']], null],
      [await count('operation_date > ?', [today]), [[1, 'Scheduled'], [3, 'Scheduled'], [6, 'Scheduled']], null],
    ];
    let seq = 0;
    for (const [have, list] of groups) {
      for (const [off, status] of list.slice(have)) {
        const pid = at(d.mine, seq + di);
        const proc = at(d.prof.ops, seq);
        await query('INSERT INTO operations (patient_id, doctor_id, procedure_name, operation_date, start_time, theatre, status, notes) VALUES (?,?,?,?,?,?,?,?)',
          [pid, d.doctor_id, proc, ymd(off), at(TIMES, seq + di), at(THEATRES, seq + di), status, 'Pre-operative checks completed.']);
        bump('operations'); seq += 1;
      }
    }
  }

  // ---------- 3. existing patients that still have gaps -> assign to a doctor of the matching specialization ----------
  const existing = await query('SELECT patient_id, medical_history FROM patients ORDER BY patient_id');
  for (const [i, p] of existing.entries()) {
    const pid = p.patient_id;
    const has = async (t) => !!(await one(`SELECT 1 x FROM ${t} WHERE patient_id = ? LIMIT 1`, [pid]));
    const [needLab, needRx, needRec, needBill] = [!(await has('lab_reports')), !(await has('prescriptions')), !(await has('medical_records')), !(await has('bills'))];
    if (!(needLab || needRx || needRec || needBill)) continue;
    const hist = String(p.medical_history || '');
    const key = PROFILE_ORDER.find((k) => PROFILES[k].hist.test(hist.toLowerCase()));
    const doc = (key && doctors.find((d) => d.pkey === key)) || at(doctors, i);
    if (needRec) await addRecord(pid, doc.prof, i, 5);
    if (needRx) { await addRx(pid, doc.doctor_id, doc.prof, i, ymd(-2)); await addRx(pid, doc.doctor_id, doc.prof, i + 1, ymd(-9)); }
    if (needLab) { for (let k = 0; k < 3; k++) await addLab(pid, doc.doctor_id, doc.prof, i + k, ymd(-(3 + k * 6))); }
    if (needBill) await addBills(pid, doc.prof, i);
  }

  // Paid bills with no payment row -> add the payment
  for (const b of await query(`SELECT b.bill_id, b.total_amount, b.bill_date FROM bills b LEFT JOIN payments pay ON pay.bill_id = b.bill_id WHERE b.payment_status = 'Paid' AND pay.payment_id IS NULL`)) {
    await query('INSERT INTO payments (bill_id, amount_paid, payment_method, payment_date) VALUES (?,?,?,?)', [b.bill_id, b.total_amount, 'UPI', b.bill_date]);
    bump('payments');
  }

  console.log('Doctors found:', doctors.map((d) => `#${d.doctor_id} ${d.name} [${d.specialization_name || 'General'}]`).join(', '));
  console.log('Rows added this run:');
  if (!Object.keys(stats).length) console.log('  (nothing - already present)');
  for (const [k, v] of Object.entries(stats)) console.log(`  ${k.padEnd(18)} +${v}`);
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  main().then(() => pool.end()).catch(async (e) => { console.error('SEED-EXTRA FAILED:', e.message); await pool.end(); process.exit(1); });
}
export { main as seedExtra };
