// Non-destructive, idempotent migration for the EXISTING hospital_management database.
//
//  * never DROPs a table/column/database and never deletes rows
//  * only ADDs missing columns/tables, widens a few columns, and relaxes NOT NULL on
//    unknown legacy columns so inserts keep working
//  * hashes any plain-text passwords with bcrypt (so JWT login works)
//
// Usage:  npm run db:migrate:dry   (prints what it WOULD do)
//         npm run db:migrate       (does it)
import bcrypt from 'bcryptjs';
import { pool, query, ensureUsernameColumn, ensurePayrollTables } from '../shared/db.js';
import { config } from '../shared/config.js';
import { fileURLToPath } from 'url';

const DB = config.db.database;

export async function migrate({ dryRun = false, log = console.log } = {}) {
  const say = (m) => log(`${dryRun ? '[dry-run] ' : ''}${m}`);

  async function exec(sql, params = []) {
    say(sql.replace(/\s+/g, ' ').trim());
    if (!dryRun) await query(sql, params);
  }

  const tableExists = async (t) =>
    (await query('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?', [DB, t])).length > 0;

  const getColumns = async (t) => {
    const rows = await query(
      `SELECT COLUMN_NAME AS name, COLUMN_TYPE AS type, IS_NULLABLE AS nullable, COLUMN_DEFAULT AS dflt,
              COLUMN_KEY AS ckey, EXTRA AS extra, CHARACTER_MAXIMUM_LENGTH AS maxlen, GENERATION_EXPRESSION AS gen
         FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? ORDER BY ORDINAL_POSITION`,
      [DB, t]
    );
    return Object.fromEntries(rows.map((r) => [r.name, r]));
  };

  async function ensureColumn(table, col, ddl) {
    const cols = await getColumns(table);
    if (!cols[col]) await exec(`ALTER TABLE \`${table}\` ADD COLUMN \`${col}\` ${ddl}`);
  }

  // Loosen NOT NULL (without default) on legacy columns we do not know about,
  // so inserts that do not mention them do not fail. Purely additive/safe.
  async function relaxUnknownRequired(table, known) {
    const cols = await getColumns(table);
    for (const c of Object.values(cols)) {
      if (known.includes(c.name) || c.ckey === 'PRI' || c.extra.includes('auto_increment') || c.gen) continue;
      if (c.nullable === 'NO' && c.dflt === null) {
        await exec(`ALTER TABLE \`${table}\` MODIFY \`${c.name}\` ${c.type} NULL`);
      }
    }
  }

  for (const t of ['users', 'patients', 'doctors', 'specializations', 'lab_tests', 'lab_reports']) {
    if (!(await tableExists(t))) throw new Error(`Table \`${t}\` was not found in database \`${DB}\`. Is DB_NAME correct?`);
  }

  // ---------------- users ----------------
  say('== users ==');
  let uc = await getColumns('users');
  if ((uc.phone?.maxlen || 0) < 20) await exec('ALTER TABLE users MODIFY phone VARCHAR(20) NULL');
  if ((uc.password?.maxlen || 0) < 100) await exec('ALTER TABLE users MODIFY password VARCHAR(255) NOT NULL');

  say('adding users.username (for self-registration) if missing');
  if (!dryRun) await ensureUsernameColumn();

  const plain = await query("SELECT user_id, password FROM users WHERE password NOT LIKE '$2a$%' AND password NOT LIKE '$2b$%' AND password NOT LIKE '$2y$%'");
  say(`hashing ${plain.length} plain-text password(s) with bcrypt`);
  if (!dryRun) {
    for (const u of plain) {
      const hash = await bcrypt.hash(String(u.password), 10);
      await query('UPDATE users SET password = ? WHERE user_id = ?', [hash, u.user_id]);
    }
  }

  // ---------------- patients ----------------
  say('== patients ==');
  await ensureColumn('patients', 'city', 'VARCHAR(100) NULL');
  await ensureColumn('patients', 'medical_history', 'TEXT NULL');
  const pc = await getColumns('patients');
  if ((pc.emergency_contact?.maxlen || 0) < 100) await exec('ALTER TABLE patients MODIFY emergency_contact VARCHAR(100) NULL');
  // existing rows keep only a city name in `address`; mirror it into the new city column
  if (!dryRun || pc.city) {
    await exec("UPDATE patients SET city = address WHERE city IS NULL AND address IS NOT NULL AND address NOT LIKE '%,%' AND CHAR_LENGTH(address) <= 40");
  }

  // ---------------- specializations / doctors ----------------
  say('== doctors & specializations ==');
  let dc = await getColumns('doctors');
  if (!dc.specialization_id) await exec('ALTER TABLE doctors ADD COLUMN specialization_id INT NULL');
  dc = await getColumns('doctors');
  if (dc.specialization) {
    // legacy text column -> normalise into the specializations table
    await exec('ALTER TABLE doctors MODIFY specialization ' + dc.specialization.type + ' NULL');
    await exec(`INSERT IGNORE INTO specializations (specialization_name)
                SELECT DISTINCT TRIM(specialization) FROM doctors WHERE specialization IS NOT NULL AND TRIM(specialization) <> ''`);
    if (dc.specialization_id || !dryRun) {
      await exec(`UPDATE doctors d JOIN specializations s ON s.specialization_name = TRIM(d.specialization)
                  SET d.specialization_id = s.specialization_id WHERE d.specialization_id IS NULL`);
    }
  }
  const fks = await query(
    `SELECT CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE
      WHERE TABLE_SCHEMA=? AND TABLE_NAME='doctors' AND COLUMN_NAME='specialization_id' AND REFERENCED_TABLE_NAME='specializations'`,
    [DB]
  );
  if (!fks.length) {
    await exec('ALTER TABLE doctors ADD CONSTRAINT fk_doctors_specialization FOREIGN KEY (specialization_id) REFERENCES specializations(specialization_id)');
  }

  // ---------------- lab_tests ----------------
  say('== lab_tests ==');
  await ensureColumn('lab_tests', 'sample_type', 'VARCHAR(100) NULL');
  await ensureColumn('lab_tests', 'test_status', "VARCHAR(20) NOT NULL DEFAULT 'Active'");
  const lt = await getColumns('lab_tests');
  if (lt.sample_type || !dryRun) {
    const rules = [
      ['Whole Blood (EDTA)', "test_name REGEXP 'Blood Test|Hemoglobin|HbA1c|COVID|Culture|Malaria|CBC'"],
      ['Blood Serum (Fasting)', "test_name REGEXP 'Sugar|Glucose|Lipid'"],
      ['Clean Catch Midstream Urine', "test_name REGEXP 'Urine|Pregnancy'"],
      ['Radiological Imaging', "test_name REGEXP 'X-Ray|CT Scan|MRI|Ultrasound|Mammogram|Doppler|Bone Density'"],
      ['Diagnostic Procedure (No Sample)', "test_name REGEXP 'ECG|EEG|Spirometry|Eye Test|Endoscopy|Colonoscopy'"],
    ];
    for (const [type, cond] of rules) {
      await exec(`UPDATE lab_tests SET sample_type = '${type}' WHERE sample_type IS NULL AND ${cond}`);
    }
    await exec("UPDATE lab_tests SET sample_type = 'Blood Serum' WHERE sample_type IS NULL");
  }

  // ---------------- lab_reports ----------------
  say('== lab_reports ==');
  await ensureColumn('lab_reports', 'file_attachment', 'VARCHAR(255) NULL');
  await ensureColumn('lab_reports', 'file_size', 'VARCHAR(30) NULL');

  // ---------------- lab_samples ----------------
  say('== lab_samples ==');
  if (!(await tableExists('lab_samples'))) {
    await exec(`CREATE TABLE lab_samples (
      lab_sample_id INT AUTO_INCREMENT PRIMARY KEY,
      sample_code VARCHAR(20) NOT NULL UNIQUE,
      patient_id INT NOT NULL,
      test_id INT NOT NULL,
      sample_type VARCHAR(100),
      collection_date DATE,
      collection_time VARCHAR(20),
      collection_status VARCHAR(20) DEFAULT 'Pending',
      collected_by VARCHAR(100),
      FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
      FOREIGN KEY (test_id) REFERENCES lab_tests(test_id)
    )`);
  } else {
    say('lab_samples already exists - keeping it and adding any missing columns');
    await ensureColumn('lab_samples', 'sample_code', 'VARCHAR(20) NULL');
    await ensureColumn('lab_samples', 'patient_id', 'INT NULL');
    await ensureColumn('lab_samples', 'test_id', 'INT NULL');
    await ensureColumn('lab_samples', 'sample_type', 'VARCHAR(100) NULL');
    await ensureColumn('lab_samples', 'collection_date', 'DATE NULL');
    await ensureColumn('lab_samples', 'collection_time', 'VARCHAR(20) NULL');
    await ensureColumn('lab_samples', 'collection_status', "VARCHAR(20) NULL DEFAULT 'Pending'");
    await ensureColumn('lab_samples', 'collected_by', 'VARCHAR(100) NULL');

    const sc = await getColumns('lab_samples');
    const pk = Object.values(sc).find((c) => c.ckey === 'PRI');
    if (sc.sample_code && pk) {
      await exec(`UPDATE lab_samples SET sample_code = CONCAT('SMP-', \`${pk.name}\`) WHERE sample_code IS NULL OR sample_code = ''`);
    } else if (!pk) {
      say('WARNING: lab_samples has no primary key; sample_code values for old rows were not backfilled.');
    }
    const idx = await query(
      "SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=? AND TABLE_NAME='lab_samples' AND COLUMN_NAME='sample_code' AND NON_UNIQUE=0",
      [DB]
    );
    if (!idx.length) await exec('ALTER TABLE lab_samples ADD UNIQUE KEY uq_lab_samples_code (sample_code)');
    await relaxUnknownRequired('lab_samples', [
      'sample_code', 'patient_id', 'test_id', 'sample_type', 'collection_date', 'collection_time', 'collection_status', 'collected_by',
    ]);
  }

  // ---------------- staff payroll (new tables) ----------------
  say('== staff payroll ==');
  say('creating tables staff_payroll and salary_payments if missing');
  if (!dryRun) await ensurePayrollTables();

  say('migration finished');
}

// Run directly: node db/migrate.js [--dry-run]
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const dryRun = process.argv.includes('--dry-run');
  migrate({ dryRun })
    .then(() => pool.end())
    .catch(async (err) => {
      console.error('MIGRATION FAILED:', err.message);
      await pool.end();
      process.exit(1);
    });
}
