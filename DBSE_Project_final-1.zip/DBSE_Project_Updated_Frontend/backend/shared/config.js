import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

const here = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(here, '..', '.env') });

const env = process.env;

export const config = {
  db: {
    host: env.DB_HOST || 'localhost',
    port: Number(env.DB_PORT || 3306),
    user: env.DB_USER || 'root',
    password: env.DB_PASSWORD ?? 'Root',
    database: env.DB_NAME || 'hospital_management',
  },
  jwt: {
    secret: env.JWT_SECRET || 'dev-only-secret-change-me',
    expiresIn: env.JWT_EXPIRES_IN || '8h',
  },
  defaults: {
    patientPassword: env.DEFAULT_PATIENT_PASSWORD || 'Patient@123',
    doctorPassword: env.DEFAULT_DOCTOR_PASSWORD || 'Doctor@123',
  },
  ports: {
    gateway: Number(env.GATEWAY_PORT || 5000),
    auth: Number(env.AUTH_PORT || 5001),
    clinical: Number(env.CLINICAL_PORT || 5002),
    pharmacy: Number(env.PHARMACY_PORT || 5003),
    lab: Number(env.LAB_PORT || 5004),
    billing: Number(env.BILLING_PORT || 5005),
    analytics: Number(env.ANALYTICS_PORT || 5006),
  },
  urls: {
    auth: env.AUTH_URL || 'http://localhost:5001',
    clinical: env.CLINICAL_URL || 'http://localhost:5002',
    pharmacy: env.PHARMACY_URL || 'http://localhost:5003',
    lab: env.LAB_URL || 'http://localhost:5004',
    billing: env.BILLING_URL || 'http://localhost:5005',
    analytics: env.ANALYTICS_URL || 'http://localhost:5006',
  },
  corsOrigin: env.CORS_ORIGIN || 'http://localhost:5173',
};

// DB role (stored in users.role) <-> role label used by the React app
export const ROLE_FROM_DB = {
  ADMIN: 'Admin',
  DOCTOR: 'Doctor',
  PATIENT: 'Patient',
  LAB: 'Laboratory Staff',
};
// Tolerant matching: the live database may store roles as 'Patient', 'PATIENT', 'Lab Technician',
// 'Laboratory Staff', ... Anything that looks like one of the four roles maps to its canonical key.
export function canonicalRole(value) {
  const k = String(value ?? '').toUpperCase().replace(/[^A-Z]/g, '');
  if (k.startsWith('ADMIN')) return 'ADMIN';
  if (k.startsWith('DOC') || k === 'PHYSICIAN') return 'DOCTOR';
  if (k.startsWith('PATIENT')) return 'PATIENT';
  if (k.includes('LAB') || k === 'TECHNICIAN' || k === 'PATHOLOGIST') return 'LAB';
  return null;
}
export const ROLE_TO_DB = Object.fromEntries(Object.entries(ROLE_FROM_DB).map(([k, v]) => [v, k]));
