import jwt from 'jsonwebtoken';
import { config } from './config.js';

export function signToken(payload) {
  return jwt.sign(payload, config.jwt.secret, { expiresIn: config.jwt.expiresIn });
}

// Verifies "Authorization: Bearer <jwt>" and attaches req.user
export function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) {
    return res.status(401).json({ message: 'Authentication required. Please log in.' });
  }
  try {
    req.user = jwt.verify(token, config.jwt.secret);
    next();
  } catch (err) {
    const expired = err.name === 'TokenExpiredError';
    return res.status(401).json({ message: expired ? 'Session expired. Please log in again.' : 'Invalid token.' });
  }
}

// Role-based access control. Usage: allow('Admin', 'Doctor')
export function allow(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'You do not have permission to perform this action.' });
    }
    next();
  };
}
