import mysql from 'mysql2/promise';
import { config, canonicalRole } from './config.js';

// One pool per service process. dateStrings keeps DATE columns as 'YYYY-MM-DD'
// (no timezone shifting) and decimalNumbers returns DECIMAL as JS numbers.
export const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  dateStrings: true,
  decimalNumbers: true,
});

export async function query(sql, params = []) {
  const [rows] = await pool.query(sql, params);
  return rows;
}

export async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

// Does the given column exist on the table in the live database?
export async function hasColumn(table, column) {
  const rows = await query(
    `SELECT 1 FROM information_schema.COLUMNS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1`,
    [config.db.database, table, column]
  );
  return rows.length > 0;
}

// Self-registration lets people pick their own username. Adds users.username (unique) if the
// live database does not have it yet. Safe to call repeatedly.
export async function ensureUsernameColumn() {
  if (!(await hasColumn('users', 'username'))) {
    await query('ALTER TABLE users ADD COLUMN username VARCHAR(50) NULL');
  }
  const idx = await query(
    `SELECT 1 FROM information_schema.STATISTICS
      WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND COLUMN_NAME = 'username' AND NON_UNIQUE = 0 LIMIT 1`,
    [config.db.database]
  );
  if (!idx.length) await query('ALTER TABLE users ADD UNIQUE KEY uq_users_username (username)');
}

// The exact spelling the live `users.role` column uses for a role ('PATIENT' -> 'Patient' etc.),
// read from the column's ENUM definition or from existing rows. Falls back to the canonical key.
const roleCache = {};
export async function dbRole(canon) {
  if (roleCache[canon]) return roleCache[canon];
  let found = null;
  const [col] = await query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role'`,
    [config.db.database]
  );
  if (col && /^enum\(/i.test(col.COLUMN_TYPE)) {
    const vals = [...col.COLUMN_TYPE.matchAll(/'((?:[^']|'')*)'/g)].map((m) => m[1].replace(/''/g, "'"));
    found = vals.find((v) => canonicalRole(v) === canon) || null;
  }
  if (!found) {
    const rows = await query('SELECT DISTINCT role FROM users');
    found = rows.map((r) => r.role).find((v) => canonicalRole(v) === canon) || null;
  }
  return (roleCache[canon] = found || canon);
}

// Staff payroll (doctors + laboratory staff). Two NEW tables, created on demand; nothing existing is touched.
//  staff_payroll   - one row per staff user: monthly salary + bank details
//  salary_payments - one row per staff user per month once the salary has been credited
// (no FK to users on purpose: it keeps this working whatever integer type users.user_id has)
export async function ensurePayrollTables() {
  await query(`CREATE TABLE IF NOT EXISTS staff_payroll (
    user_id INT NOT NULL PRIMARY KEY,
    monthly_salary DECIMAL(12,2) NOT NULL DEFAULT 0,
    bank_name VARCHAR(100) NULL,
    account_holder VARCHAR(100) NULL,
    account_number VARCHAR(30) NULL,
    ifsc_code VARCHAR(15) NULL,
    branch VARCHAR(100) NULL,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  )`);
  await query(`CREATE TABLE IF NOT EXISTS salary_payments (
    salary_payment_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    pay_month CHAR(7) NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Credited',
    credited_on DATE NOT NULL,
    payment_mode VARCHAR(30) NOT NULL DEFAULT 'Bank Transfer',
    reference_no VARCHAR(60) NULL,
    bank_name VARCHAR(100) NULL,
    account_last4 VARCHAR(4) NULL,
    UNIQUE KEY uq_salary_user_month (user_id, pay_month)
  )`);
}

// Operations / surgeries (new table, created on demand; nothing existing is touched).
// Powers "Operations Today" on the doctor dashboard.
export async function ensureOperationsTable() {
  await query(`CREATE TABLE IF NOT EXISTS operations (
    operation_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    procedure_name VARCHAR(150) NOT NULL,
    operation_date DATE NOT NULL,
    start_time VARCHAR(10) NULL,
    theatre VARCHAR(40) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Scheduled',
    notes VARCHAR(255) NULL,
    KEY ix_ops_doctor_date (doctor_id, operation_date),
    KEY ix_ops_date (operation_date)
  )`);
}
