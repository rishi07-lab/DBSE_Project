import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import { PaymentIcon, CheckCircleIcon } from './Icons';

const inr = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;
export const monthLabel = (ym) => {
  if (!ym) return '';
  const [y, m] = ym.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });
};
const dateLabel = (d) => (d ? new Date(`${d}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '');

// "My Salary" card shown on the Doctor and Laboratory dashboards.
export default function SalaryCard() {
  const [data, setData] = useState(undefined); // undefined = loading, null = failed
  const [showAll, setShowAll] = useState(false);

  useEffect(() => {
    let cancelled = false;
    API.getMyPayroll().then((d) => { if (!cancelled) setData(d); });
    return () => { cancelled = true; };
  }, []);

  if (data === undefined || data === null) return null;

  const { configured, latest, current_month, current_status, history } = data;
  const creditedNow = current_status === 'Credited';
  const bankLine = data.bank_name ? `${data.bank_name} · A/c ${data.account_masked}${data.ifsc_code ? ` · IFSC ${data.ifsc_code}` : ''}` : null;

  let banner;
  if (!configured) {
    banner = { bg: '#f8fafc', border: '#e2e8f0', color: '#475569', title: 'Salary details not set up yet', text: 'The hospital administrator has not added your salary and bank details yet. They will appear here once added.' };
  } else if (creditedNow) {
    banner = { bg: '#ecfdf5', border: '#a7f3d0', color: '#047857', title: `Salary credited for ${monthLabel(current_month)}`, text: `${inr(latest.amount)} was credited on ${dateLabel(latest.credited_on)}${latest.bank_name ? ` to ${latest.bank_name} (A/c ending ${latest.account_last4})` : ''}.` };
  } else {
    banner = { bg: '#fffbeb', border: '#fde68a', color: '#b45309', title: `${monthLabel(current_month)} salary is being processed`, text: latest ? `Your last salary of ${inr(latest.amount)} (${monthLabel(latest.pay_month)}) was credited on ${dateLabel(latest.credited_on)}.` : 'No salary has been credited yet. It will show here as soon as the administrator releases it.' };
  }

  const rows = showAll ? history : history.slice(0, 3);

  return (
    <div className="table-card" style={{ marginBottom: '24px', overflow: 'hidden' }}>
      <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <span style={{ color: '#d97706', display: 'flex' }}><PaymentIcon size={20} /></span>
        <h3 style={{ fontSize: '15.5px', fontWeight: 700, color: '#0f172a' }}>My Salary</h3>
        {configured && <span className="badge badge-gray" style={{ marginLeft: 'auto' }}>Monthly: {inr(data.monthly_salary)}</span>}
      </div>

      <div style={{ padding: '16px 20px' }}>
        <div style={{ background: banner.bg, border: `1px solid ${banner.border}`, borderRadius: '12px', padding: '14px 16px', display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
          {creditedNow && <span style={{ color: banner.color, display: 'flex', marginTop: 1 }}><CheckCircleIcon size={20} /></span>}
          <div>
            <div style={{ fontWeight: 700, color: banner.color, fontSize: '14px' }}>{banner.title}</div>
            <div style={{ fontSize: '13px', color: '#475569', marginTop: 3 }}>{banner.text}</div>
            {configured && bankLine && <div style={{ fontSize: '12px', color: '#64748b', marginTop: 6 }}>Salary account: {bankLine}</div>}
          </div>
        </div>

        {history.length > 0 && (
          <div className="table-responsive" style={{ marginTop: '14px' }}>
            <table className="custom-table">
              <thead>
                <tr><th>Month</th><th>Amount</th><th>Credited On</th><th>Mode</th><th>Reference</th><th>Status</th></tr>
              </thead>
              <tbody>
                {rows.map((h) => (
                  <tr key={h.salary_payment_id}>
                    <td style={{ fontWeight: 700, color: '#0f172a' }}>{monthLabel(h.pay_month)}</td>
                    <td style={{ fontWeight: 700, color: '#059669' }}>{inr(h.amount)}</td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{dateLabel(h.credited_on)}</td>
                    <td><span className="badge badge-gray">{h.payment_mode}</span></td>
                    <td style={{ color: '#64748b', fontSize: '12px' }}>{h.reference_no}</td>
                    <td><span className="badge badge-success">{h.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {history.length > 3 && (
          <button className="btn btn-sm btn-secondary" style={{ marginTop: '12px' }} onClick={() => setShowAll(!showAll)}>
            {showAll ? 'Show fewer' : `Show all ${history.length} months`}
          </button>
        )}
      </div>
    </div>
  );
}
