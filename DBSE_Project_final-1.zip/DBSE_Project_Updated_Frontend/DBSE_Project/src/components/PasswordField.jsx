import React, { useState } from 'react';

// Same rule as the server: at least 8 characters, with a letter and a number.
export const PASSWORD_MSG = 'Password must be at least 8 characters and include a letter and a number.';
export const isValidPassword = (pw) => typeof pw === 'string' && pw.length >= 8 && /[A-Za-z]/.test(pw) && /\d/.test(pw);

const generate = () => {
  const letters = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
  const digits = '23456789';
  const pick = (s) => s[Math.floor(Math.random() * s.length)];
  let out = pick(letters.slice(0, 24)) + pick(letters.slice(24));
  for (let i = 0; i < 4; i += 1) out += pick(letters);
  out += pick(digits) + pick(digits) + '@' + pick(digits);
  return out;
};

// Password input with show/hide and a "Generate" helper. Use `required` when creating an account;
// leave it optional on edit forms (blank = keep the current password).
export default function PasswordField({ value, onChange, required = false, label = 'Login Password', hint }) {
  const [show, setShow] = useState(false);
  const bad = value && !isValidPassword(value);
  return (
    <div className="form-group col-span-2">
      <label className="form-label">{label}{required ? ' *' : ''}</label>
      <div style={{ display: 'flex', gap: '8px' }}>
        <input
          type={show ? 'text' : 'password'}
          className="form-input"
          style={{ flex: 1 }}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={required ? 'Set a password for this account' : 'Leave blank to keep the current password'}
          autoComplete="new-password"
          required={required}
        />
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => setShow((s) => !s)}>
          {show ? 'Hide' : 'Show'}
        </button>
        <button type="button" className="btn btn-secondary btn-sm" onClick={() => { onChange(generate()); setShow(true); }}>
          Generate
        </button>
      </div>
      <div style={{ fontSize: '12px', marginTop: '4px', color: bad ? '#dc2626' : '#64748b' }}>
        {bad ? PASSWORD_MSG : (hint || 'Min 8 characters with a letter and a number. They log in with their email and this password.')}
      </div>
    </div>
  );
}
