// CarePulse HMS - API client
// All data now comes from the Express microservices (through the API gateway on :5000)
// which read/write the MySQL `hospital_management` database. Authentication uses JWT:
// the token is stored in localStorage and sent as `Authorization: Bearer <token>`.
//
// In development Vite proxies /api -> http://localhost:5000 (see vite.config.js).
// Set VITE_API_BASE (e.g. http://my-server:5000/api) to point somewhere else.

const BASE = import.meta.env.VITE_API_BASE || '/api';
const TOKEN_KEY = 'hms_token';
const USER_KEY = 'hms_current_user';

// ----- session helpers -----
const getToken = () => {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
};
const saveSession = (token, user) => {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
};
const clearSession = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
};

// Remove any leftovers from the old localStorage-only demo version.
(function cleanupLegacyDemoData() {
  try {
    Object.keys(localStorage)
      .filter((k) => k.startsWith('hms_') && ![TOKEN_KEY, USER_KEY].includes(k))
      .forEach((k) => localStorage.removeItem(k));
  } catch { /* ignore */ }
})();

// ----- low-level request -----
async function request(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  const token = getToken();
  if (auth && token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
  } catch (err) {
    const e = new Error('Cannot reach the server. Is the backend running on port 5000?');
    e.network = true;
    throw e;
  }

  let data = null;
  try { data = await res.json(); } catch { /* empty body */ }

  if (res.status === 401 && auth && path !== '/auth/login') {
    // token missing/expired -> force a fresh login
    clearSession();
    window.location.reload();
  }
  if (!res.ok) {
    const e = new Error(data?.message || `Request failed (${res.status})`);
    e.status = res.status;
    throw e;
  }
  return data;
}

// GET helper: never throws (pages simply render an empty state if the call fails)
async function read(path, fallback = []) {
  try {
    return await request(path);
  } catch (err) {
    console.error(`GET ${path} failed:`, err.message);
    return fallback;
  }
}

// write helper: shows the server's message (validation / duplicate / permission) and re-throws
async function write(path, method, body) {
  try {
    return await request(path, { method, body });
  } catch (err) {
    window.alert(err.message);
    throw err;
  }
}

// Builds get/add/update/delete functions for a REST resource.
const resource = (name, idKey, { update = true, del = true } = {}) => ({
  list: () => read(`/${name}`),
  add: (data) => write(`/${name}`, 'POST', data),
  update: update ? (data) => write(`/${name}/${encodeURIComponent(data[idKey])}`, 'PUT', data) : undefined,
  remove: del ? (id) => write(`/${name}/${encodeURIComponent(id)}`, 'DELETE') : undefined,
});

const specializations = resource('specializations', 'specialization_id');
const doctors = resource('doctors', 'doctor_id');
const patients = resource('patients', 'patient_id');
const medicines = resource('medicines', 'medicine_id');
const prescriptions = resource('prescriptions', 'prescription_id', { update: false });
const labTests = resource('lab-tests', 'test_id');
const labSamples = resource('lab-samples', 'sample_id', { del: false });
const labReports = resource('lab-reports', 'report_id');
const bills = resource('bills', 'bill_id');
const payments = resource('payments', 'payment_id', { update: false });
const insurance = resource('insurance', 'insurance_id');
const medicalRecords = resource('medical-records', 'record_id');

export const API = {
  // ---------------- Authentication (JWT) ----------------
  getCurrentUser() {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw && getToken() ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  },

  async login(email, password, role) {
    try {
      const data = await request('/auth/login', { method: 'POST', body: { email, password, ...(role ? { role } : {}) }, auth: false });
      saveSession(data.token, data.user);
      return { success: true, user: data.user };
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  // Public sign-up: creates a Patient account with the person's own username + password
  // and signs them in straight away.
  async register({ name, username, email, phone, password }) {
    try {
      const data = await request('/auth/register', {
        method: 'POST', body: { name, username, email, phone, password }, auth: false,
      });
      saveSession(data.token, data.user);
      return { success: true, user: data.user };
    } catch (err) {
      return { success: false, message: err.message };
    }
  },

  // Validates the stored token with the server (called once on app start).
  async restoreSession() {
    if (!getToken()) return null;
    try {
      const data = await request('/auth/me');
      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      return data.user;
    } catch {
      clearSession();
      return null;
    }
  },

  logout() {
    clearSession();
  },

  changePassword: (current_password, new_password) =>
    write('/auth/change-password', 'POST', { current_password, new_password }),

  // ---------------- Dashboards ----------------
  getAdminDashboardStats: () => read('/dashboard/admin', {}),
  getDoctorDashboardStats: () => read('/dashboard/doctor', { recentPrescriptions: [] }),
  getDashboardStats() { return this.getAdminDashboardStats(); },
  // the patient is always taken from the JWT on the server; the argument is kept for compatibility
  getPatientDashboardStats: () => read('/dashboard/patient', { prescriptions: [], labReports: [], bills: [], medicalRecords: [], payments: [] }),
  getLabDashboardStats: () => read('/dashboard/lab', { recentSamples: [], recentReports: [] }),

  // ---------------- Resources ----------------
  getSpecializations: specializations.list,
  addSpecialization: specializations.add,
  updateSpecialization: specializations.update,
  deleteSpecialization: specializations.remove,

  getDoctors: doctors.list,
  addDoctor: doctors.add,
  updateDoctor: doctors.update,
  deleteDoctor: doctors.remove,

  getPatients: patients.list,
  addPatient: patients.add,
  updatePatient: patients.update,
  deletePatient: patients.remove,

  getMedicines: medicines.list,
  addMedicine: medicines.add,
  updateMedicine: medicines.update,
  deleteMedicine: medicines.remove,

  getPrescriptions: prescriptions.list,
  addPrescription: prescriptions.add,
  deletePrescription: prescriptions.remove,

  getLabTests: labTests.list,
  addLabTest: labTests.add,
  updateLabTest: labTests.update,
  deleteLabTest: labTests.remove,

  getLabSamples: labSamples.list,
  addLabSample: labSamples.add,
  updateLabSample: labSamples.update,

  getLabReports: labReports.list,
  addLabReport: labReports.add,
  updateLabReport: labReports.update,
  deleteLabReport: labReports.remove,

  getBills: bills.list,
  addBill: bills.add,
  updateBill: bills.update,
  deleteBill: bills.remove,

  getPayments: payments.list,
  addPayment: payments.add,
  deletePayment: payments.remove,

  getInsurance: insurance.list,
  addInsurance: insurance.add,
  updateInsurance: insurance.update,
  deleteInsurance: insurance.remove,

  // ---------------- Staff payroll (salary + bank details) ----------------
  getPayroll: (month) => read(`/payroll${month ? `?month=${encodeURIComponent(month)}` : ''}`),
  updatePayroll: (userId, data) => write(`/payroll/${encodeURIComponent(userId)}`, 'PUT', data),
  creditSalary: (userId, data) => write(`/payroll/${encodeURIComponent(userId)}/credit`, 'POST', data),
  creditAllSalaries: (data) => write('/payroll/credit-all', 'POST', data),
  getSalaryHistory: (userId) => read(`/payroll/${encodeURIComponent(userId)}/history`),
  undoSalaryCredit: (userId, month) => write(`/payroll/${encodeURIComponent(userId)}/credit/${encodeURIComponent(month)}`, 'DELETE'),
  // the logged-in doctor / lab staff member's own salary (account number is masked by the server)
  getMyPayroll: () => read('/payroll/me', null),

  // ---------------- Laboratory staff accounts (Admin) ----------------
  getLabStaff: () => read('/auth/staff/lab'),
  addLabStaff: (data) => write('/auth/staff/lab', 'POST', data),
  updateLabStaff: (data) => write(`/auth/staff/lab/${encodeURIComponent(data.user_id)}`, 'PUT', data),
  deleteLabStaff: (id) => write(`/auth/staff/lab/${encodeURIComponent(id)}`, 'DELETE'),

  getMedicalRecords: medicalRecords.list,
  addMedicalRecord: medicalRecords.add,
  updateMedicalRecord: medicalRecords.update,
  deleteMedicalRecord: medicalRecords.remove,
};
