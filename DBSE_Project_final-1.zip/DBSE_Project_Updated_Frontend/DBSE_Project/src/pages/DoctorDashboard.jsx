import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import SalaryCard from '../components/SalaryCard';
import {
  PatientsIcon,
  MedicalRecordIcon,
  PrescriptionIcon,
  LabReportIcon,
  PlusIcon,
  ActivityIcon,
  CheckCircleIcon,
} from '../components/Icons';

export default function DoctorDashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      const data = await API.getDoctorDashboardStats();
      setStats(data);
      setLoading(false);
    }
    loadStats();
  }, []);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading clinical dashboard...
        </div>
      </div>
    );
  }

  const p = stats.profile;
  const myPatients = stats.myPatients || [];
  const departments = stats.departments || [];

  const todaysOps = stats.todaysOperations || [];
  const opBadge = (st) => (st === 'Completed' ? 'badge-success' : st === 'In Progress' ? 'badge-primary' : 'badge-gray');

  const statCards = [
    {
      label: 'Patients Seen',
      value: stats.patientsSeen ?? 0,
      sub: `${stats.patientsSeenToday ?? 0} today · ${stats.patientsSeenThisMonth ?? 0} this month`,
      icon: CheckCircleIcon,
      bgColor: '#dcfce7',
      iconColor: '#16a34a',
      page: 'patients',
    },
    {
      label: 'Operations Today',
      value: stats.operationsToday ?? 0,
      sub: `${stats.operationsCompletedToday ?? 0} done · ${stats.operationsInProgress ?? 0} in progress · ${stats.operationsUpcoming ?? 0} upcoming`,
      icon: ActivityIcon,
      bgColor: '#ffedd5',
      iconColor: '#ea580c',
      page: null,
    },
    {
      label: 'My Patients',
      value: stats.totalPatients,
      icon: PatientsIcon,
      bgColor: '#e0f2fe',
      iconColor: '#0284c7',
      page: 'patients',
    },
    {
      label: 'My Prescriptions',
      value: stats.totalPrescriptions,
      icon: PrescriptionIcon,
      bgColor: '#ede9fe',
      iconColor: '#7c3aed',
      page: 'prescriptions',
    },
    {
      label: 'My Patients\' Records',
      value: stats.totalMedicalRecords,
      icon: MedicalRecordIcon,
      bgColor: '#d1fae5',
      iconColor: '#059669',
      page: 'medical-records',
    },
    {
      label: 'My Lab Reports',
      value: stats.totalLabReports,
      icon: LabReportIcon,
      bgColor: '#fee2e2',
      iconColor: '#dc2626',
      page: 'lab-reports',
    },
  ];

  return (
    <div className="page-container">
      {/* Page Heading */}
      <div className="page-header">
        <div>
          <h1>Clinical Overview</h1>
          <p>{p ? `${p.specialization_name || 'General'} — your caseload, prescriptions, and clinical records at a glance.` : 'Active caseloads, prescriptions, and clinical records at a glance.'}</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('patients')}>
            <PlusIcon size={16} />
            <span>Admit Patient</span>
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('prescriptions')}>
            <PlusIcon size={16} />
            <span>New Prescription</span>
          </button>
        </div>
      </div>

      {/* Logged-in doctor profile */}
      {p && (
        <div className="table-card" style={{ padding: '18px 20px', marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '16px', flexWrap: 'wrap' }}>
          <div style={{ width: 52, height: 52, borderRadius: '50%', background: '#e0f2fe', color: '#0284c7', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 20 }}>
            {(p.name || 'D').replace(/^Dr\.?\s*/i, '').charAt(0).toUpperCase()}
          </div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <div style={{ fontSize: '17px', fontWeight: 700, color: '#0f172a' }}>{p.name}</div>
            <div style={{ fontSize: '13px', color: '#64748b', marginTop: 2 }}>
              {p.specialization_name || 'General'} · Doctor ID #{p.doctor_id}{p.email ? ` · ${p.email}` : ''}
            </div>
          </div>
          <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
            <span className="badge badge-primary">{p.specialization_name || 'General'}</span>
            {p.qualification && <span className="badge badge-gray">{p.qualification}</span>}
            {p.experience_years != null && <span className="badge badge-gray">{p.experience_years} yrs experience</span>}
            {p.availability_status && <span className="badge badge-success">{p.availability_status}</span>}
          </div>
        </div>
      )}

      {/* Salary credited / bank account */}
      <SalaryCard />

      {/* KPI Stats Grid */}
      <div className="stats-grid">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="stat-card"
              style={{ cursor: 'pointer' }}
              onClick={() => card.page && onNavigate(card.page)}
            >
              <div
                className="stat-icon-wrapper"
                style={{ backgroundColor: card.bgColor, color: card.iconColor }}
              >
                <Icon size={26} />
              </div>
              <div className="stat-card-info">
                <span className="stat-card-value">{card.value}</span>
                <span className="stat-card-label">{card.label}</span>
                {card.sub && <span className="stat-card-trend" style={{ color: '#64748b' }}>{card.sub}</span>}
              </div>
            </div>
          );
        })}
      </div>

      {/* Today's operations */}
      <div className="table-card" style={{ marginBottom: '24px' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>Today's Operations</h3>
          <span style={{ fontSize: '12px', color: '#64748b' }}>{stats.operationsToday ?? 0} scheduled today · {stats.operationsTotal ?? 0} total</span>
        </div>
        <div className="table-responsive">
          <table className="custom-table">
            <thead><tr><th>Time</th><th>Patient</th><th>Procedure</th><th>Theatre</th><th>Status</th></tr></thead>
            <tbody>
              {todaysOps.length > 0 ? todaysOps.map((o) => (
                <tr key={o.operation_id}>
                  <td style={{ fontWeight: 700 }}>{o.start_time}</td>
                  <td style={{ fontWeight: 600 }}>{o.patient_name}</td>
                  <td>{o.procedure_name}</td>
                  <td><span className="badge badge-gray">{o.theatre}</span></td>
                  <td><span className={`badge ${opBadge(o.status)}`}>{o.status}</span></td>
                </tr>
              )) : (
                <tr><td colSpan="5" style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>No operations scheduled for today.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Lower Section: Recent Prescriptions & Quick Module Launch */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>

        {/* Recent Prescriptions Table Card */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>
              Recent Prescriptions Issued
            </h3>
            <button
              className="btn btn-sm btn-secondary"
              onClick={() => onNavigate('prescriptions')}
            >
              View All
            </button>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Doctor</th>
                  <th>Medicine</th>
                  <th>Dosage</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {stats.recentPrescriptions?.length > 0 ? (
                  stats.recentPrescriptions.map((p) => (
                    <tr key={p.prescription_id}>
                      <td style={{ fontWeight: '600' }}>{p.patient_name}</td>
                      <td style={{ color: '#0284c7' }}>{p.doctor_name}</td>
                      <td>{p.medicine_name}</td>
                      <td><span className="badge badge-gray">{p.dosage}</span></td>
                      <td style={{ color: '#64748b', fontSize: '12px' }}>{p.prescription_date}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>
                      No prescriptions recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Quick Module Launch */}
        <div className="table-card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '16px' }}>
            Clinical Modules Quick Launch
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            {[
              { title: 'Patients', desc: 'Patient directory', page: 'patients' },
              { title: 'Medical Records', desc: 'Diagnoses & history', page: 'medical-records' },
              { title: 'Prescriptions', desc: 'Issue & track Rx', page: 'prescriptions' },
              { title: 'Lab Reports', desc: 'Pathology results', page: 'lab-reports' },
            ].map((m, i) => (
              <div
                key={i}
                onClick={() => onNavigate(m.page)}
                style={{
                  padding: '14px',
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  transition: 'all 0.18s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#e0f2fe';
                  e.currentTarget.style.borderColor = '#0284c7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#f8fafc';
                  e.currentTarget.style.borderColor = '#e2e8f0';
                }}
              >
                <div style={{ fontWeight: '700', fontSize: '13.5px', color: '#0f172a' }}>{m.title}</div>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

        {/* My Patients (patients with a prescription or lab report from this doctor) */}
        <div className="table-card">
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>My Patients</h3>
            <span style={{ fontSize: '12px', color: '#64748b' }}>{stats.totalPatients} total</span>
          </div>
          <div className="table-responsive">
            <table className="custom-table">
              <thead><tr><th>Patient</th><th>Age</th><th>Gender</th><th>City</th></tr></thead>
              <tbody>
                {myPatients.length > 0 ? myPatients.map((pt) => (
                  <tr key={pt.patient_id}>
                    <td style={{ fontWeight: '600' }}>{pt.name}</td>
                    <td>{pt.age ?? '-'}</td>
                    <td>{pt.gender || '-'}</td>
                    <td style={{ color: '#64748b' }}>{pt.city || '-'}</td>
                  </tr>
                )) : (
                  <tr><td colSpan="4" style={{ textAlign: 'center', color: '#94a3b8', padding: '24px' }}>
                    No patients linked to you yet. Patients appear here once you issue them a prescription or lab report.
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Doctors grouped by specialization (own department first) */}
        <div className="table-card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '14px' }}>Doctors by Specialization</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', maxHeight: 340, overflowY: 'auto' }}>
            {departments.map((d) => (
              <div key={d.specialization_name} style={{
                padding: '10px 12px', borderRadius: '10px',
                background: d.isMine ? '#e0f2fe' : '#f8fafc',
                border: `1px solid ${d.isMine ? '#0284c7' : '#e2e8f0'}`,
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: 700, fontSize: '13.5px', color: '#0f172a' }}>
                  <span>{d.specialization_name}{d.isMine ? ' (your department)' : ''}</span>
                  <span style={{ color: '#64748b', fontWeight: 600 }}>{d.doctorCount}</span>
                </div>
                <div style={{ fontSize: '12px', color: '#475569', marginTop: 2 }}>
                  {d.doctors.map((x) => x.name).join(', ')}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
