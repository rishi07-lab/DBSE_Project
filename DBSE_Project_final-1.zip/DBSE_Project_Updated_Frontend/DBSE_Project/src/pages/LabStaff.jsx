import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import PasswordField, { isValidPassword, PASSWORD_MSG } from '../components/PasswordField';
import { PlusIcon, EditIcon, TrashIcon, SearchIcon } from '../components/Icons';

const EMPTY = { name: '', email: '', phone: '', password: '' };

// Admin: create laboratory staff accounts with a password of your choice, reset it later, or remove the account.
export default function LabStaff() {
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);

  const load = async () => {
    setLoading(true);
    setStaff(await API.getLabStaff());
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const openAdd = () => { setEditing(null); setForm(EMPTY); setIsOpen(true); };
  const openEdit = (s) => { setEditing(s); setForm({ name: s.name || '', email: s.email || '', phone: s.phone || '', password: '' }); setIsOpen(true); };

  const submit = async (e) => {
    e.preventDefault();
    if ((!editing || form.password) && !isValidPassword(form.password)) { window.alert(PASSWORD_MSG); return; }
    if (editing) {
      await API.updateLabStaff({ ...form, user_id: editing.user_id });
      if (form.password) window.alert(`Password updated.\nLogin: ${form.email}\nPassword: ${form.password}`);
    } else {
      await API.addLabStaff(form);
      window.alert(`Laboratory staff account created.\nLogin: ${form.email}\nPassword: ${form.password}`);
    }
    setIsOpen(false);
    load();
  };

  const remove = async (s) => {
    if (window.confirm(`Remove the account for ${s.name}?`)) {
      await API.deleteLabStaff(s.user_id);
      load();
    }
  };

  const q = search.toLowerCase();
  const rows = staff.filter((s) => !q || s.name?.toLowerCase().includes(q) || s.email?.toLowerCase().includes(q) || s.phone?.includes(q));

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Laboratory Staff Accounts</h1>
          <p>Create laboratory staff logins. You choose the password; they sign in at Laboratory Login with their email and that password.</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          <PlusIcon size={16} />
          <span>Add Lab Staff</span>
        </button>
      </div>

      <div className="table-card">
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border-color)', display: 'flex', alignItems: 'center', gap: '10px' }}>
          <SearchIcon size={16} />
          <input className="form-input" style={{ maxWidth: 320 }} placeholder="Search by name, email or phone" value={search} onChange={(e) => setSearch(e.target.value)} />
          <span style={{ marginLeft: 'auto', fontSize: '12px', color: '#64748b' }}>{rows.length} account{rows.length === 1 ? '' : 's'}</span>
        </div>
        <div className="table-responsive">
          <table className="custom-table">
            <thead><tr><th>ID</th><th>Name</th><th>Login Email</th><th>Phone</th><th style={{ textAlign: 'right' }}>Actions</th></tr></thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="5" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>Loading...</td></tr>
              ) : rows.length === 0 ? (
                <tr><td colSpan="5" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No laboratory staff accounts yet.</td></tr>
              ) : rows.map((s) => (
                <tr key={s.user_id}>
                  <td style={{ color: '#64748b' }}>#{s.user_id}</td>
                  <td style={{ fontWeight: 600 }}>{s.name}</td>
                  <td>{s.email}</td>
                  <td>{s.phone || '-'}</td>
                  <td style={{ textAlign: 'right' }}>
                    <button className="btn-icon" title="Edit / reset password" onClick={() => openEdit(s)}><EditIcon size={16} /></button>
                    <button className="btn-icon" title="Remove" onClick={() => remove(s)}><TrashIcon size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <Modal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        title={editing ? 'Edit Laboratory Staff' : 'Add Laboratory Staff'}
        footer={
          <>
            <button className="btn btn-secondary" onClick={() => setIsOpen(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={submit}>{editing ? 'Save Changes' : 'Create Account'}</button>
          </>
        }
      >
        <form onSubmit={submit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Full Name *</label>
            <input type="text" className="form-input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Kavita Reddy" required />
          </div>
          <div className="form-group">
            <label className="form-label">Email (used to log in) *</label>
            <input type="email" className="form-input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="name@hospital.com" required />
          </div>
          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input type="text" className="form-input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+91 98765 43210" />
          </div>
          <PasswordField
            value={form.password}
            onChange={(v) => setForm({ ...form, password: v })}
            required={!editing}
            label={editing ? 'Reset Password (optional)' : 'Login Password'}
          />
        </form>
      </Modal>
    </div>
  );
}
