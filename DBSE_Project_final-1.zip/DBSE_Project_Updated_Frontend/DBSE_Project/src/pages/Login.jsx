import React, { useState } from 'react';
import { ActivityIcon, DoctorIcon, DashboardIcon, LabTestIcon, PatientsIcon } from '../components/Icons';
import { API } from '../services/api';

// The four login areas. `role` matches the role names the backend returns for a verified account.
const ROLE_OPTIONS = [
  { role: 'Doctor', title: 'Doctor Login', blurb: 'Patients, prescriptions & clinical records', color: '#0284c7', bg: '#f0f9ff', border: '#bae6fd', Icon: DoctorIcon },
  { role: 'Admin', title: 'Admin Login', blurb: 'Hospital administration, billing & staff', color: '#ea580c', bg: '#fff7ed', border: '#fed7aa', Icon: DashboardIcon },
  { role: 'Laboratory Staff', title: 'Laboratory Login', blurb: 'Samples, tests & lab reports', color: '#6d28d9', bg: '#f5f3ff', border: '#ddd6fe', Icon: LabTestIcon },
  { role: 'Patient', title: 'Patient Login', blurb: 'Your records, reports & bills', color: '#059669', bg: '#ecfdf5', border: '#a7f3d0', Icon: PatientsIcon },
];

export default function Login({ onLoginSuccess }) {
  const [role, setRole] = useState(null); // null = role chooser; otherwise the login area that was opened
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [reg, setReg] = useState({ name: '', username: '', email: '', phone: '', password: '', confirm: '' });
  const [showPw, setShowPw] = useState(false);
  const [busy, setBusy] = useState(false);

  const setField = (k) => (e) => setReg((r) => ({ ...r, [k]: e.target.value }));
  const switchMode = (m) => { setMode(m); setError(''); };
  const roleInfo = ROLE_OPTIONS.find((o) => o.role === role);
  const chooseRole = (r) => { setRole(r); setEmail(''); setPassword(''); setError(''); };
  const backToRoles = () => { setRole(null); setEmail(''); setPassword(''); setError(''); };

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');
    if (!/^[a-z0-9][a-z0-9._-]{2,29}$/.test(reg.username.trim().toLowerCase())) {
      return setError('Username must be 3-30 characters: letters, numbers, dot, dash or underscore.');
    }
    if (reg.password.length < 8 || !/[A-Za-z]/.test(reg.password) || !/\d/.test(reg.password)) {
      return setError('Password must be at least 8 characters and include a letter and a number.');
    }
    if (reg.password !== reg.confirm) return setError('Passwords do not match.');
    setBusy(true);
    const res = await API.register(reg);
    setBusy(false);
    if (res.success) onLoginSuccess(res.user);
    else setError(res.message || 'Could not create the account.');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    const res = await API.login(email, password, role);
    setBusy(false);
    if (!res.success) return setError(res.message || 'Invalid username/email or password.');
    // second check on the verified account's actual role (the server already refuses a mismatch)
    if (res.user.role !== role) {
      API.logout();
      return setError(`This account is not a ${roleInfo?.title.replace(' Login', '')} account. Please use the correct login.`);
    }
    onLoginSuccess(res.user);
  };

  // Sample accounts only FILL the form; the person still presses Sign In (no direct dashboard entry).
  const handleFill = (demoEmail, demoPassword) => {
    setEmail(demoEmail);
    setPassword(demoPassword);
    setError('');
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #0369a1 50%, #0d9488 100%)',
      padding: '24px',
    }}>
      <div style={{
        background: '#ffffff',
        borderRadius: '18px',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
        width: '100%',
        maxWidth: '560px',
        overflow: 'hidden',
      }}>
        {/* Card Header */}
        <div style={{
          padding: '32px 32px 20px',
          textAlign: 'center',
          borderBottom: '1px solid #f1f5f9',
        }}>
          <div style={{
            width: '56px',
            height: '56px',
            background: 'linear-gradient(135deg, #0284c7, #0d9488)',
            borderRadius: '14px',
            margin: '0 auto 14px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#ffffff',
            boxShadow: '0 4px 12px rgba(2, 132, 199, 0.35)',
          }}>
            <ActivityIcon size={32} />
          </div>
          <h2 style={{ fontSize: '24px', fontWeight: '800', color: '#0f172a', letterSpacing: '-0.5px' }}>
            CarePulse Hospital System
          </h2>
          <p style={{ color: '#64748b', fontSize: '13.5px', marginTop: '4px' }}>
            Hospital Clinical &amp; Administrative Management Portal
          </p>

        </div>

        {/* Form Body */}
        <div style={{ padding: '24px 32px 28px' }}>
          {error && (
            <div style={{
              background: '#fee2e2',
              color: '#dc2626',
              padding: '10px 14px',
              borderRadius: '8px',
              fontSize: '13px',
              marginBottom: '16px',
              border: '1px solid #fecaca',
            }}>
              {error}
            </div>
          )}

          {mode === 'register' ? (
            <>
              <div style={{ marginBottom: '14px' }}>
                <div style={{ fontSize: '17px', fontWeight: 700, color: '#0f172a' }}>Create your patient account</div>
                <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>
                  Choose your own username and password — you'll use them to sign in.
                </div>
              </div>
              <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                <div className="form-group">
                  <label className="form-label">Full name</label>
                  <input className="form-input" value={reg.name} onChange={setField('name')} placeholder="e.g. Ananya Rao" required />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div className="form-group">
                    <label className="form-label">Username</label>
                    <input className="form-input" value={reg.username} onChange={setField('username')}
                      placeholder="e.g. ananya.rao" autoComplete="username" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Phone (optional)</label>
                    <input className="form-input" value={reg.phone} onChange={setField('phone')} placeholder="10-digit number" autoComplete="tel" />
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input type="email" className="form-input" value={reg.email} onChange={setField('email')}
                    placeholder="you@example.com" autoComplete="email" required />
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                  <div className="form-group">
                    <label className="form-label">Password</label>
                    <input type={showPw ? 'text' : 'password'} className="form-input" value={reg.password}
                      onChange={setField('password')} placeholder="Min 8 chars, letter + number" autoComplete="new-password" required />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Confirm password</label>
                    <input type={showPw ? 'text' : 'password'} className="form-input" value={reg.confirm}
                      onChange={setField('confirm')} placeholder="Re-enter password" autoComplete="new-password" required />
                  </div>
                </div>
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '12.5px', color: '#475569', cursor: 'pointer' }}>
                  <input type="checkbox" checked={showPw} onChange={(e) => setShowPw(e.target.checked)} /> Show passwords
                </label>
                <button type="submit" className="btn btn-primary" disabled={busy} style={{ padding: '12px' }}>
                  {busy ? 'Creating account…' : 'Create Account'}
                </button>
              </form>
              <p style={{ textAlign: 'center', fontSize: '13px', color: '#64748b', marginTop: '16px' }}>
                Already registered?{' '}
                <button type="button" onClick={() => switchMode('login')}
                  style={{ background: 'none', border: 'none', color: '#0284c7', fontWeight: 700, cursor: 'pointer', padding: 0 }}>
                  Sign in
                </button>
              </p>
            </>
          ) : !role ? (
            <>
              <div style={{ marginBottom: '16px' }}>
                <div style={{ fontSize: '17px', fontWeight: 700, color: '#0f172a' }}>Select your role to sign in</div>
                <div style={{ fontSize: '12.5px', color: '#64748b', marginTop: '2px' }}>
                  Choose how you use CarePulse. You will be asked for that role's username/email and password next.
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', gap: '12px' }}>
                {ROLE_OPTIONS.map(({ role: r, title, blurb, color, bg, border, Icon }) => (
                  <button key={r} type="button" onClick={() => chooseRole(r)}
                    style={{ textAlign: 'left', background: bg, border: `1px solid ${border}`, borderRadius: '12px', padding: '14px 16px', cursor: 'pointer', display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
                    <span style={{ width: 38, height: 38, borderRadius: 10, background: '#ffffff', color, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon size={20} />
                    </span>
                    <span>
                      <span style={{ display: 'block', fontSize: '14.5px', fontWeight: 800, color: '#0f172a' }}>{title}</span>
                      <span style={{ display: 'block', fontSize: '12px', color: '#64748b', marginTop: 2 }}>{blurb}</span>
                    </span>
                  </button>
                ))}
              </div>
              <p style={{ textAlign: 'center', fontSize: '13px', color: '#64748b', marginTop: '18px' }}>
                New patient?{' '}
                <button type="button" onClick={() => switchMode('register')}
                  style={{ background: 'none', border: 'none', color: '#0284c7', fontWeight: 700, cursor: 'pointer', padding: 0 }}>
                  Create an account
                </button>
              </p>
            </>
          ) : (
          <>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div style={{ fontSize: '17px', fontWeight: 800, color: roleInfo.color }}>{roleInfo.title}</div>
            <button type="button" onClick={backToRoles}
              style={{ background: 'none', border: 'none', color: '#0284c7', fontWeight: 700, cursor: 'pointer', padding: 0, fontSize: '13px' }}>
              ← Change role
            </button>
          </div>
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            <div className="form-group">
              <label className="form-label">Username or Email</label>
              <input
                type="text"
                className="form-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Your username or email"
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-input"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />
            </div>

            <button type="submit" className="btn btn-primary" disabled={busy} style={{ padding: '12px', marginTop: '4px' }}>
              {busy ? 'Signing in…' : `Sign In as ${roleInfo.title.replace(' Login', '')}`}
            </button>
          </form>

          {role === 'Patient' && (
            <p style={{ textAlign: 'center', fontSize: '13px', color: '#64748b', marginTop: '16px' }}>
              New patient?{' '}
              <button type="button" onClick={() => switchMode('register')}
                style={{ background: 'none', border: 'none', color: '#0284c7', fontWeight: 700, cursor: 'pointer', padding: 0 }}>
                Create an account
              </button>
            </p>
          )}

          {/* Demo Login Credentials Box */}
          <div style={{
            marginTop: '22px',
            paddingTop: '18px',
            borderTop: '1px solid #f1f5f9',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '10px',
            }}>
              <span style={{ fontSize: '12px', fontWeight: '700', color: '#475569', letterSpacing: '0.4px', textTransform: 'uppercase' }}>
                SAMPLE LOGIN ACCOUNTS
              </span>
              <span style={{ fontSize: '11px', color: '#0284c7', fontWeight: '600' }}>
                Click to fill the form, then press Sign In
              </span>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>

              {role === 'Doctor' && (
              <div style={{
                background: '#f0f9ff',
                border: '1px solid #bae6fd',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-primary" style={{ fontSize: '11px', padding: '2px 8px' }}>Doctor</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>doctor@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Doctor@123</code>
                    {' '}<span style={{ color: '#0284c7' }}>Dr. Rajesh Sharma — Clinical pages</span>
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-primary"
                  onClick={() => handleFill('doctor@hospital.com', 'Doctor@123')}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  Fill Credentials
                </button>
              </div>
              )}

              {role === 'Admin' && (
              <div style={{
                background: '#fff7ed',
                border: '1px solid #fed7aa',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span
                      className="badge"
                      style={{ fontSize: '11px', padding: '2px 8px', background: '#f97316', color: '#fff', borderRadius: '9999px' }}
                    >
                      Admin
                    </span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>admin@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>admin123</code>
                    {' '}<span style={{ color: '#ea580c' }}>Admin User — Administrative pages</span>
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm"
                  onClick={() => handleFill('admin@hospital.com', 'admin123')}
                  style={{ whiteSpace: 'nowrap', background: '#f97316', color: '#fff', border: 'none' }}
                >
                  Fill Credentials
                </button>
              </div>
              )}

              {role === 'Patient' && (
              <div style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-success" style={{ fontSize: '11px', padding: '2px 8px' }}>Patient</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>patient@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Patient@123</code> (Patient #1: Ramesh Kumar Verma)
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-success"
                  onClick={() => handleFill('patient@hospital.com', 'Patient@123')}
                  style={{ whiteSpace: 'nowrap' }}
                >
                  Fill Credentials
                </button>
              </div>
              )}

              {role === 'Laboratory Staff' && (
              <div style={{
                background: '#f8fafc',
                border: '1px solid #e2e8f0',
                borderRadius: '10px',
                padding: '10px 14px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: '12px',
              }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span className="badge badge-purple" style={{ fontSize: '11px', padding: '2px 8px' }}>Lab Staff</span>
                    <span style={{ fontSize: '13px', fontWeight: '700', color: '#0f172a' }}>lab@hospital.com</span>
                  </div>
                  <div style={{ fontSize: '11.5px', color: '#64748b', marginTop: '2px' }}>
                    Password: <code style={{ background: '#e2e8f0', padding: '1px 5px', borderRadius: '4px' }}>Lab@123</code> (Diagnostic &amp; lab tests)
                  </div>
                </div>
                <button
                  type="button"
                  className="btn btn-sm btn-secondary"
                  onClick={() => handleFill('lab@hospital.com', 'Lab@123')}
                  style={{ whiteSpace: 'nowrap', borderColor: '#8b5cf6', color: '#6d28d9' }}
                >
                  Fill Credentials
                </button>
              </div>
              )}

            </div>
          </div>
          </>
          )}
        </div>
      </div>
    </div>
  );
}
