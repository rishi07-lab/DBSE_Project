import React, { useState, useEffect } from 'react';
import { API } from '../services/api';
import {
  DoctorIcon,
  MedicineIcon,
  BillIcon,
  LabReportIcon,
  InsuranceIcon,
  AlertTriangleIcon,
  PlusIcon,
  PatientsIcon,
  ActivityIcon,
} from '../components/Icons';

export default function Dashboard({ onNavigate }) {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      setLoading(true);
      const data = await API.getAdminDashboardStats();
      setStats(data);
      setLoading(false);
    }
    loadStats();
  }, []);

  if (loading || !stats) {
    return (
      <div className="page-container">
        <div style={{ textAlign: 'center', padding: '60px 20px', color: '#64748b' }}>
          Loading hospital analytics...
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: 'Specialist Doctors',
      value: stats.totalDoctors,
      icon: DoctorIcon,
      bgColor: '#ccfbf1',
      iconColor: '#0d9488',
      page: 'doctors',
    },
    {
      label: 'Registered Patients',
      value: stats.totalPatients,
      icon: PatientsIcon,
      bgColor: '#e0f2fe',
      iconColor: '#0284c7',
      subtext: null,
      page: null, // Admin doesn't navigate to patients
    },
    {
      label: 'Medicine Inventory',
      value: stats.totalMedicines,
      icon: MedicineIcon,
      bgColor: '#fef3c7',
      iconColor: '#d97706',
      page: 'medicines',
      subtext: `${stats.lowStockMedicines} Low Stock`,
    },
    {
      label: 'Total Revenue',
      value: `₹${Number(stats.totalRevenue).toLocaleString('en-IN')}`,
      icon: BillIcon,
      bgColor: '#d1fae5',
      iconColor: '#059669',
      page: 'bills',
      subtext: `${stats.pendingBills} Pending Payment`,
    },
    {
      label: 'Operations Today',
      value: stats.operationsToday ?? 0,
      icon: ActivityIcon,
      bgColor: '#ffedd5',
      iconColor: '#ea580c',
      page: null,
      subtext: `${stats.operationsCompletedToday ?? 0} done · ${stats.operationsUpcoming ?? 0} upcoming`,
    },
    {
      label: 'Laboratory Reports',
      value: stats.totalLabReports,
      icon: LabReportIcon,
      bgColor: '#fee2e2',
      iconColor: '#dc2626',
      page: 'lab-tests',
    },
    {
      label: 'Monthly Staff Payroll',
      value: `₹${Number(stats.monthlyPayroll || 0).toLocaleString('en-IN')}`,
      icon: BillIcon,
      bgColor: '#fce7f3',
      iconColor: '#db2777',
      page: 'payroll',
      subtext: `${stats.salariesCreditedThisMonth || 0} of ${stats.salariesSet || 0} salaries credited`,
    },
    {
      label: 'Insurance Claims',
      value: stats.totalInsurance,
      icon: InsuranceIcon,
      bgColor: '#e0e7ff',
      iconColor: '#4f46e5',
      page: 'insurance',
    },
  ];

  return (
    <div className="page-container">
      {/* Page Heading */}
      <div className="page-header">
        <div>
          <h1>Hospital Administration Overview</h1>
          <p>Financial metrics, inventory status, and hospital-wide operational summary.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button className="btn btn-primary" onClick={() => onNavigate('doctors')}>
            <PlusIcon size={16} />
            <span>Add Doctor</span>
          </button>
          <button className="btn btn-secondary" onClick={() => onNavigate('bills')}>
            <PlusIcon size={16} />
            <span>New Bill</span>
          </button>
        </div>
      </div>

      {/* Low stock alert banner if any */}
      {stats.lowStockMedicines > 0 && (
        <div style={{
          background: '#fffbeb',
          border: '1px solid #fde68a',
          borderRadius: '12px',
          padding: '14px 20px',
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{ color: '#d97706' }}><AlertTriangleIcon size={22} /></span>
            <div>
              <span style={{ fontWeight: '700', color: '#92400e', fontSize: '14px' }}>
                Pharmacy Stock Attention Required:
              </span>{' '}
              <span style={{ color: '#b45309', fontSize: '13.5px' }}>
                {stats.lowStockMedicines} medicine item(s) are running below safety threshold (under 20 units).
              </span>
            </div>
          </div>
          <button
            className="btn btn-sm btn-secondary"
            onClick={() => onNavigate('medicines')}
            style={{ whiteSpace: 'nowrap' }}
          >
            Review Inventory
          </button>
        </div>
      )}

      {/* KPI Stats Grid */}
      <div className="stats-grid">
        {statCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div
              key={index}
              className="stat-card"
              style={{ cursor: card.page ? 'pointer' : 'default' }}
              onClick={() => card.page && onNavigate(card.page)}
            >
              <div
                className="stat-icon-wrapper"
                style={{ backgroundColor: card.bgColor, color: card.iconColor }}
              >
                <Icon size={26} />
              </div>
              <div className="stat-card-info">
                <span className="stat-card-value">{card.value}</span>
                <span className="stat-card-label">{card.label}</span>
                {card.subtext && (
                  <span className="stat-card-trend" style={{ color: card.iconColor }}>
                    {card.subtext}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Lower Section: Finance Summary & Quick Actions */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: '24px' }}>

        {/* Recent Bills Summary */}
        <div className="table-card">
          <div style={{
            padding: '16px 20px',
            borderBottom: '1px solid var(--border-color)',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a' }}>
              Financial Snapshot
            </h3>
            <button
              className="btn btn-sm btn-secondary"
              onClick={() => onNavigate('bills')}
            >
              View Bills
            </button>
          </div>
          <div style={{ padding: '20px' }}>
            {[
              { label: 'Total Revenue Collected', value: `₹${Number(stats.totalRevenue).toLocaleString('en-IN')}`, color: '#059669' },
              { label: 'Total Bills Generated', value: stats.totalBills, color: '#0f172a' },
              { label: 'Pending Payments', value: stats.pendingBills, color: '#d97706' },
              { label: 'Active Insurance Claims', value: stats.totalInsurance, color: '#4f46e5' },
            ].map((item, i) => (
              <div key={i} style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: '10px 0',
                borderBottom: i < 3 ? '1px solid #f1f5f9' : 'none',
              }}>
                <span style={{ fontSize: '13.5px', color: '#475569' }}>{item.label}</span>
                <span style={{ fontSize: '15px', fontWeight: '700', color: item.color }}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Admin Quick Navigation */}
        <div className="table-card" style={{ padding: '20px' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '700', color: '#0f172a', marginBottom: '16px' }}>
            Administration Modules Quick Launch
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px' }}>
            {[
              { title: 'Doctors', desc: 'Manage medical staff', page: 'doctors' },
              { title: 'Specializations', desc: 'Departments directory', page: 'specializations' },
              { title: 'Medicines', desc: 'Inventory & stock', page: 'medicines' },
              { title: 'Lab Tests', desc: 'Diagnostic catalog', page: 'lab-tests' },
              { title: 'Billing & Invoices', desc: 'Financial invoices', page: 'bills' },
              { title: 'Insurance Policies', desc: 'Provider claims', page: 'insurance' },
            ].map((m, i) => (
              <div
                key={i}
                onClick={() => onNavigate(m.page)}
                style={{
                  padding: '14px',
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  transition: 'all 0.18s ease',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = '#e0f2fe';
                  e.currentTarget.style.borderColor = '#0284c7';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = '#f8fafc';
                  e.currentTarget.style.borderColor = '#e2e8f0';
                }}
              >
                <div style={{ fontWeight: '700', fontSize: '13.5px', color: '#0f172a' }}>{m.title}</div>
                <div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
