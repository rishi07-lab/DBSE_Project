import React, { useState, useEffect, useMemo } from 'react';
import { API } from '../services/api';
import Modal from '../components/Modal';
import { monthLabel } from '../components/SalaryCard';
import { SearchIcon, EditIcon, PaymentIcon, CheckCircleIcon, EyeIcon, TrashIcon } from '../components/Icons';

const inr = (n) => `₹${Number(n || 0).toLocaleString('en-IN')}`;
const todayStr = () => new Date().toISOString().slice(0, 10);
const maskAcct = (a) => (a ? `${'•'.repeat(Math.max(a.length - 4, 4))}${a.slice(-4)}` : '—');
const MODES = ['Bank Transfer', 'NEFT', 'RTGS', 'IMPS', 'UPI', 'Cheque'];
const STATUS_BADGE = { Credited: 'badge-success', Pending: 'badge-warning', 'Not Set': 'badge-gray' };

export default function StaffPayroll() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [month, setMonth] = useState(todayStr().slice(0, 7));
  const [search, setSearch] = useState('');
  const [type, setType] = useState('All');

  const [editing, setEditing] = useState(null);   // staff row being edited
  const [form, setForm] = useState({});
  const [crediting, setCrediting] = useState(null);
  const [creditForm, setCreditForm] = useState({});
  const [history, setHistory] = useState(null);   // { staff, items }
  const [showAcct, setShowAcct] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    setLoading(true);
    setRows(await API.getPayroll(month));
    setLoading(false);
  };
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [month]);

  const filtered = useMemo(() => rows.filter((r) => {
    const q = search.toLowerCase();
    const okSearch = !q || r.name?.toLowerCase().includes(q) || r.email?.toLowerCase().includes(q) || r.bank_name?.toLowerCase().includes(q);
    return okSearch && (type === 'All' || r.staff_type === type);
  }), [rows, search, type]);

  const totalMonthly = rows.reduce((a, r) => a + Number(r.monthly_salary || 0), 0);
  const creditedRows = rows.filter((r) => r.salary_status === 'Credited');
  const creditedAmount = creditedRows.reduce((a, r) => a + Number(r.credited_amount || 0), 0);
  const pendingRows = rows.filter((r) => r.salary_status === 'Pending');
  const notSet = rows.filter((r) => r.salary_status === 'Not Set').length;

  // ---- edit salary + bank ----
  const openEdit = (r) => {
    setEditing(r);
    setShowAcct(false);
    setForm({
      monthly_salary: r.monthly_salary || '', bank_name: r.bank_name || '',
      account_holder: r.account_holder || r.name?.replace(/^Dr\.?\s*/i, '') || '',
      account_number: r.account_number || '', ifsc_code: r.ifsc_code || '', branch: r.branch || '',
    });
  };
  const saveEdit = async (e) => {
    e?.preventDefault();
    setBusy(true);
    try {
      await API.updatePayroll(editing.user_id, { ...form, monthly_salary: form.monthly_salary === '' ? 0 : Number(form.monthly_salary) });
      setEditing(null);
      await load();
    } catch { /* message already shown by the API layer */ }
    setBusy(false);
  };

  // ---- credit salary ----
  const openCredit = (r) => {
    setCrediting(r);
    setCreditForm({ credited_on: todayStr(), payment_mode: 'Bank Transfer', reference_no: '', amount: r.monthly_salary });
  };
  const saveCredit = async (e) => {
    e?.preventDefault();
    setBusy(true);
    try {
      await API.creditSalary(crediting.user_id, { ...creditForm, month, amount: Number(creditForm.amount) });
      setCrediting(null);
      await load();
    } catch { /* shown */ }
    setBusy(false);
  };
  const creditAll = async () => {
    if (!window.confirm(`Credit ${monthLabel(month)} salary to ${pendingRows.length} staff member(s) with complete bank details?`)) return;
    setBusy(true);
    try {
      const r = await API.creditAllSalaries({ month, credited_on: todayStr() });
      const skip = r.skipped.filter((s) => s.reason !== 'Already credited');
      window.alert(`${r.creditedCount} salary credit(s) recorded for ${monthLabel(month)}.${skip.length ? `\n\nSkipped (add salary / bank details first):\n- ${skip.map((s) => s.name).join('\n- ')}` : ''}`);
      await load();
    } catch { /* shown */ }
    setBusy(false);
  };

  // ---- history ----
  const openHistory = async (r) => setHistory({ staff: r, items: await API.getSalaryHistory(r.user_id) });
  const undoCredit = async (item) => {
    if (!window.confirm(`Remove the ${monthLabel(item.pay_month)} salary credit entry for ${history.staff.name}? Use this only for entries made by mistake.`)) return;
    await API.undoSalaryCredit(history.staff.user_id, item.pay_month);
    setHistory({ ...history, items: await API.getSalaryHistory(history.staff.user_id) });
    load();
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1>Staff Salaries &amp; Bank Details</h1>
          <p>Set monthly salary and bank accounts for doctors and laboratory staff, and record when salary is credited.</p>
        </div>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' }}>
          <input type="month" className="form-input" style={{ width: 'auto' }} value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} />
          <button className="btn btn-primary" disabled={busy || pendingRows.length === 0} onClick={creditAll}>
            <CheckCircleIcon size={16} /><span>Credit All Pending ({pendingRows.length})</span>
          </button>
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#fce7f3', color: '#db2777' }}><PaymentIcon size={26} /></div>
          <div className="stat-card-info">
            <span className="stat-card-value">{inr(totalMonthly)}</span>
            <span className="stat-card-label">Monthly Payroll</span>
            <span className="stat-card-trend" style={{ color: '#64748b' }}>{rows.length} staff members</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#d1fae5', color: '#059669' }}><CheckCircleIcon size={26} /></div>
          <div className="stat-card-info">
            <span className="stat-card-value" style={{ color: '#059669' }}>{inr(creditedAmount)}</span>
            <span className="stat-card-label">Credited · {monthLabel(month)}</span>
            <span className="stat-card-trend" style={{ color: '#64748b' }}>{creditedRows.length} salaries paid</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#fef3c7', color: '#d97706' }}><PaymentIcon size={26} /></div>
          <div className="stat-card-info">
            <span className="stat-card-value">{pendingRows.length}</span>
            <span className="stat-card-label">Pending This Month</span>
            <span className="stat-card-trend" style={{ color: '#64748b' }}>{inr(pendingRows.reduce((a, r) => a + r.monthly_salary, 0))} to release</span>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper" style={{ background: '#f1f5f9', color: '#64748b' }}><EditIcon size={24} /></div>
          <div className="stat-card-info">
            <span className="stat-card-value">{notSet}</span>
            <span className="stat-card-label">Salary Not Set</span>
            <span className="stat-card-trend" style={{ color: '#64748b' }}>need salary &amp; bank details</span>
          </div>
        </div>
      </div>

      <div className="action-bar">
        <div className="search-filter-group">
          <div className="search-input-wrapper">
            <span className="search-icon"><SearchIcon size={16} /></span>
            <input type="text" className="search-input" placeholder="Search by name, email or bank..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <select className="filter-select" value={type} onChange={(e) => setType(e.target.value)}>
            <option value="All">Doctors &amp; Lab Staff</option>
            <option value="Doctor">Doctors only</option>
            <option value="Laboratory Staff">Lab Staff only</option>
          </select>
        </div>
        <div style={{ color: '#64748b', fontSize: '13px', fontWeight: 500 }}>{filtered.length} staff shown</div>
      </div>

      <div className="table-card">
        <div className="table-responsive">
          <table className="custom-table">
            <thead>
              <tr>
                <th>Staff Member</th><th>Role</th><th>Monthly Salary</th><th>Bank Account</th>
                <th>{monthLabel(month)}</th><th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="6" style={{ textAlign: 'center', padding: '30px', color: '#64748b' }}>Loading payroll...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan="6" style={{ textAlign: 'center', padding: '40px', color: '#94a3b8' }}>No staff found.</td></tr>
              ) : filtered.map((r) => (
                <tr key={r.user_id}>
                  <td>
                    <div style={{ fontWeight: 700, color: '#0f172a' }}>{r.name}</div>
                    <div style={{ fontSize: '12px', color: '#64748b' }}>{r.designation}</div>
                  </td>
                  <td><span className={`badge ${r.staff_type === 'Doctor' ? 'badge-primary' : 'badge-purple'}`}>{r.staff_type}</span></td>
                  <td style={{ fontWeight: 700 }}>{r.monthly_salary ? inr(r.monthly_salary) : <span style={{ color: '#94a3b8', fontWeight: 500 }}>Not set</span>}</td>
                  <td>
                    {r.bank_name ? (
                      <>
                        <div style={{ fontWeight: 600, color: '#0f172a', fontSize: '13px' }}>{r.bank_name}</div>
                        <div style={{ fontSize: '12px', color: '#64748b' }}>{maskAcct(r.account_number)}{r.ifsc_code ? ` · ${r.ifsc_code}` : ''}</div>
                      </>
                    ) : <span style={{ color: '#94a3b8' }}>No bank details</span>}
                  </td>
                  <td>
                    <span className={`badge ${STATUS_BADGE[r.salary_status]}`}>{r.salary_status === 'Credited' ? 'Salary Credited' : r.salary_status}</span>
                    {r.salary_status === 'Credited' && <div style={{ fontSize: '11px', color: '#64748b', marginTop: 3 }}>{r.credited_on}</div>}
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    {r.salary_status !== 'Credited' && (
                      <button className="btn btn-sm btn-success" style={{ marginRight: 6 }} disabled={!r.bank_ready} title={r.bank_ready ? 'Record salary credit' : 'Add salary and bank details first'} onClick={() => openCredit(r)}>
                        Credit Salary
                      </button>
                    )}
                    <button className="btn-icon edit" title="Edit salary & bank details" onClick={() => openEdit(r)}><EditIcon size={16} /></button>
                    <button className="btn-icon" title="Salary history" onClick={() => openHistory(r)}><EyeIcon size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit salary + bank details */}
      <Modal
        isOpen={!!editing}
        onClose={() => setEditing(null)}
        title={editing ? `Salary & Bank Details — ${editing.name}` : ''}
        footer={<>
          <button className="btn btn-secondary" onClick={() => setEditing(null)}>Cancel</button>
          <button className="btn btn-primary" disabled={busy} onClick={saveEdit}>Save Details</button>
        </>}
      >
        <form onSubmit={saveEdit} className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Monthly Salary (₹) *</label>
            <input type="number" min="0" step="0.01" className="form-input" value={form.monthly_salary ?? ''} onChange={set('monthly_salary')} placeholder="e.g. 85000" required />
          </div>
          <div className="form-group">
            <label className="form-label">Bank Name</label>
            <input className="form-input" value={form.bank_name ?? ''} onChange={set('bank_name')} placeholder="e.g. HDFC Bank" />
          </div>
          <div className="form-group">
            <label className="form-label">Account Holder Name</label>
            <input className="form-input" value={form.account_holder ?? ''} onChange={set('account_holder')} />
          </div>
          <div className="form-group">
            <label className="form-label">Account Number</label>
            <input type={showAcct ? 'text' : 'password'} autoComplete="off" inputMode="numeric" className="form-input" value={form.account_number ?? ''} onChange={set('account_number')} placeholder="9 to 18 digits" />
            <label style={{ fontSize: '12px', color: '#64748b', marginTop: 4, display: 'flex', gap: 6, alignItems: 'center' }}>
              <input type="checkbox" checked={showAcct} onChange={(e) => setShowAcct(e.target.checked)} /> Show account number
            </label>
          </div>
          <div className="form-group">
            <label className="form-label">IFSC Code</label>
            <input className="form-input" style={{ textTransform: 'uppercase' }} maxLength={11} value={form.ifsc_code ?? ''} onChange={set('ifsc_code')} placeholder="HDFC0001234" />
          </div>
          <div className="form-group col-span-2">
            <label className="form-label">Branch</label>
            <input className="form-input" value={form.branch ?? ''} onChange={set('branch')} placeholder="e.g. Kukatpally Branch" />
          </div>
        </form>
      </Modal>

      {/* Credit salary */}
      <Modal
        isOpen={!!crediting}
        onClose={() => setCrediting(null)}
        title={crediting ? `Credit Salary — ${crediting.name}` : ''}
        footer={<>
          <button className="btn btn-secondary" onClick={() => setCrediting(null)}>Cancel</button>
          <button className="btn btn-success" disabled={busy} onClick={saveCredit}>Mark as Credited</button>
        </>}
      >
        {crediting && (
          <form onSubmit={saveCredit} className="form-grid">
            <div className="form-group col-span-2" style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10, padding: '10px 14px', fontSize: '13px', color: '#475569' }}>
              Salary for <strong>{monthLabel(month)}</strong> to <strong>{crediting.bank_name}</strong> · A/c {maskAcct(crediting.account_number)} · IFSC {crediting.ifsc_code}
            </div>
            <div className="form-group">
              <label className="form-label">Amount (₹) *</label>
              <input type="number" min="1" step="0.01" className="form-input" value={creditForm.amount} onChange={(e) => setCreditForm({ ...creditForm, amount: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Credited On *</label>
              <input type="date" className="form-input" value={creditForm.credited_on} onChange={(e) => setCreditForm({ ...creditForm, credited_on: e.target.value })} required />
            </div>
            <div className="form-group">
              <label className="form-label">Payment Mode</label>
              <select className="form-select" value={creditForm.payment_mode} onChange={(e) => setCreditForm({ ...creditForm, payment_mode: e.target.value })}>
                {MODES.map((m) => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Reference / UTR No.</label>
              <input className="form-input" value={creditForm.reference_no} onChange={(e) => setCreditForm({ ...creditForm, reference_no: e.target.value })} placeholder="Auto-generated if empty" />
            </div>
          </form>
        )}
      </Modal>

      {/* History */}
      <Modal isOpen={!!history} onClose={() => setHistory(null)} title={history ? `Salary History — ${history.staff.name}` : ''} maxWidth="760px">
        {history && (
          <div className="table-responsive">
            <table className="custom-table">
              <thead><tr><th>Month</th><th>Amount</th><th>Credited On</th><th>Mode</th><th>Reference</th><th>Bank</th><th /></tr></thead>
              <tbody>
                {history.items.length === 0 ? (
                  <tr><td colSpan="7" style={{ textAlign: 'center', padding: '24px', color: '#94a3b8' }}>No salary credited yet.</td></tr>
                ) : history.items.map((i) => (
                  <tr key={i.salary_payment_id}>
                    <td style={{ fontWeight: 700 }}>{monthLabel(i.pay_month)}</td>
                    <td style={{ fontWeight: 700, color: '#059669' }}>{inr(i.amount)}</td>
                    <td style={{ fontSize: '12px', color: '#64748b' }}>{i.credited_on}</td>
                    <td><span className="badge badge-gray">{i.payment_mode}</span></td>
                    <td style={{ fontSize: '12px', color: '#64748b' }}>{i.reference_no}</td>
                    <td style={{ fontSize: '12px', color: '#64748b' }}>{i.bank_name} {i.account_last4 ? `••${i.account_last4}` : ''}</td>
                    <td><button className="btn-icon delete" title="Remove this entry (made by mistake)" onClick={() => undoCredit(i)}><TrashIcon size={15} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Modal>
    </div>
  );
}
